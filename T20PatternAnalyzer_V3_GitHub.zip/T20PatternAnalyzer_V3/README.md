# T20 Pattern Analyzer V3

Android app for testing the user's six T20 match-pattern signals.

## Build

The included GitHub Actions workflow builds a debug APK using Java 17 and Gradle 8.9.

## Important

This is an experimental analysis tool. It does not place bets and does not claim guaranteed outcomes. The next development stage is persistent prediction history and backtesting so each pattern can be measured against real results.
