package com.example.t20patternanalyzer

import android.app.Activity
import android.os.Bundle
import android.text.InputType
import android.graphics.Color
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class MainActivity : Activity() {

    private lateinit var resultView: TextView
    private lateinit var historyView: TextView

    private fun textInput(hintText: String): EditText {
        return EditText(this).apply {
            hint = hintText
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT
        }
    }

    private fun numberInput(hintText: String): EditText {
        return EditText(this).apply {
            hint = hintText
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL or InputType.TYPE_NUMBER_FLAG_SIGNED
        }
    }

    private fun addView(box: LinearLayout, view: View) {
        box.addView(
            view,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = 12
            }
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 24, 28, 32)
        }

        val title = TextView(this).apply {
            text = "T20 Pattern Analyzer"
            textSize = 26f
            setTextColor(Color.rgb(20, 55, 90))
            setPadding(0, 0, 0, 8)
        }
        addView(box, title)

        val subtitle = TextView(this).apply {
            text = "V3 • Six-signal experimental engine • Backtest-ready"
            textSize = 14f
            setPadding(0, 0, 0, 16)
        }
        addView(box, subtitle)

        val teamA = textInput("Team A")
        val teamB = textInput("Team B")
        val firstInningsScore = numberInput("1st innings score")
        val openingOddsA = numberInput("Opening odds — Team A")
        val currentOddsA = numberInput("Current / innings-break odds — Team A")
        val runDifference = numberInput("Run difference — A perspective")

        addView(box, teamA)
        addView(box, teamB)
        addView(box, firstInningsScore)
        addView(box, openingOddsA)
        addView(box, currentOddsA)
        addView(box, runDifference)

        val previousResult = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@MainActivity,
                android.R.layout.simple_spinner_dropdown_item,
                arrayOf(
                    "Previous result: unknown",
                    "Team A won chasing",
                    "Team A won defending",
                    "Team B won chasing",
                    "Team B won defending"
                )
            )
        }
        addView(box, previousResult)

        val closeMatch = CheckBox(this).apply {
            text = "Previous match was very close / favourites changed multiple times"
        }
        addView(box, closeMatch)

        val collapseRecovery = CheckBox(this).apply {
            text = "1st innings: early collapse followed by recovery"
        }
        addView(box, collapseRecovery)

        val steadyInnings = CheckBox(this).apply {
            text = "1st innings: steady/slower scoring without repeated wicket clusters"
        }
        addView(box, steadyInnings)

        val analyseButton = Button(this).apply {
            text = "ANALYSE MATCH"
        }
        addView(box, analyseButton)

        resultView = TextView(this).apply {
            textSize = 17f
            setPadding(0, 18, 0, 18)
        }
        addView(box, resultView)

        val saveButton = Button(this).apply {
            text = "SAVE LAST PREDICTION"
        }
        addView(box, saveButton)

        historyView = TextView(this).apply {
            textSize = 14f
            setPadding(0, 8, 0, 18)
        }
        addView(box, historyView)

        val clearButton = Button(this).apply {
            text = "CLEAR FORM"
        }
        addView(box, clearButton)

        val note = TextView(this).apply {
            text = "Important: these are experimental signals, not guaranteed probabilities. " +
                    "The app does not place bets. The next development step is persistent history + backtesting."
            textSize = 12f
            setPadding(0, 18, 0, 0)
        }
        addView(box, note)

        var lastPrediction = ""

        analyseButton.setOnClickListener {
            val teamAName = teamA.text.toString().trim().ifBlank { "Team A" }
            val teamBName = teamB.text.toString().trim().ifBlank { "Team B" }
            val score = firstInningsScore.text.toString().toIntOrNull()
            val openingOdds = openingOddsA.text.toString().toDoubleOrNull()
            val currentOdds = currentOddsA.text.toString().toDoubleOrNull()
            val runDiff = runDifference.text.toString().toDoubleOrNull()

            val signals = mutableListOf<String>()
            var teamAVotes = 0
            var teamBVotes = 0
            var chaseVotes = 0
            var defendVotes = 0

            // Pattern 1: first-innings score bands.
            if (score != null) {
                when (score) {
                    in 141..149, in 160..169, in 180..189, in 190..200, in 210..225 -> {
                        signals += "P1: $score → DEFEND tendency"
                        defendVotes++
                    }
                    in 150..159, in 170..179, in 201..209 -> {
                        signals += "P1: $score → CHASE tendency"
                        chaseVotes++
                    }
                    else -> signals += "P1: $score → outside configured score bands"
                }
            }

            // Pattern 2: previous-match direction.
            when (previousResult.selectedItemPosition) {
                1 -> {
                    signals += "P2: A won chasing previously → if A chases again, oppose A; if A defends, support A"
                    teamBVotes++
                }
                2 -> {
                    signals += "P2: A won defending previously → if A defends again, support A; if A chases, oppose A"
                    teamAVotes++
                }
                3 -> {
                    signals += "P2: B won chasing previously → if B chases again, oppose B; if B defends, support B"
                    teamAVotes++
                }
                4 -> {
                    signals += "P2: B won defending previously → if B defends again, support B; if B chases, oppose B"
                    teamBVotes++
                }
            }

            // Pattern 3: close/fluctuating previous match.
            if (closeMatch.isChecked) {
                when (previousResult.selectedItemPosition) {
                    1, 2 -> {
                        signals += "P3: close/fluctuating match → continuation signal for previous winner (A)"
                        teamAVotes++
                    }
                    3, 4 -> {
                        signals += "P3: close/fluctuating match → continuation signal for previous winner (B)"
                        teamBVotes++
                    }
                    else -> signals += "P3: close match marked, but previous winner is unknown"
                }
            }

            // Pattern 4: first-ball / current price movement.
            if (openingOdds != null && currentOdds != null && openingOdds > 1.0 && currentOdds > 1.0) {
                when {
                    currentOdds < openingOdds -> {
                        signals += String.format(
                            Locale.US,
                            "P4: A shortened %.2f → %.2f → oppose A",
                            openingOdds,
                            currentOdds
                        )
                        teamBVotes++
                    }
                    currentOdds > openingOdds -> {
                        signals += String.format(
                            Locale.US,
                            "P4: A drifted %.2f → %.2f → oppose B",
                            openingOdds,
                            currentOdds
                        )
                        teamAVotes++
                    }
                    else -> signals += "P4: A odds unchanged"
                }
            }

            // Pattern 5: innings shape.
            if (collapseRecovery.isChecked) {
                signals += "P5: collapse + recovery → CHASE tendency"
                chaseVotes++
            }
            if (steadyInnings.isChecked) {
                signals += "P5: steady/slower innings → DEFEND tendency"
                defendVotes++
            }

            // Pattern 6: opening probability + run adjustment.
            var adjustedProbability: Double? = null
            if (openingOdds != null && openingOdds > 1.0 && runDiff != null) {
                val openingProbability = 1.0 / openingOdds
                adjustedProbability = min(0.99, max(0.01, openingProbability + runDiff * 0.0065))
                signals += String.format(
                    Locale.US,
                    "P6: A probability estimate = %.1f%% (opening 1/odds + run difference × 0.0065)",
                    adjustedProbability * 100.0
                )
                if (adjustedProbability > 0.50) {
                    teamAVotes++
                } else if (adjustedProbability < 0.50) {
                    teamBVotes++
                }
            }

            val prediction = when {
                teamAVotes > teamBVotes -> teamAName
                teamBVotes > teamAVotes -> teamBName
                chaseVotes > defendVotes -> "Chasing side"
                defendVotes > chaseVotes -> "Defending side"
                else -> "NO CLEAR SIGNAL"
            }

            val totalTeamVotes = teamAVotes + teamBVotes
            val signalStrength = if (totalTeamVotes == 0) {
                50
            } else {
                min(90, 50 + (abs(teamAVotes - teamBVotes) * 10))
            }

            val output = StringBuilder()
            output.append("PREDICTION: ").append(prediction).append("\n")
            output.append("Signal strength: ").append(signalStrength).append("/100\n\n")
            if (signals.isEmpty()) {
                output.append("Enter at least one useful input so the engine has a signal to evaluate.")
            } else {
                output.append(signals.joinToString("\n") { "• $it" })
            }
            output.append("\n\nTeam votes: ").append(teamAName).append("=").append(teamAVotes)
            output.append(" | ").append(teamBName).append("=").append(teamBVotes)
            output.append("\nMatch-shape votes: chase=").append(chaseVotes)
            output.append(" | defend=").append(defendVotes)
            output.append("\n\nP6 is an experimental model, not a calibrated probability.")

            lastPrediction = output.toString()
            resultView.text = lastPrediction
        }

        saveButton.setOnClickListener {
            if (lastPrediction.isBlank()) {
                Toast.makeText(this, "Analyse a match first", Toast.LENGTH_SHORT).show()
            } else {
                historyView.text = "Last saved prediction:\n\n$lastPrediction"
                Toast.makeText(this, "Prediction saved on screen", Toast.LENGTH_SHORT).show()
            }
        }

        clearButton.setOnClickListener {
            teamA.text.clear()
            teamB.text.clear()
            firstInningsScore.text.clear()
            openingOddsA.text.clear()
            currentOddsA.text.clear()
            runDifference.text.clear()
            previousResult.setSelection(0)
            closeMatch.isChecked = false
            collapseRecovery.isChecked = false
            steadyInnings.isChecked = false
            resultView.text = ""
            lastPrediction = ""
        }

        scroll.addView(box)
        setContentView(scroll)
    }
}
