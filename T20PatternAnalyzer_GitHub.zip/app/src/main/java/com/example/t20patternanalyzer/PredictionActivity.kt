package com.example.t20patternanalyzer

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class PredictionActivity : Activity() {
    private val navy = Color.rgb(15, 30, 48)
    private val navy2 = Color.rgb(25, 49, 76)
    private val blue = Color.rgb(38, 126, 218)
    private val blueSoft = Color.rgb(232, 242, 253)
    private val green = Color.rgb(37, 135, 76)
    private val greenSoft = Color.rgb(231, 247, 238)
    private val red = Color.rgb(190, 55, 55)
    private val redSoft = Color.rgb(252, 235, 235)
    private val amber = Color.rgb(201, 124, 31)
    private val amberSoft = Color.rgb(255, 244, 225)
    private val textDark = Color.rgb(29, 38, 49)
    private val muted = Color.rgb(101, 113, 126)
    private val line = Color.rgb(224, 230, 237)
    private val pageBg = Color.rgb(245, 247, 250)
    private val white = Color.WHITE

    private lateinit var resultCard: LinearLayout
    private lateinit var historyView: TextView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun bg(color: Int, radius: Int = 16) = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    private fun stroke(color: Int, strokeColor: Int = line, width: Int = 1, radius: Int = 16) = GradientDrawable().apply { setColor(color); setStroke(dp(width), strokeColor); cornerRadius = dp(radius).toFloat() }
    private fun lp(bottom: Int = 0, top: Int = 0) = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(bottom); topMargin = dp(top) }
    private fun add(parent: LinearLayout, child: View, bottom: Int = 10) { parent.addView(child, lp(bottom)) }
    private fun row(weight1: Float = 1f, gap: Int = 8) = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutParams = lp(10) }
    private fun label(text: String) = TextView(this).apply { this.text = text; textSize = 12f; typeface = Typeface.DEFAULT_BOLD; setTextColor(muted); letterSpacing = .03f }
    private fun title(text: String) = TextView(this).apply { this.text = text; textSize = 18f; typeface = Typeface.DEFAULT_BOLD; setTextColor(navy) }
    private fun subtitle(text: String) = TextView(this).apply { this.text = text; textSize = 12.5f; setTextColor(muted); setLineSpacing(1f, 1.05f) }
    private fun input(hint: String, number: Boolean = false) = EditText(this).apply {
        this.hint = hint; setSingleLine(true); textSize = 15.5f; setTextColor(textDark); setHintTextColor(Color.rgb(145,154,164))
        setPadding(dp(13), dp(10), dp(13), dp(10)); minimumHeight = dp(48)
        inputType = if (number) InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL else InputType.TYPE_CLASS_TEXT
        background = stroke(Color.rgb(249, 250, 252), line, 1, 12)
    }
    private fun spinner(options: Array<String>) = Spinner(this).apply {
        adapter = ArrayAdapter(this@PredictionActivity, android.R.layout.simple_spinner_dropdown_item, options)
        background = stroke(Color.rgb(249, 250, 252), line, 1, 12); minimumHeight = dp(48)
    }
    private fun section(icon: String, heading: String, hint: String): LinearLayout {
        val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(16)); background = bg(white, 18) }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val iconView = TextView(this).apply { text = icon; textSize = 18f; gravity = Gravity.CENTER; background = bg(blueSoft, 12); setPadding(dp(7),dp(5),dp(7),dp(5)); minWidth = dp(38) }
        top.addView(iconView, LinearLayout.LayoutParams(dp(42), dp(42)))
        val text = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12),0,0,0) }
        text.addView(title(heading), lp(2)); text.addView(subtitle(hint), lp(0))
        top.addView(text, LinearLayout.LayoutParams(0,-2,1f)); card.addView(top, lp(14)); return card
    }
    private fun field(parent: LinearLayout, name: String, view: View, bottom: Int = 10) { add(parent, label(name), 5); add(parent, view, bottom) }
    private fun note(text: String) = TextView(this).apply { this.text = text; textSize = 11.5f; setTextColor(muted); setPadding(dp(2),dp(2),dp(2),dp(2)); setLineSpacing(1f,1.08f) }

    private data class Signal(val pattern: String, val team: Int, val text: String)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = navy
        window.navigationBarColor = pageBg

        val scroll = ScrollView(this).apply { setBackgroundColor(pageBg); clipToPadding = false }
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(14), dp(14), dp(30)) }

        // Premium header
        val hero = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20),dp(20),dp(20),dp(20)); background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(navy, navy2)).apply { cornerRadius=dp(24).toFloat() } }
        val brand = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val mark = TextView(this).apply { text="T20"; textSize=15f; typeface=Typeface.DEFAULT_BOLD; setTextColor(navy); gravity=Gravity.CENTER; background=bg(Color.WHITE,12); setPadding(dp(8),dp(7),dp(8),dp(7)) }
        brand.addView(mark, LinearLayout.LayoutParams(dp(50),dp(42)))
        val brandText = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(12),0,0,0) }
        brandText.addView(TextView(this).apply{text="PATTERN ANALYZER";textSize=11f;typeface=Typeface.DEFAULT_BOLD;setTextColor(Color.rgb(174,201,227));letterSpacing=.16f},lp(2))
        brandText.addView(TextView(this).apply{text="Decision Engine";textSize=21f;typeface=Typeface.DEFAULT_BOLD;setTextColor(Color.WHITE)},lp(0))
        brand.addView(brandText,LinearLayout.LayoutParams(0,-2,1f)); hero.addView(brand,lp(14))
        hero.addView(TextView(this).apply{text="P1–P6 strategy engine  •  market-aware  •  conflict-aware";textSize=12.5f;setTextColor(Color.rgb(208,222,236))},lp(0))
        add(root, hero, 14)

        val match = section("🏏","Match setup","First innings and team context")
        val teams = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        val teamA=input("Team A"); val teamB=input("Team B")
        teams.addView(teamA,LinearLayout.LayoutParams(0,-2,1f).apply{rightMargin=dp(5)}); teams.addView(teamB,LinearLayout.LayoutParams(0,-2,1f).apply{leftMargin=dp(5)})
        add(match,label("TEAMS"),5); add(match,teams,10)
        val first=spinner(arrayOf("Select batting-first team","Team A","Team B")); field(match,"BATTING FIRST",first)
        val score=input("e.g. 159",true); field(match,"FIRST-INNINGS SCORE",score)
        val length=spinner(arrayOf("20 overs","Shortened — under 20 overs")); field(match,"INNINGS LENGTH",length)
        val overs=input("Overs actually played, e.g. 17.4",true); field(match,"OVERS ACTUALLY PLAYED",overs,0)
        add(root,match,12)

        val odds=section("◈","Market inputs","Prices used by P4 and the finalized P6 model")
        val openFav=spinner(arrayOf("Select opening favourite","Team A","Team B")); field(odds,"OPENING FAVOURITE",openFav)
        val openOdds=input("Opening odds, e.g. 1.52",true); field(odds,"PRE-FIRST-BALL ODDS",openOdds)
        val firstBallOdds=input("First-ball odds, e.g. 1.53",true); field(odds,"FIRST-BALL ODDS",firstBallOdds)
        add(odds,note("P4 uses the opening → first-ball movement. A move must be strictly greater than 0.10 to signal."),12)
        val currentFav=spinner(arrayOf("Select innings-break favourite","Team A","Team B")); field(odds,"INNINGS-BREAK FAVOURITE",currentFav)
        val currentOdds=input("Current odds, e.g. 1.42",true); field(odds,"INNINGS-BREAK ODDS (P6)",currentOdds)
        add(odds,note("P6 uses the opening favourite's pre-first-ball odds as its baseline. If the market favourite switches, the same team's market-implied odds are derived from the opposite probability."),12)
        val lambiDir=spinner(arrayOf("Select: more or less than Lambi","More than Lambi","Less than Lambi")); field(odds,"SCORE VS LAMBI",lambiDir)
        val lambiDiff=input("Absolute difference, e.g. 4",true); field(odds,"RUN DIFFERENCE",lambiDiff,0)
        add(root,odds,12)

        val prev=section("↻","Previous-match signals","P2 and P3 context")
        val prevA=spinner(arrayOf("Unknown","Won — chasing","Won — defending","Lost — chasing","Lost — defending")); field(prev,"TEAM A — PREVIOUS MATCH",prevA)
        val prevB=spinner(arrayOf("Unknown","Won — chasing","Won — defending","Lost — chasing","Lost — defending")); field(prev,"TEAM B — PREVIOUS MATCH",prevB)
        val closeA=CheckBox(this).apply{text="Team A: close / volatile previous match";textSize=13.5f;setTextColor(textDark);buttonTintList=android.content.res.ColorStateList.valueOf(blue)}
        val closeB=CheckBox(this).apply{text="Team B: close / volatile previous match";textSize=13.5f;setTextColor(textDark);buttonTintList=android.content.res.ColorStateList.valueOf(blue)}
        add(prev,closeA,2); add(prev,closeB,0); add(root,prev,12)

        val shape=section("◒","First-innings shape","P5 is manual and mutually exclusive")
        val p5=spinner(arrayOf("No P5 signal","Collapse + recovery → CHASE","Steady / slower innings → DEFEND")); add(shape,p5,0); add(root,shape,12)

        val analyse=Button(this).apply{text="RUN FINAL ANALYSIS  〉";textSize=15f;typeface=Typeface.DEFAULT_BOLD;setTextColor(Color.WHITE);background=bg(blue,16);minimumHeight=dp(56);elevation=dp(2).toFloat()}
        add(root,analyse,12)

        resultCard=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(18),dp(18),dp(18));background=bg(white,20);visibility=View.GONE}
        add(root,resultCard,12)
        val save=Button(this).apply{text="SAVE LAST ANALYSIS";textSize=13f;typeface=Typeface.DEFAULT_BOLD;setTextColor(navy);background=stroke(Color.WHITE,line,1,14);minimumHeight=dp(48)}; add(root,save,8)
        historyView=TextView(this).apply{textSize=12.5f;setTextColor(muted);setPadding(dp(4),dp(4),dp(4),dp(4))}; add(root,historyView,8)
        val clear=Button(this).apply{text="RESET FORM";textSize=13f;typeface=Typeface.DEFAULT_BOLD;setTextColor(muted);background=bg(Color.rgb(235,239,244),14);minimumHeight=dp(46)}; add(root,clear,12)
        add(root,TextView(this).apply{text="Experimental strategy analysis • no bets are placed • confidence reflects signal alignment, not guaranteed probability.";textSize=11f;setTextColor(muted);gravity=Gravity.CENTER;setPadding(dp(10),0,dp(10),0)},0)

        var last=""
        analyse.setOnClickListener {
            val a=teamA.text.toString().trim().ifBlank{"Team A"}; val b=teamB.text.toString().trim().ifBlank{"Team B"}
            val sc=score.text.toString().toIntOrNull(); val oo=openOdds.text.toString().toDoubleOrNull(); val fb=firstBallOdds.text.toString().toDoubleOrNull(); val co=currentOdds.text.toString().toDoubleOrNull()
            val batting=first.selectedItemPosition; val of=openFav.selectedItemPosition; val cf=currentFav.selectedItemPosition
            val diff=lambiDiff.text.toString().toDoubleOrNull()?.let{abs(it)}; val moreLess=when(lambiDir.selectedItemPosition){1->1.0;2->-1.0;else->null}
            val signals=mutableListOf<Signal>(); val notes=mutableListOf<String>()
            fun name(t:Int)=if(t==1)a else b
            fun other(t:Int)=if(t==1)2 else 1
            fun addSignal(p:String,t:Int,s:String){signals+=Signal(p,t,s)}
            fun role(t:Int)=if(batting==0)0 else if(t==batting)2 else 1 // 1 chase, 2 defend

            // P1
            if(sc!=null && length.selectedItemPosition==0 && batting in 1..2){
                val tendency=when(sc){in 141..149,in 160..169,in 180..189,in 190..200,in 210..225->2;in 150..159,in 170..179,in 201..209->1;else->0}
                if(tendency==1)addSignal("P1",other(batting),"$sc → CHASE tendency")
                if(tendency==2)addSignal("P1",batting,"$sc → DEFEND tendency")
                if(tendency==0)notes+="P1: no signal (score outside 141–225)"
            } else notes+="P1: no signal (requires a completed 20-over innings)"

            // P2
            fun p2(position:Int, team:Int):Int?{val r=role(team);if(position !in 1..4||r==0)return null;val won=position<=2;val prevRole=if(position==1||position==3)1 else 2;val support=if(won)r!=prevRole else r==prevRole;return if(support)team else other(team)}
            val p2a=p2(prevA.selectedItemPosition,1); val p2b=p2(prevB.selectedItemPosition,2)
            if(p2a!=null&&p2b!=null&&p2a!=p2b)notes+="P2: opposite team signals → P2 ignored entirely" else {if(p2a!=null)addSignal("P2",p2a,"${name(1)} previous ${if(prevA.selectedItemPosition<=2)"WIN" else "LOSS"} / ${if(prevA.selectedItemPosition==1||prevA.selectedItemPosition==3)"chasing" else "defending"} → support ${name(p2a)}");if(p2b!=null)addSignal("P2",p2b,"${name(2)} previous ${if(prevB.selectedItemPosition<=2)"WIN" else "LOSS"} / ${if(prevB.selectedItemPosition==1||prevB.selectedItemPosition==3)"chasing" else "defending"} → support ${name(p2b)}")}

            // P3
            val p3a=closeA.isChecked&&prevA.selectedItemPosition in 1..4; val p3b=closeB.isChecked&&prevB.selectedItemPosition in 1..4
            if(p3a&&p3b)notes+="P3: both teams qualify → P3 ignored entirely" else {if(p3a)addSignal("P3",1,"close/fluctuating previous match → $a");if(p3b)addSignal("P3",2,"close/fluctuating previous match → $b")}

            // P4
            if(of in 1..2&&oo!=null&&fb!=null&&oo>1&&fb>1){val move=fb-oo;if(abs(move)>0.10){val t=if(move>0)of else other(of);addSignal("P4",t,String.format(Locale.US,"opening ${name(of)} %.2f → first-ball %.2f (%.2f) → support ${name(t)}",oo,fb,move))}else notes+=String.format(Locale.US,"P4: movement %.2f → no signal (threshold > 0.10)",abs(move))}else notes+="P4: insufficient opening/first-ball odds inputs"

            // P5
            if(p5.selectedItemPosition==1&&batting in 1..2)addSignal("P5",other(batting),"collapse + recovery → CHASE")
            if(p5.selectedItemPosition==2&&batting in 1..2)addSignal("P5",batting,"steady/slower innings → DEFEND")
            if(p5.selectedItemPosition>0&&batting==0)notes+="P5: batting-first team required"

            // P6 FINALIZED: baseline = PRE-FIRST-BALL odds; +/-0.0065 per run applies to the CHASING team.
            var p6Expected:Double?=null; var p6Current:Double?=null; var p6Diff:Double?=null
            if(of in 1..2&&oo!=null&&oo>1&&diff!=null&&moreLess!=null&&batting in 1..2&&cf in 1..2&&co!=null&&co>1){
                // moreLess: +1 means first innings MORE than Lambi, -1 means LESS.
                // Chasing team gets -0.0065/run when score is MORE; +0.0065/run when LESS.
                val chasingAdjustment = -moreLess * diff * 0.0065
                val openingFavouriteAdjustment = if(of==other(batting)) chasingAdjustment else -chasingAdjustment
                val baselineProbability = 1.0 / oo
                val expectedProbability = max(0.01,min(0.99,baselineProbability + openingFavouriteAdjustment))
                p6Expected=1.0/expectedProbability
                p6Current=if(cf==of){co}else{val oppositeProbability=1.0/co;if(oppositeProbability<0.99)1.0/(1.0-oppositeProbability)else 99.0}
                p6Diff=p6Current-p6Expected
                if(abs(p6Diff)>0.10){val t=if(p6Diff<0)of else other(of);addSignal("P6",t,String.format(Locale.US,"pre-first-ball ${name(of)} %.2f → expected %.2f; market-implied %.2f (diff %.2f) → support ${name(t)}",oo,p6Expected,p6Current,p6Diff))}else notes+=String.format(Locale.US,"P6: expected %.2f vs market-implied %.2f → NO SIGNAL (difference %.2f; threshold > 0.10)",p6Expected,p6Current,p6Diff)
            } else notes+="P6: requires opening favourite, pre-first-ball odds, batting-first team, innings-break favourite/odds and Lambi difference"

            val p3=signals.filter{it.pattern=="P3"}; val p3Winner=if(p3.size==1)p3[0].team else 0
            val core=signals.filter{it.pattern=="P1"||it.pattern=="P2"||it.pattern=="P5"}; val coreFinal=if(p3Winner!=0)p3Winner else run{val filtered=if(p5.selectedItemPosition>0)core.filter{it.pattern!="P1"}else core;val av=filtered.count{it.team==1};val bv=filtered.count{it.team==2};if(av>bv)1 else if(bv>av)2 else 0}
            val market=signals.filter{it.pattern=="P4"||it.pattern=="P6"}; val mvA=market.count{it.team==1};val mvB=market.count{it.team==2};val marketFinal=if(mvA>mvB)1 else if(mvB>mvA)2 else 0
            val finalTeam:Int;val status:String
            if(p3Winner!=0){finalTeam=p3Winner;status="P3 OVERRIDE"}else if(coreFinal!=0&&marketFinal!=0&&coreFinal!=marketFinal){finalTeam=coreFinal;status="CONFLICT — CORE vs MARKET"}else{finalTeam=if(coreFinal!=0)coreFinal else marketFinal;status=if(coreFinal!=0&&marketFinal==coreFinal)"ALIGNED — CORE + MARKET"else if(coreFinal!=0)"CORE SIGNAL"else if(marketFinal!=0)"MARKET SIGNAL"else"NO CLEAR SIGNAL"}
            val totalApplicable=signals.size;val agreeing=if(finalTeam==0)0 else signals.count{it.team==finalTeam};val opposing=if(finalTeam==0)0 else signals.count{it.team!=finalTeam};val confidence=when{finalTeam==0->0;status=="P3 OVERRIDE"->85;status.startsWith("CONFLICT")->35;totalApplicable==0->0;else->min(90,50+abs(agreeing-opposing)*10)}

            resultCard.removeAllViews(); resultCard.visibility=View.VISIBLE
            val resultColor=when{finalTeam==0->muted;status.startsWith("CONFLICT")->amber;else->green}
            val resultSoft=when{finalTeam==0->Color.rgb(240,243,246);status.startsWith("CONFLICT")->amberSoft;else->greenSoft}
            val badge=TextView(this).apply{text=if(finalTeam==0)"NO SIGNAL" else name(finalTeam).uppercase(Locale.US);textSize=12f;typeface=Typeface.DEFAULT_BOLD;setTextColor(resultColor);gravity=Gravity.CENTER;setPadding(dp(12),dp(7),dp(12),dp(7));background=bg(resultSoft,20)}
            val topLine=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
            topLine.addView(badge,LinearLayout.LayoutParams(0,-2,1f))
            val conf=TextView(this).apply{text=if(confidence==0)"—" else "$confidence/100";textSize=14f;typeface=Typeface.DEFAULT_BOLD;setTextColor(navy);gravity=Gravity.CENTER;setPadding(dp(10),dp(7),dp(10),dp(7));background=stroke(Color.WHITE,line,1,12)}
            topLine.addView(conf,LinearLayout.LayoutParams(dp(82),dp(42)).apply{leftMargin=dp(8)}); resultCard.addView(topLine,lp(12))
            resultCard.addView(TextView(this).apply{text=status;textSize=20f;typeface=Typeface.DEFAULT_BOLD;setTextColor(navy)},lp(4))
            resultCard.addView(TextView(this).apply{text="Core: ${if(coreFinal==0)"No clear signal" else name(coreFinal)}    •    Market: ${if(marketFinal==0)"No clear signal" else name(marketFinal)}";textSize=12.5f;setTextColor(muted)},lp(14))
            if(status.startsWith("CONFLICT"))resultCard.addView(TextView(this).apply{text="⚠ Core and market patterns disagree — treat as low confidence.";textSize=12f;setTextColor(amber);setPadding(dp(10),dp(9),dp(10),dp(9));background=bg(amberSoft,10)},lp(12))

            resultCard.addView(title("Pattern details"),lp(8))
            val grouped=listOf("P3","P5","P1","P2","P4","P6")
            for(g in grouped){signals.filter{it.pattern==g}.forEach{sig->
                val r=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.TOP;setPadding(dp(10),dp(9),dp(10),dp(9));background=bg(Color.rgb(248,250,252),11)}
                val tag=TextView(this).apply{text=sig.pattern;textSize=10f;typeface=Typeface.DEFAULT_BOLD;setTextColor(blue);gravity=Gravity.CENTER;setPadding(dp(7),dp(5),dp(7),dp(5));background=bg(blueSoft,8)}
                r.addView(tag,LinearLayout.LayoutParams(dp(36),dp(30)).apply{rightMargin=dp(8)})
                r.addView(TextView(this).apply{text="${name(sig.team)}  •  ${sig.text}";textSize=12f;setTextColor(textDark);setLineSpacing(1f,1.05f)},LinearLayout.LayoutParams(0,-2,1f))
                resultCard.addView(r,lp(6))
            }}
            if(notes.isNotEmpty()){resultCard.addView(title("Notes"),lp(6));notes.forEach{resultCard.addView(TextView(this).apply{text="• $it";textSize=11.5f;setTextColor(muted);setLineSpacing(1f,1.05f)},lp(4))}}
            resultCard.addView(title("Match snapshot"),lp(6))
            resultCard.addView(TextView(this).apply{text="First innings: ${sc?:"—"}  •  ${if(length.selectedItemPosition==0)"20 overs" else "shortened"}\nBatting first: ${if(batting==1)a else if(batting==2)b else "—"}\nInnings-break favourite: ${if(cf in 1..2)name(cf) else "—"}";textSize=12f;setTextColor(muted);setLineSpacing(1f,1.1f)},lp(8))
            if(p6Expected!=null&&p6Current!=null)resultCard.addView(TextView(this).apply{text=String.format(Locale.US,"P6  •  expected odds %.2f  •  market-implied %.2f  •  difference %.2f",p6Expected,p6Current,p6Diff);textSize=12f;typeface=Typeface.DEFAULT_BOLD;setTextColor(navy);setPadding(dp(10),dp(10),dp(10),dp(10));background=bg(blueSoft,10)},lp(8))
            resultCard.addView(TextView(this).apply{text="Experimental strategy analysis — not a guaranteed probability or outcome.";textSize=10.5f;setTextColor(muted);gravity=Gravity.CENTER},lp(0))

            last=buildString{append("FINAL ANALYSIS\n\n");append(if(finalTeam==0)"NO CLEAR SIGNAL" else name(finalTeam));append("\n$status\n\nConfidence: ${if(confidence==0)"—" else "$confidence/100"}\nCore: ${if(coreFinal==0)"No clear core signal" else name(coreFinal)}\nMarket: ${if(marketFinal==0)"No clear market signal" else name(marketFinal)}\n\nPATTERN DETAILS");signals.forEach{append("\n• ${it.pattern} → ${name(it.team)}: ${it.text}")};if(notes.isNotEmpty()){append("\n\nNOTES");notes.forEach{append("\n• $it")}}}
        }

        save.setOnClickListener{if(last.isBlank())Toast.makeText(this,"Run an analysis first",Toast.LENGTH_SHORT).show()else{historyView.text="✓ Last analysis saved in this session\n\n$last";Toast.makeText(this,"Analysis saved",Toast.LENGTH_SHORT).show()}}
        clear.setOnClickListener{teamA.text.clear();teamB.text.clear();score.text.clear();overs.text.clear();openOdds.text.clear();firstBallOdds.text.clear();currentOdds.text.clear();lambiDiff.text.clear();first.setSelection(0);length.setSelection(0);openFav.setSelection(0);currentFav.setSelection(0);lambiDir.setSelection(0);prevA.setSelection(0);prevB.setSelection(0);closeA.isChecked=false;closeB.isChecked=false;p5.setSelection(0);resultCard.removeAllViews();resultCard.visibility=View.GONE;historyView.text="";last=""}

        scroll.addView(root);setContentView(scroll)
    }
}
