package com.example.t20patternanalyzer.data.db
import androidx.room.Entity
import androidx.room.PrimaryKey
@Entity(tableName="match_predictions")
data class MatchPrediction(@PrimaryKey(autoGenerate=true) val id:Long=0,val matchId:String,val matchName:String,val teamA:String,val teamB:String,val finalTeam:Int,val status:String,val confidence:Int,val coreTeam:Int,val marketTeam:Int,val p1:String,val p2:String,val p3:String,val p4:String,val p5:String,val p6:String,val createdAt:Long=System.currentTimeMillis())
