package com.example.t20patternanalyzer.engine

import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

data class PatternInput(
    val teamA: String,
    val teamB: String,
    val battingFirst: Int,
    val firstInningsScore: Int?,
    val isTwentyOvers: Boolean,
    val openingFavourite: Int,
    val preFirstBallOdds: Double?,
    val firstBallOdds: Double?,
    val inningsBreakFavourite: Int,
    val inningsBreakOdds: Double?,
    val lambiType: String,
    val lambi: Double?,
    val teamAPreviousMatch: Int,
    val teamBPreviousMatch: Int,
    val teamAClose: Boolean,
    val teamBClose: Boolean,
    val p5: Int
)

data class Signal(val pattern: String, val team: Int, val text: String)
data class AnalysisResult(
    val finalTeam: Int,
    val status: String,
    val confidence: Int,
    val coreTeam: Int,
    val marketTeam: Int,
    val signals: List<Signal>,
    val notes: List<String>,
    val p6Expected: Double?,
    val p6Current: Double?,
    val p6Difference: Double?
)

object PatternEngine {
    fun analyze(i: PatternInput): AnalysisResult {
        val a=i.teamA.ifBlank { "Team A" }; val b=i.teamB.ifBlank { "Team B" }
        fun name(t:Int)=if(t==1)a else b
        fun other(t:Int)=if(t==1)2 else 1
        fun role(t:Int)=if(i.battingFirst==0)0 else if(t==i.battingFirst)2 else 1
        fun addSignal(list:MutableList<Signal>,p:String,t:Int,s:String){list += Signal(p,t,s)}
        val signals=mutableListOf<Signal>(); val notes=mutableListOf<String>()

        // P1 — preserved from the original T20 Pattern Analyzer.
        if(i.firstInningsScore!=null && i.isTwentyOvers && i.battingFirst in 1..2){
            val sc=i.firstInningsScore!!
            val tendency=when(sc){in 141..149,in 160..169,in 180..189,in 190..200,in 210..225->2;in 150..159,in 170..179,in 201..209->1;else->0}
            if(tendency==1)addSignal(signals,"P1",other(i.battingFirst),"$sc → CHASE tendency")
            if(tendency==2)addSignal(signals,"P1",i.battingFirst,"$sc → DEFEND tendency")
            if(tendency==0)notes += "P1: no signal (score outside 141–225)"
        } else notes += "P1: no signal (requires a completed 20-over innings)"

        // P2 — preserved, including the original opposite-signal ignore rule.
        fun p2(position:Int,team:Int):Int?{val r=role(team);if(position !in 1..4||r==0)return null;val won=position<=2;val prevRole=if(position==1||position==3)1 else 2;val support=if(won)r!=prevRole else r==prevRole;return if(support)team else other(team)}
        val p2a=p2(i.teamAPreviousMatch,1); val p2b=p2(i.teamBPreviousMatch,2)
        if(p2a!=null&&p2b!=null&&p2a!=p2b)notes += "P2: opposite team signals → P2 ignored entirely" else {
            if(p2a!=null)addSignal(signals,"P2",p2a,"${name(1)} previous ${if(i.teamAPreviousMatch<=2)"WIN" else "LOSS"} / ${if(i.teamAPreviousMatch==1||i.teamAPreviousMatch==3)"chasing" else "defending"} → support ${name(p2a)}")
            if(p2b!=null)addSignal(signals,"P2",p2b,"${name(2)} previous ${if(i.teamBPreviousMatch<=2)"WIN" else "LOSS"} / ${if(i.teamBPreviousMatch==1||i.teamBPreviousMatch==3)"chasing" else "defending"} → support ${name(p2b)}")
        }

        // P3 — preserved, including mutual qualification ignore rule.
        val p3a=i.teamAClose&&i.teamAPreviousMatch in 1..4; val p3b=i.teamBClose&&i.teamBPreviousMatch in 1..4
        if(p3a&&p3b)notes += "P3: both teams qualify → P3 ignored entirely" else {if(p3a)addSignal(signals,"P3",1,"close/fluctuating previous match → $a");if(p3b)addSignal(signals,"P3",2,"close/fluctuating previous match → $b")}

        // P4 — strict >0.10 movement threshold preserved.
        if(i.openingFavourite in 1..2&&i.preFirstBallOdds!=null&&i.firstBallOdds!=null&&i.preFirstBallOdds>1&&i.firstBallOdds>1){val move=i.firstBallOdds-i.preFirstBallOdds;if(abs(move)>0.10){val t=if(move>0)i.openingFavourite else other(i.openingFavourite);addSignal(signals,"P4",t,String.format(Locale.US,"opening ${name(i.openingFavourite)} %.2f → first-ball %.2f (%.2f) → support ${name(t)}",i.preFirstBallOdds,i.firstBallOdds,move))}else notes += String.format(Locale.US,"P4: movement %.2f → no signal (threshold > 0.10)",abs(move))}else notes += "P4: insufficient opening/first-ball odds inputs"

        // P5 — preserved manual mutually-exclusive signal.
        if(i.p5==1&&i.battingFirst in 1..2)addSignal(signals,"P5",other(i.battingFirst),"collapse + recovery → CHASE")
        if(i.p5==2&&i.battingFirst in 1..2)addSignal(signals,"P5",i.battingFirst,"steady/slower innings → DEFEND")
        if(i.p5>0&&i.battingFirst==0)notes += "P5: batting-first team required"

        // P6 — finalized rules: pre-first-ball baseline, automatic innings-score vs Lambi
        // difference, 0.0065/run adjustment, and strict >0.10 market-difference threshold.
        var p6Expected:Double?=null; var p6Current:Double?=null; var p6Diff:Double?=null
        val actualScore = i.firstInningsScore?.toDouble()
        val lambiDifference = if (actualScore != null && i.lambi != null) actualScore - i.lambi else null
        if(i.openingFavourite in 1..2&&i.preFirstBallOdds!=null&&i.preFirstBallOdds>1&&lambiDifference!=null&&i.battingFirst in 1..2&&i.inningsBreakFavourite in 1..2&&i.inningsBreakOdds!=null&&i.inningsBreakOdds>1){
            // LESS than Lambi → chasing team probability increases.
            // MORE than Lambi → chasing team probability decreases.
            val chasingAdjustment = -lambiDifference * 0.0065
            val openingFavouriteAdjustment=if(i.openingFavourite==other(i.battingFirst))chasingAdjustment else -chasingAdjustment
            val baselineProbability=1.0/i.preFirstBallOdds
            val expectedProbability=max(0.01,min(0.99,baselineProbability+openingFavouriteAdjustment))
            p6Expected=1.0/expectedProbability
            p6Current=if(i.inningsBreakFavourite==i.openingFavourite)i.inningsBreakOdds else {val oppositeProbability=1.0/i.inningsBreakOdds;if(oppositeProbability<0.99)1.0/(1.0-oppositeProbability)else 99.0}
            p6Diff=p6Current-p6Expected
            val direction=if(lambiDifference<0)"LESS" else if(lambiDifference>0)"MORE" else "EQUAL"
            if(abs(p6Diff)>0.10){val t=if(p6Diff<0)i.openingFavourite else other(i.openingFavourite);addSignal(signals,"P6",t,String.format(Locale.US,"${i.lambiType} Lambi %.1f; actual %.0f = %+.1f (%s); pre-first-ball ${name(i.openingFavourite)} %.2f → expected %.2f; market-implied %.2f (diff %.2f) → support ${name(t)}",i.lambi,i.firstInningsScore.toDouble(),lambiDifference,direction,i.preFirstBallOdds,p6Expected,p6Current,p6Diff))}else notes += String.format(Locale.US,"P6: Lambi %.1f vs actual %.0f = %+.1f (%s); expected %.2f vs market-implied %.2f → NO SIGNAL (difference %.2f; threshold > 0.10)",i.lambi,i.firstInningsScore.toDouble(),lambiDifference,direction,p6Expected,p6Current,p6Diff)
        } else notes += "P6: requires opening favourite, pre-first-ball odds, batting-first team, actual innings-break score, Lambi and innings-break market odds"

        val p3=signals.filter{it.pattern=="P3"}; val p3Winner=if(p3.size==1)p3[0].team else 0
        val core=signals.filter{it.pattern=="P1"||it.pattern=="P2"||it.pattern=="P5"}
        val coreFinal=if(p3Winner!=0)p3Winner else run{val filtered=if(i.p5>0)core.filter{it.pattern!="P1"}else core;val av=filtered.count{it.team==1};val bv=filtered.count{it.team==2};if(av>bv)1 else if(bv>av)2 else 0}
        val market=signals.filter{it.pattern=="P4"||it.pattern=="P6"};val mvA=market.count{it.team==1};val mvB=market.count{it.team==2};val marketFinal=if(mvA>mvB)1 else if(mvB>mvA)2 else 0
        val finalTeam:Int;val status:String
        if(p3Winner!=0){finalTeam=p3Winner;status="P3 OVERRIDE"}else if(coreFinal!=0&&marketFinal!=0&&coreFinal!=marketFinal){finalTeam=coreFinal;status="CONFLICT — CORE vs MARKET"}else{finalTeam=if(coreFinal!=0)coreFinal else marketFinal;status=if(coreFinal!=0&&marketFinal==coreFinal)"ALIGNED — CORE + MARKET"else if(coreFinal!=0)"CORE SIGNAL"else if(marketFinal!=0)"MARKET SIGNAL"else"NO CLEAR SIGNAL"}
        val total=signals.size;val agreeing=if(finalTeam==0)0 else signals.count{it.team==finalTeam};val opposing=if(finalTeam==0)0 else signals.count{it.team!=finalTeam}
        val confidence=when{finalTeam==0->0;status=="P3 OVERRIDE"->85;status.startsWith("CONFLICT")->35;total==0->0;else->min(90,50+abs(agreeing-opposing)*10)}
        return AnalysisResult(finalTeam,status,confidence,coreFinal,marketFinal,signals,notes,p6Expected,p6Current,p6Diff)
    }
}
