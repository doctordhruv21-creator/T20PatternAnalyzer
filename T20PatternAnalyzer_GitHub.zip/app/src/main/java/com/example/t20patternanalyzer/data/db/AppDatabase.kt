package com.example.t20patternanalyzer.data.db
import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
@Database(entities=[MatchPrediction::class],version=1,exportSchema=false)
abstract class AppDatabase:RoomDatabase(){abstract fun predictionDao():PredictionDao;companion object{ @Volatile private var INSTANCE:AppDatabase?=null; fun getInstance(context:Context):AppDatabase=INSTANCE?:synchronized(this){INSTANCE?:Room.databaseBuilder(context.applicationContext,AppDatabase::class.java,"t20_pattern_analyzer.db").build().also{INSTANCE=it}}}}
