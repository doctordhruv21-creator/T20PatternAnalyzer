package com.example.t20patternanalyzer

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.net.HttpURLConnection
import java.net.URL
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    private val navy = Color.rgb(15,30,48)
    private val navy2 = Color.rgb(25,49,76)
    private val blue = Color.rgb(38,126,218)
    private val pageBg = Color.rgb(245,247,250)
    private val white = Color.WHITE
    private val textDark = Color.rgb(29,38,49)
    private val muted = Color.rgb(101,113,126)
    private val line = Color.rgb(224,230,237)

    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    private fun bg(c:Int,r:Int=16)=GradientDrawable().apply{setColor(c);cornerRadius=dp(r).toFloat()}
    private fun stroke(c:Int, sc:Int=line,r:Int=16)=GradientDrawable().apply{setColor(c);setStroke(dp(1),sc);cornerRadius=dp(r).toFloat()}
    private fun lp(bottom:Int=0)=LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(bottom)}
    private fun title(t:String)=TextView(this).apply{text=t;textSize=18f;typeface=Typeface.DEFAULT_BOLD;setTextColor(navy)}
    private fun sub(t:String)=TextView(this).apply{text=t;textSize=12.5f;setTextColor(muted);setLineSpacing(1f,1.05f)}
    private fun card():LinearLayout=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(16),dp(16),dp(16));background=bg(white,18)}
    private fun add(p:LinearLayout,v:View,b:Int=10){p.addView(v,lp(b))}

    override fun onCreate(state:Bundle?) {
        super.onCreate(state)
        window.statusBarColor=navy
        window.navigationBarColor=pageBg
        val scroll=ScrollView(this).apply{setBackgroundColor(pageBg)}
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(14),dp(14),dp(14),dp(30))}

        val hero=LinearLayout(this).apply{
            orientation=LinearLayout.VERTICAL;setPadding(dp(20),dp(20),dp(20),dp(20))
            background=GradientDrawable(GradientDrawable.Orientation.TL_BR,intArrayOf(navy,navy2)).apply{cornerRadius=dp(24).toFloat()}
        }
        hero.addView(TextView(this).apply{text="T20 PATTERN ANALYZER";textSize=12f;typeface=Typeface.DEFAULT_BOLD;setTextColor(Color.rgb(174,201,227));letterSpacing=.14f},lp(5))
        hero.addView(TextView(this).apply{text="Live Match Center";textSize=25f;typeface=Typeface.DEFAULT_BOLD;setTextColor(white)},lp(5))
        hero.addView(TextView(this).apply{text="Live scores • match status • one-tap pattern prediction";textSize=12.5f;setTextColor(Color.rgb(208,222,236))},lp(0))
        add(root,hero,12)

        val nav=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;setPadding(dp(5),dp(5),dp(5),dp(5));background=bg(white,16)}
        val liveTab=TextView(this).apply{text="  LIVE MATCHES  ";textSize=13f;typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER;setTextColor(white);setPadding(dp(8),dp(12),dp(8),dp(12));background=bg(blue,12)}
        val predTab=TextView(this).apply{text="  PREDICTION  ";textSize=13f;typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER;setTextColor(navy);setPadding(dp(8),dp(12),dp(8),dp(12))}
        nav.addView(liveTab,LinearLayout.LayoutParams(0,-2,1f))
        nav.addView(predTab,LinearLayout.LayoutParams(0,-2,1f))
        add(root,nav,12)

        val status=TextView(this).apply{text="Loading live matches…";textSize=13f;setTextColor(muted);setPadding(dp(4),dp(8),dp(4),dp(8))}
        add(root,status,8)
        val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        add(root,list,12)

        val apiCard=card()
        add(apiCard,title("Connect your Cricket API"),8)
        add(apiCard,sub("This app uses Cricket Data / CricAPI's Current Matches endpoint. You need your own API key. The free plan currently allows 100 API hits/day; registered requests can provide near-live updates."))
        val key=android.widget.EditText(this).apply{
            hint="Paste your API key";textSize=14f;setSingleLine(true);setTextColor(textDark);setPadding(dp(12),dp(10),dp(12),dp(10));background=stroke(Color.rgb(249,250,252),line,12)
        }
        add(apiCard,key,8)
        val save=TextView(this).apply{text="SAVE API KEY & REFRESH";textSize=13f;typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER;setTextColor(white);setPadding(dp(10),dp(12),dp(10),dp(12));background=bg(blue,12)}
        add(apiCard,save,0)
        add(root,apiCard,12)

        val refresh=TextView(this).apply{text="↻  REFRESH LIVE SCORES";textSize=13f;typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER;setTextColor(navy);setPadding(dp(10),dp(13),dp(10),dp(13));background=stroke(white,line,14)}
        add(root,refresh,12)

        val prefs=getSharedPreferences("t20_api",MODE_PRIVATE)
        key.setText(prefs.getString("api_key","") ?: "")

        fun prediction(){
            startActivity(android.content.Intent(this,PredictionActivity::class.java))
        }
        predTab.setOnClickListener{prediction()}

        fun matchCard(m:JSONObject):View{
            val c=card()
            val name=m.optString("name","Cricket Match")
            val statusText=m.optString("status","")
            val matchType=m.optString("matchType","").uppercase()
            add(c,TextView(this).apply{text=name;textSize=16f;typeface=Typeface.DEFAULT_BOLD;setTextColor(navy)},5)
            add(c,TextView(this).apply{text=if(matchType.isBlank())statusText else "$matchType  •  $statusText";textSize=11.5f;setTextColor(muted)},10)
            val scores=m.optJSONArray("score")
            if(scores!=null){
                for(i in 0 until scores.length()){
                    val sc=scores.optJSONObject(i) ?: continue
                    val team=sc.optString("inning","").substringBefore(" Inning")
                    val runs=sc.optInt("r",0); val w=sc.optInt("w",0); val ov=sc.optString("o","")
                    add(c,TextView(this).apply{text="$team   $runs/$w  ($ov ov)";textSize=14f;typeface=Typeface.DEFAULT_BOLD;setTextColor(textDark);setPadding(dp(8),dp(7),dp(8),dp(7));background=bg(Color.rgb(248,250,252),10)},4)
                }
            } else add(c,sub("Score details not available in current response."),5)
            val pred=TextView(this).apply{text="OPEN PREDICTION  〉";textSize=12f;typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER;setTextColor(blue);setPadding(dp(9),dp(10),dp(9),dp(10));background=bg(Color.rgb(232,242,253),10)}
            add(c,pred,0); pred.setOnClickListener{prediction()}
            return c
        }

        fun load(){
            val apiKey=key.text.toString().trim()
            if(apiKey.isBlank()){
                status.text="Add your API key below to load live matches."
                return
            }
            status.text="Fetching live matches…"
            list.removeAllViews()
            val progress=ProgressBar(this).apply{isIndeterminate=true}
            add(list,progress,12)
            Thread {
                try{
                    val url=URL("https://api.cricapi.com/v1/currentMatches?apikey="+java.net.URLEncoder.encode(apiKey,"UTF-8")+"&offset=0")
                    val conn=url.openConnection() as HttpURLConnection
                    conn.requestMethod="GET"; conn.connectTimeout=10000; conn.readTimeout=10000
                    val body=conn.inputStream.bufferedReader().use{it.readText()}
                    conn.disconnect()
                    val json=JSONObject(body)
                    val data=json.optJSONArray("data") ?: JSONArray()
                    runOnUiThread{
                        list.removeAllViews()
                        if(data.length()==0){
                            status.text="No current matches returned."
                        }else{
                            status.text="${data.length()} current match${if(data.length()==1)"" else "es"} • refresh when you want the latest score"
                            for(i in 0 until data.length()) add(list,matchCard(data.getJSONObject(i)),10)
                        }
                    }
                }catch(e:Exception){
                    runOnUiThread{
                        list.removeAllViews()
                        status.text="Could not load live scores."
                        Toast.makeText(this,"API error: ${e.message ?: "check key/network"}",Toast.LENGTH_LONG).show()
                    }
                }
            }.start()
        }
        save.setOnClickListener{prefs.edit().putString("api_key",key.text.toString().trim()).apply();load()}
        refresh.setOnClickListener{load()}
        if((prefs.getString("api_key","") ?: "").isNotBlank()) load()
        else status.text="Ready — connect your Cricket Data API key to see live matches."

        scroll.addView(root);setContentView(scroll)
    }
}
