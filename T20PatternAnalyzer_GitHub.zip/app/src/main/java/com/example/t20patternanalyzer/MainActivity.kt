package com.example.t20patternanalyzer

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SportsCricket
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.t20patternanalyzer.data.api.CricketMatchDto
import com.example.t20patternanalyzer.engine.AnalysisResult
import com.example.t20patternanalyzer.engine.PatternInput
import com.example.t20patternanalyzer.ui.CricketViewModel
import kotlin.math.roundToInt

private val Navy = Color(0xFF0F172A)
private val Slate = Color(0xFF1E293B)
private val Green = Color(0xFF10B981)
private val Cyan = Color(0xFF38BDF8)
private val Muted = Color(0xFF94A3B8)
private val Red = Color(0xFFF87171)
private val Amber = Color(0xFFF59E0B)

private enum class Tab { LIVE, PREDICT, SAVED }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Navy
        window.navigationBarColor = Navy
        setContent {
            T20Theme {
                T20App()
            }
        }
    }
}

@Composable
private fun T20Theme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = androidx.compose.material3.darkColorScheme(
            primary = Green,
            secondary = Cyan,
            background = Navy,
            surface = Slate,
            onBackground = Color.White,
            onSurface = Color.White
        ),
        content = content
    )
}

@Composable
private fun T20App(vm: CricketViewModel = viewModel()) {
    var tab by rememberSaveable { mutableStateOf(Tab.LIVE) }
    var selectedMatch by remember { mutableStateOf<CricketMatchDto?>(null) }

    Scaffold(
        containerColor = Navy,
        bottomBar = {
            NavigationBar(containerColor = Slate) {
                NavigationBarItem(
                    selected = tab == Tab.LIVE,
                    onClick = { tab = Tab.LIVE },
                    icon = { Icon(Icons.Default.SportsCricket, contentDescription = "Live") },
                    label = { Text("LIVE") }
                )
                NavigationBarItem(
                    selected = tab == Tab.PREDICT,
                    onClick = { tab = Tab.PREDICT },
                    icon = { Icon(Icons.Default.Analytics, contentDescription = "Predict") },
                    label = { Text("PREDICT") }
                )
                NavigationBarItem(
                    selected = tab == Tab.SAVED,
                    onClick = { tab = Tab.SAVED },
                    icon = { Icon(Icons.Default.Save, contentDescription = "Saved") },
                    label = { Text("SAVED") }
                )
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            Header(
                tab = tab,
                onRefresh = {
                    if (tab == Tab.LIVE) {
                        vm.loadMatches()
                    }
                }
            )

            when (tab) {
                Tab.LIVE -> LiveScreen(vm) {
                    selectedMatch = it
                    tab = Tab.PREDICT
                }
                Tab.PREDICT -> PredictionScreen(vm, selectedMatch)
                Tab.SAVED -> SavedScreen(vm)
            }
        }
    }
}

@Composable
private fun Header(tab: Tab, onRefresh: () -> Unit) {
    Surface(color = Navy) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    "T20 PATTERN ANALYZER",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Black
                )
                Text(
                    when (tab) {
                        Tab.LIVE -> "LIVE MATCH CENTER"
                        Tab.PREDICT -> "P1–P6 DECISION ENGINE"
                        Tab.SAVED -> "OFFLINE SNAPSHOTS"
                    },
                    color = Cyan,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            IconButton(onClick = onRefresh) {
                Icon(Icons.Default.Refresh, contentDescription = "Refresh", tint = Cyan)
            }
        }
    }
}

@Composable
private fun Hero(title: String, subtitle: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Slate),
        shape = RoundedCornerShape(24.dp)
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Text(title, color = Green, fontSize = 11.sp, fontWeight = FontWeight.Black)
            Spacer(Modifier.height(5.dp))
            Text(subtitle, fontSize = 23.sp, lineHeight = 28.sp, fontWeight = FontWeight.Black)
            Spacer(Modifier.height(7.dp))
            Text(
                "Original P1–P6 engine • market-aware • conflict-aware",
                color = Muted,
                fontSize = 11.sp
            )
        }
    }
}

@Composable
private fun LiveScreen(vm: CricketViewModel, onPredict: (CricketMatchDto) -> Unit) {
    val matches by vm.matches.collectAsState()
    val loading by vm.loading.collectAsState()
    val error by vm.error.collectAsState()
    val apiKey by vm.apiKey.collectAsState()
    var keyInput by rememberSaveable { mutableStateOf("") }
    var showSettings by rememberSaveable { mutableStateOf(true) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(vertical = 14.dp)
    ) {
        item {
            Hero(
                "LIVE MATCH CENTER",
                "Connect your cricket API, choose a live T20, and open the real P1–P6 form."
            )
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Slate),
                shape = RoundedCornerShape(18.dp)
            ) {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Settings, contentDescription = null, tint = Cyan)
                        Spacer(Modifier.width(8.dp))
                        Text("CRICKET API", fontWeight = FontWeight.Bold)
                        Spacer(Modifier.weight(1f))
                        Text(
                            if (apiKey.isBlank()) "NOT CONNECTED" else "CONNECTED",
                            color = if (apiKey.isBlank()) Amber else Green,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    if (showSettings) {
                        Spacer(Modifier.height(10.dp))
                        OutlinedTextField(
                            value = keyInput,
                            onValueChange = { keyInput = it },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text("CricAPI API key") },
                            singleLine = true
                        )
                        Spacer(Modifier.height(8.dp))
                        Button(
                            onClick = {
                                vm.setApiKey(keyInput)
                                showSettings = false
                                vm.loadMatches()
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = Green)
                        ) {
                            Text("CONNECT & LOAD T20", color = Navy, fontWeight = FontWeight.Black)
                        }
                    } else {
                        Spacer(Modifier.height(8.dp))
                        OutlinedButton(
                            onClick = { showSettings = true },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("CHANGE API KEY")
                        }
                    }
                }
            }
        }

        if (loading) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                    horizontalArrangement = Arrangement.Center
                ) {
                    Text("Loading live matches…", color = Cyan, fontWeight = FontWeight.Bold)
                }
            }
        }

        error?.let { message ->
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF3B2430)),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Text(
                        message,
                        modifier = Modifier.padding(14.dp),
                        color = Red,
                        fontSize = 12.sp
                    )
                }
            }
        }

        if (matches.isEmpty() && !loading) {
            item {
                Text(
                    "No T20 matches loaded yet. Enter a valid API key and tap Connect.",
                    color = Muted,
                    modifier = Modifier.padding(8.dp)
                )
            }
        }

        items(matches, key = { it.id.orEmpty() }) { match ->
            LiveMatchCard(match, onPredict)
        }
    }
}

@Composable
private fun LiveMatchCard(match: CricketMatchDto, onPredict: (CricketMatchDto) -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Slate),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(
                match.name ?: "T20 Match",
                fontSize = 17.sp,
                fontWeight = FontWeight.Black
            )
            Spacer(Modifier.height(4.dp))
            Text(
                match.status ?: "Status unavailable",
                color = Cyan,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(12.dp))

            match.score.takeLast(2).forEach { score ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(score.inning ?: "Innings", color = Muted, fontSize = 11.sp)
                    Text(
                        "${score.r ?: 0}/${score.w ?: 0}  (${score.o ?: 0.0})",
                        fontWeight = FontWeight.Black
                    )
                }
                Spacer(Modifier.height(4.dp))
            }

            Spacer(Modifier.height(10.dp))
            Button(
                onClick = { onPredict(match) },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Green)
            ) {
                Text("OPEN P1–P6 PREDICTION", color = Navy, fontWeight = FontWeight.Black)
            }
        }
    }
}

@Composable
private fun PredictionScreen(vm: CricketViewModel, match: CricketMatchDto?) {
    val teams = match?.teams.orEmpty()
    var teamA by rememberSaveable(match?.id) { mutableStateOf(teams.getOrNull(0) ?: "Team A") }
    var teamB by rememberSaveable(match?.id) { mutableStateOf(teams.getOrNull(1) ?: "Team B") }
    var battingFirst by rememberSaveable(match?.id) { mutableIntStateOf(0) }
    var firstScore by rememberSaveable(match?.id) {
        mutableStateOf(match?.score?.firstOrNull()?.r?.toString().orEmpty())
    }
    var isTwentyOvers by rememberSaveable { mutableStateOf(true) }

    var openingFavourite by rememberSaveable { mutableIntStateOf(0) }
    var preFirstBallOdds by rememberSaveable { mutableStateOf("") }
    var firstBallOdds by rememberSaveable { mutableStateOf("") }
    var inningsBreakFavourite by rememberSaveable { mutableIntStateOf(0) }
    var inningsBreakOdds by rememberSaveable { mutableStateOf("") }
    var scoreVsLambi by rememberSaveable { mutableIntStateOf(0) }
    var runDifference by rememberSaveable { mutableStateOf("") }

    var teamAPreviousMatch by rememberSaveable { mutableIntStateOf(0) }
    var teamBPreviousMatch by rememberSaveable { mutableIntStateOf(0) }
    var teamAClose by rememberSaveable { mutableStateOf(false) }
    var teamBClose by rememberSaveable { mutableStateOf(false) }
    var p5 by rememberSaveable { mutableIntStateOf(0) }

    var target by rememberSaveable { mutableFloatStateOf(160f) }
    var oversLeft by rememberSaveable { mutableFloatStateOf(10f) }
    var wicketsLost by rememberSaveable { mutableFloatStateStateOfCompat(3f) }
    var userWeighting by rememberSaveable { mutableFloatStateOf(0.65f) }

    var result by remember { mutableStateOf<AnalysisResult?>(null) }

    val scenario = (
        (
            0.5f +
                (target - 160f) / 240f -
                (20f - oversLeft) / 100f -
                wicketsLost / 45f
            ) * userWeighting +
                0.5f * (1f - userWeighting)
        ).coerceIn(0.02f, 0.98f)

    val animatedScenario by animateFloatAsState(
        targetValue = scenario,
        animationSpec = tween(450),
        label = "whatIfProbability"
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(bottom = 20.dp)
    ) {
        item {
            Hero(
                "PATTERN LAB",
                match?.name ?: "Manual match analysis"
            )
        }

        item {
            Section("MATCH SETUP") {
                TextFieldLine("TEAM A", teamA) { teamA = it }
                TextFieldLine("TEAM B", teamB) { teamB = it }
                Choice(
                    "BATTING FIRST",
                    battingFirst,
                    listOf("Select", "Team A", "Team B")
                ) { battingFirst = it }
                NumberField("FIRST-INNINGS SCORE", firstScore) { firstScore = it }
                Choice(
                    "INNINGS LENGTH",
                    if (isTwentyOvers) 0 else 1,
                    listOf("20 overs", "Shortened — under 20 overs")
                ) { isTwentyOvers = it == 0 }
            }
        }

        item {
            Section("MARKET INPUTS") {
                Choice(
                    "OPENING FAVOURITE",
                    openingFavourite,
                    listOf("Select", "Team A", "Team B")
                ) { openingFavourite = it }
                NumberField("PRE-FIRST-BALL ODDS", preFirstBallOdds) {
                    preFirstBallOdds = it
                }
                NumberField("FIRST-BALL ODDS", firstBallOdds) {
                    firstBallOdds = it
                }
                Text(
                    "P4 uses opening → first-ball movement. Signal threshold is strictly > 0.10.",
                    color = Muted,
                    fontSize = 11.sp
                )
                Spacer(Modifier.height(8.dp))
                Choice(
                    "INNINGS-BREAK FAVOURITE",
                    inningsBreakFavourite,
                    listOf("Select", "Team A", "Team B")
                ) { inningsBreakFavourite = it }
                NumberField("INNINGS-BREAK ODDS (P6)", inningsBreakOdds) {
                    inningsBreakOdds = it
                }
                Choice(
                    "SCORE VS LAMBI",
                    scoreVsLambi,
                    listOf("Select", "More than Lambi", "Less than Lambi")
                ) { scoreVsLambi = it }
                NumberField("RUN DIFFERENCE", runDifference) {
                    runDifference = it
                }
                Text(
                    "P6: pre-first-ball baseline • 0.0065/run direction • >0.10 odds-difference threshold.",
                    color = Cyan,
                    fontSize = 11.sp
                )
            }
        }

        item {
            Section("PREVIOUS MATCH — P2 / P3") {
                Choice(
                    "TEAM A PREVIOUS MATCH",
                    teamAPreviousMatch,
                    listOf(
                        "Unknown",
                        "Won — chasing",
                        "Won — defending",
                        "Lost — chasing",
                        "Lost — defending"
                    )
                ) { teamAPreviousMatch = it }
                Choice(
                    "TEAM B PREVIOUS MATCH",
                    teamBPreviousMatch,
                    listOf(
                        "Unknown",
                        "Won — chasing",
                        "Won — defending",
                        "Lost — chasing",
                        "Lost — defending"
                    )
                ) { teamBPreviousMatch = it }
                CheckLine("Team A close / volatile previous match", teamAClose) {
                    teamAClose = it
                }
                CheckLine("Team B close / volatile previous match", teamBClose) {
                    teamBClose = it
                }
            }
        }

        item {
            Section("P5 — FIRST-INNINGS SHAPE") {
                Choice(
                    "P5 SIGNAL",
                    p5,
                    listOf(
                        "No P5 signal",
                        "Collapse + recovery → CHASE",
                        "Steady / slower innings → DEFEND"
                    )
                ) { p5 = it }
            }
        }

        item {
            Section("WHAT-IF SIMULATOR") {
                Text(
                    "Scenario gauge is separate from the original P1–P6 engine.",
                    color = Muted,
                    fontSize = 11.sp
                )
                SliderLine("TARGET SCORE", target, "${target.roundToInt()}", 80f..240f) {
                    target = it
                }
                SliderLine("OVERS LEFT", oversLeft, "%.1f".format(oversLeft), 0f..20f) {
                    oversLeft = it
                }
                SliderLine(
                    "WICKETS LOST",
                    wicketsLost,
                    "${wicketsLost.roundToInt()}",
                    0f..10f
                ) {
                    wicketsLost = it
                }
                SliderLine(
                    "USER WEIGHTING",
                    userWeighting,
                    "${(userWeighting * 100).roundToInt()}%",
                    0f..1f
                ) {
                    userWeighting = it
                }
                ProbabilityGauge(animatedScenario)
            }
        }

        item {
            Button(
                onClick = {
                    result = vm.analyze(
                        PatternInput(
                            teamA = teamA,
                            teamB = teamB,
                            battingFirst = battingFirst,
                            firstInningsScore = firstScore.toIntOrNull(),
                            isTwentyOvers = isTwentyOvers,
                            openingFavourite = openingFavourite,
                            preFirstBallOdds = preFirstBallOdds.toDoubleOrNull(),
                            firstBallOdds = firstBallOdds.toDoubleOrNull(),
                            inningsBreakFavourite = inningsBreakFavourite,
                            inningsBreakOdds = inningsBreakOdds.toDoubleOrNull(),
                            scoreVsLambi = scoreVsLambi,
                            runDifference = runDifference.toDoubleOrNull(),
                            teamAPreviousMatch = teamAPreviousMatch,
                            teamBPreviousMatch = teamBPreviousMatch,
                            teamAClose = teamAClose,
                            teamBClose = teamBClose,
                            p5 = p5
                        )
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Green)
            ) {
                Text("RUN ORIGINAL P1–P6 ENGINE  →", color = Navy, fontWeight = FontWeight.Black)
            }
        }

        result?.let { analysis ->
            item {
                ResultCard(teamA, teamB, analysis)
            }
            item {
                Button(
                    onClick = {
                        vm.save(
                            match,
                            PatternInput(
                                teamA,
                                teamB,
                                battingFirst,
                                firstScore.toIntOrNull(),
                                isTwentyOvers,
                                openingFavourite,
                                preFirstBallOdds.toDoubleOrNull(),
                                firstBallOdds.toDoubleOrNull(),
                                inningsBreakFavourite,
                                inningsBreakOdds.toDoubleOrNull(),
                                scoreVsLambi,
                                runDifference.toDoubleOrNull(),
                                teamAPreviousMatch,
                                teamBPreviousMatch,
                                teamAClose,
                                teamBClose,
                                p5
                            ),
                            analysis
                        )
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Cyan)
                ) {
                    Icon(Icons.Default.Save, contentDescription = null, tint = Navy)
                    Spacer(Modifier.width(7.dp))
                    Text("SAVE SNAPSHOT OFFLINE", color = Navy, fontWeight = FontWeight.Black)
                }
            }
        }
    }
}

@Composable
private fun Section(
    title: String,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Slate),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(title, color = Cyan, fontWeight = FontWeight.Black, fontSize = 11.sp)
            Spacer(Modifier.height(10.dp))
            content()
        }
    }
}

@Composable
private fun TextFieldLine(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 8.dp),
        label = { Text(label) },
        singleLine = true
    )
}

@Composable
private fun NumberField(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 8.dp),
        label = { Text(label) },
        singleLine = true
    )
}

@Composable
private fun Choice(
    label: String,
    value: Int,
    options: List<String>,
    onChange: (Int) -> Unit
) {
    var expanded by remember(label, value) { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 8.dp)
    ) {
        OutlinedButton(
            onClick = { expanded = true },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp)
        ) {
            Text(
                "$label  •  ${options.getOrElse(value) { options.first() }}",
                modifier = Modifier.fillMaxWidth()
            )
        }

        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
        ) {
            options.forEachIndexed { index, option ->
                DropdownMenuItem(
                    text = { Text(option) },
                    onClick = {
                        onChange(index)
                        expanded = false
                    }
                )
            }
        }
    }
}

@Composable
private fun CheckLine(
    text: String,
    checked: Boolean,
    onChange: (Boolean) -> Unit
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Checkbox(checked = checked, onCheckedChange = onChange)
        Text(text, color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun SliderLine(
    label: String,
    value: Float,
    valueText: String,
    range: ClosedFloatingPointRange<Float>,
    onChange: (Float) -> Unit
) {
    Row(modifier = Modifier.fillMaxWidth()) {
        Text(label, color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.weight(1f))
        Text(valueText, color = Cyan, fontWeight = FontWeight.Bold)
    }
    Slider(
        value = value,
        onValueChange = onChange,
        valueRange = range
    )
}

@Composable
private fun ProbabilityGauge(value: Float) {
    Text(
        "SCENARIO WIN PROBABILITY  ${(value * 100).roundToInt()}%",
        color = Green,
        fontWeight = FontWeight.Black,
        fontSize = 12.sp
    )
    Spacer(Modifier.height(6.dp))
    LinearProgressIndicator(
        progress = { value },
        modifier = Modifier
            .fillMaxWidth()
            .height(10.dp)
            .clip(RoundedCornerShape(8.dp)),
        color = Green,
        trackColor = Navy
    )
}

@Composable
private fun ResultCard(a: String, b: String, result: AnalysisResult) {
    fun teamName(team: Int): String = when (team) {
        1 -> a.ifBlank { "Team A" }
        2 -> b.ifBlank { "Team B" }
        else -> "—"
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = Slate),
        shape = RoundedCornerShape(22.dp)
    ) {
        Column(Modifier.padding(18.dp)) {
            Text("FINAL DECISION", color = Cyan, fontSize = 11.sp, fontWeight = FontWeight.Black)
            Spacer(Modifier.height(5.dp))
            Text(
                if (result.finalTeam == 0) "NO CLEAR SIGNAL" else teamName(result.finalTeam),
                fontSize = 29.sp,
                fontWeight = FontWeight.Black,
                color = if (result.status.startsWith("CONFLICT")) Amber else Green
            )
            Text(
                result.status,
                color = if (result.status.startsWith("CONFLICT")) Amber else Muted,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Metric("CONFIDENCE", "${result.confidence}/100")
                Metric("CORE", if (result.coreTeam == 0) "—" else teamName(result.coreTeam))
                Metric("MARKET", if (result.marketTeam == 0) "—" else teamName(result.marketTeam))
            }

            Spacer(Modifier.height(14.dp))
            Text("PATTERN DETAILS", fontWeight = FontWeight.Black)

            listOf("P3", "P5", "P1", "P2", "P4", "P6").forEach { pattern ->
                result.signals
                    .filter { it.pattern == pattern }
                    .forEach { signal ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 3.dp),
                            colors = CardDefaults.cardColors(containerColor = Navy),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Column(Modifier.padding(10.dp)) {
                                Text(
                                    "${signal.pattern}  •  ${teamName(signal.team)}",
                                    color = Cyan,
                                    fontWeight = FontWeight.Black,
                                    fontSize = 11.sp
                                )
                                Text(signal.text, fontSize = 11.sp, color = Color.White)
                            }
                        }
                    }
            }

            if (result.notes.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                Text("NOTES", fontWeight = FontWeight.Black)
                result.notes.forEach { note ->
                    Text(
                        "• $note",
                        color = Muted,
                        fontSize = 11.sp,
                        modifier = Modifier.padding(top = 3.dp)
                    )
                }
            }

            result.p6Expected?.let { expected ->
                Spacer(Modifier.height(8.dp))
                Text(
                    "P6  • expected %.2f  • market-implied %.2f  • difference %.2f"
                        .format(
                            expected,
                            result.p6Current ?: 0.0,
                            result.p6Difference ?: 0.0
                        ),
                    color = Cyan,
                    fontSize = 11.sp
                )
            }
        }
    }
}

@Composable
private fun Metric(key: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(key, color = Muted, fontSize = 9.sp)
        Text(value, color = Color.White, fontWeight = FontWeight.Black, fontSize = 13.sp)
    }
}

@Composable
private fun SavedScreen(vm: CricketViewModel) {
    val saved by vm.savedPredictions.collectAsState(initial = emptyList())

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(vertical = 14.dp)
    ) {
        item {
            Hero(
                "OFFLINE VAULT",
                "Saved P1–P6 decisions remain available without the network."
            )
        }

        if (saved.isEmpty()) {
            item {
                Text("No snapshots yet.", color = Muted, modifier = Modifier.padding(16.dp))
            }
        }

        items(saved, key = { it.id }) { prediction ->
            Card(
                colors = CardDefaults.cardColors(containerColor = Slate),
                shape = RoundedCornerShape(18.dp)
            ) {
                Column(Modifier.padding(15.dp)) {
                    Text(prediction.matchName, fontWeight = FontWeight.Black)
                    Text(
                        "${prediction.teamA} vs ${prediction.teamB}",
                        color = Muted,
                        fontSize = 11.sp
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        when (prediction.finalTeam) {
                            1 -> prediction.teamA
                            2 -> prediction.teamB
                            else -> "NO CLEAR SIGNAL"
                        },
                        color = Green,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black
                    )
                    Text(
                        "${prediction.status} • confidence ${prediction.confidence}/100",
                        color = Cyan,
                        fontSize = 11.sp
                    )
                    Spacer(Modifier.height(7.dp))
                    Button(
                        onClick = { vm.delete(prediction.id) },
                        colors = ButtonDefaults.buttonColors(containerColor = Navy)
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = null, tint = Red)
                        Spacer(Modifier.width(5.dp))
                        Text("DELETE", color = Red, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun mutableFloatStateStatefulCompat(initial: Float): androidx.compose.runtime.MutableFloatState {
    return androidx.compose.runtime.mutableFloatStateOf(initial)
}
