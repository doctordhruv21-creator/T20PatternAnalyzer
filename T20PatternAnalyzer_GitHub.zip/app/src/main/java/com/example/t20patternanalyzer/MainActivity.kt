package com.example.t20patternanalyzer

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class MainActivity : Activity() {
    private lateinit var resultView: TextView
    private lateinit var historyView: TextView

    private val navy = Color.rgb(16, 36, 61)
    private val blue = Color.rgb(30, 136, 229)
    private val green = Color.rgb(46, 125, 50)
    private val red = Color.rgb(198, 40, 40)
    private val amber = Color.rgb(230, 126, 34)
    private val textDark = Color.rgb(35, 43, 52)
    private val muted = Color.rgb(100, 110, 120)
    private val cardBg = Color.WHITE
    private val pageBg = Color.rgb(245, 247, 250)

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun rounded(color: Int, radius: Int = 18) = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    private fun card() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(16), dp(18), dp(16)); background = rounded(cardBg) }
    private fun add(p: LinearLayout, c: View, bottom: Int = 10) { p.addView(c, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(bottom) }) }
    private fun label(t: String) = TextView(this).apply { text = t; textSize = 13f; typeface = Typeface.DEFAULT_BOLD; setTextColor(muted) }
    private fun sectionTitle(t: String, s: String? = null): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        add(this, TextView(this@MainActivity).apply { text = t; textSize = 18f; typeface = Typeface.DEFAULT_BOLD; setTextColor(navy) }, if (s == null) 0 else 4)
        if (s != null) add(this, TextView(this@MainActivity).apply { text = s; textSize = 12f; setTextColor(muted) }, 0)
    }
    private fun textInput(h: String) = EditText(this).apply { hint = h; setSingleLine(true); textSize = 16f; setPadding(dp(12), dp(8), dp(12), dp(8)); inputType = InputType.TYPE_CLASS_TEXT; background = rounded(Color.rgb(247,249,252), 12) }
    private fun numberInput(h: String) = EditText(this).apply { hint = h; setSingleLine(true); textSize = 16f; setPadding(dp(12), dp(8), dp(12), dp(8)); inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL; background = rounded(Color.rgb(247,249,252), 12) }
    private fun spinner(o: Array<String>) = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, o); background = rounded(Color.rgb(247,249,252), 12); minimumHeight = dp(48) }

    private data class Signal(val pattern: String, val team: Int, val text: String)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val scroll = ScrollView(this).apply { setBackgroundColor(pageBg) }
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(28)) }

        val header = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20),dp(22),dp(20),dp(22)); background = rounded(navy,22) }
        add(header, TextView(this).apply { text="T20 Pattern Analyzer"; textSize=27f; typeface=Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE) },4)
        add(header, TextView(this).apply { text="V5  •  P1–P6 strategy engine  •  Conflict-aware analysis"; textSize=13f; setTextColor(Color.rgb(205,220,235)) },0)
        add(root, header,12)

        val match = card(); add(match, sectionTitle("🏏  Match setup", "Enter the first-innings information"),12)
        val teamA=textInput("Team A"); val teamB=textInput("Team B")
        add(match,label("Teams"),5); add(match,teamA,7); add(match,teamB,10)
        add(match,label("Who batted first?"),5)
        val first = spinner(arrayOf("Select batting-first team","Team A","Team B")); add(match,first,10)
        add(match,label("First-innings score"),5)
        val score=numberInput("e.g. 147"); add(match,score,10)
        add(match,label("Innings length"),5)
        val length=spinner(arrayOf("20 overs","Shortened — under 20 overs")); add(match,length,10)
        val overs=numberInput("Overs actually played, e.g. 17.4"); add(match,overs,0)
        add(root,match,12)

        val odds=card(); add(odds,sectionTitle("💹  Odds inputs","Opening odds, first-ball movement and innings-break market"),12)
        add(odds,label("Opening favourite"),5)
        val openFav=spinner(arrayOf("Select opening favourite","Team A","Team B")); add(odds,openFav,8)
        val openOdds=numberInput("Opening odds, e.g. 1.50"); add(odds,openOdds,12)

        add(odds,label("First-ball odds — same opening favourite"),5)
        val firstBallOdds=numberInput("First-ball odds, e.g. 1.70"); add(odds,firstBallOdds,12)
        add(odds,TextView(this).apply { text="P4: movement > 0.10 = signal. Drift supports original favourite; shorten supports the other team."; textSize=12f; setTextColor(muted) },12)

        add(odds,label("Innings-break current favourite"),5)
        val currentFav=spinner(arrayOf("Select current favourite","Team A","Team B")); add(odds,currentFav,8)
        val currentOdds=numberInput("Current odds, e.g. 1.30"); add(odds,currentOdds,12)

        add(odds,label("Score vs Lambi"),5)
        val lambiDir=spinner(arrayOf("Select: more or less than Lambi","More than Lambi","Less than Lambi")); add(odds,lambiDir,8)
        val lambiDiff=numberInput("Absolute difference from Lambi, e.g. 10"); add(odds,lambiDiff,3)
        add(odds,TextView(this).apply { text="P6: expected odds are calculated from opening odds and the Lambi adjustment (0.0065 per run), then compared with the current market."; textSize=12f; setTextColor(muted) },0)
        add(root,odds,12)

        val prev=card(); add(prev,sectionTitle("🔄  Previous match signals","P2 uses the immediately preceding match for each team"),12)
        add(prev,label("Team A — previous match"),5)
        val prevA=spinner(arrayOf("Unknown","Won — chasing","Won — defending","Lost — chasing","Lost — defending")); add(prev,prevA,10)
        add(prev,label("Team B — previous match"),5)
        val prevB=spinner(arrayOf("Unknown","Won — chasing","Won — defending","Lost — chasing","Lost — defending")); add(prev,prevB,10)
        val closeA=CheckBox(this).apply{text="Team A's previous match was very close / favourite changed multiple times";textSize=14f;setTextColor(textDark)}
        val closeB=CheckBox(this).apply{text="Team B's previous match was very close / favourite changed multiple times";textSize=14f;setTextColor(textDark)}
        add(prev,closeA,4); add(prev,closeB,0); add(root,prev,12)

        val shape=card(); add(shape,sectionTitle("📈  First-innings shape","P5 is manual and mutually exclusive"),12)
        val p5=spinner(arrayOf("No P5 signal","Collapse + recovery → CHASE","Steady / slower innings → DEFEND")); add(shape,p5,0); add(root,shape,12)

        val analyse=Button(this).apply{text="ANALYSE MATCH  →";textSize=16f;typeface=Typeface.DEFAULT_BOLD;setTextColor(Color.WHITE);background=rounded(blue,16);minimumHeight=dp(54)}
        add(root,analyse,12)
        resultView=TextView(this).apply{textSize=15f;setTextColor(textDark);setPadding(dp(18),dp(18),dp(18),dp(18));background=rounded(Color.WHITE,18)}; add(root,resultView,12)
        val save=Button(this).apply{text="SAVE LAST ANALYSIS";setTextColor(navy);background=rounded(Color.rgb(225,232,240),14);minimumHeight=dp(50)}; add(root,save,10)
        historyView=TextView(this).apply{textSize=13f;setTextColor(muted);setPadding(dp(18),dp(12),dp(18),dp(12))}; add(root,historyView,10)
        val clear=Button(this).apply{text="CLEAR FORM";setTextColor(navy);background=rounded(Color.rgb(232,235,239),14)}; add(root,clear,12)
        add(root,TextView(this).apply{text="⚠ Experimental analysis only. No bets are placed. Confidence is a signal-quality indicator, not a guaranteed probability.";textSize=12f;setTextColor(muted);gravity=Gravity.CENTER},0)

        var last=""
        analyse.setOnClickListener {
            val a=teamA.text.toString().trim().ifBlank{"Team A"}; val b=teamB.text.toString().trim().ifBlank{"Team B"}
            val sc=score.text.toString().toIntOrNull(); val oo=openOdds.text.toString().toDoubleOrNull(); val fb=firstBallOdds.text.toString().toDoubleOrNull(); val co=currentOdds.text.toString().toDoubleOrNull()
            val batting=first.selectedItemPosition; val of=openFav.selectedItemPosition; val cf=currentFav.selectedItemPosition
            val diff=lambiDiff.text.toString().toDoubleOrNull()?.let{abs(it)}; val ld=when(lambiDir.selectedItemPosition){1->1.0;2->-1.0;else->null}
            val signals=mutableListOf<Signal>(); val notes=mutableListOf<String>()
            fun name(t:Int)=if(t==1)a else b
            fun other(t:Int)=if(t==1)2 else 1
            fun addSignal(p:String,t:Int,s:String){signals+=Signal(p,t,s)}
            fun role(t:Int)=if(batting==0)0 else if(t==batting)2 else 1 // 1 chase, 2 defend

            // P1: only full 20-over first innings.
            if(sc!=null && length.selectedItemPosition==0 && batting in 1..2){
                val tendency=when(sc){in 141..149,in 160..169,in 180..189,in 190..200,in 210..225->2;in 150..159,in 170..179,in 201..209->1;else->0}
                if(tendency==1) addSignal("P1",other(batting),"$sc → CHASE tendency")
                if(tendency==2) addSignal("P1",batting,"$sc → DEFEND tendency")
                if(tendency==0) notes+="P1: no signal (score outside 141–225)"
            } else notes+="P1: no signal (requires a completed 20-over innings)"

            // P2 exact mapping, evaluated independently, then resolve opposite-team conflict.
            fun p2(position:Int, team:Int):Int? {
                val r=role(team); if(position !in 1..4 || r==0) return null
                val won=position<=2; val prevRole=if(position==1||position==3)1 else 2
                val support=if(won) r!=prevRole else r==prevRole
                return if(support) team else other(team)
            }
            val p2a=p2(prevA.selectedItemPosition,1); val p2b=p2(prevB.selectedItemPosition,2)
            if(p2a!=null && p2b!=null && p2a!=p2b){notes+="P2: opposite team signals → P2 ignored entirely"}
            else { if(p2a!=null)addSignal("P2",p2a,"${name(1)} previous ${if(prevA.selectedItemPosition<=2)"WIN" else "LOSS"} / ${if(prevA.selectedItemPosition==1||prevA.selectedItemPosition==3)"chasing" else "defending"} → support ${name(p2a)}"); if(p2b!=null)addSignal("P2",p2b,"${name(2)} previous ${if(prevB.selectedItemPosition<=2)"WIN" else "LOSS"} / ${if(prevB.selectedItemPosition==1||prevB.selectedItemPosition==3)"chasing" else "defending"} → support ${name(p2b)}") }

            // P3: manual applicability; both qualifying teams = ignore P3.
            val p3a=closeA.isChecked && prevA.selectedItemPosition in 1..4; val p3b=closeB.isChecked && prevB.selectedItemPosition in 1..4
            if(p3a && p3b) notes+="P3: both teams qualify → P3 ignored entirely" else {if(p3a)addSignal("P3",1,"close/fluctuating previous match → ${a}");if(p3b)addSignal("P3",2,"close/fluctuating previous match → ${b}")}

            // P4: opening favourite vs first-ball price, threshold strictly > 0.10.
            if(of in 1..2 && oo!=null && fb!=null && oo>1 && fb>1){
                val move=fb-oo; if(abs(move)>0.10){val t=if(move>0)of else other(of); addSignal("P4",t,String.format(Locale.US,"opening ${name(of)} %.2f → first-ball %.2f (%.2f) → support ${name(t)}",oo,fb,move))} else notes+=String.format(Locale.US,"P4: movement %.2f → no signal (threshold > 0.10)",abs(move))
            } else notes+="P4: insufficient opening/first-ball odds inputs"

            // P5: exactly one selected option.
            if(p5.selectedItemPosition==1 && batting in 1..2)addSignal("P5",other(batting),"collapse + recovery → CHASE")
            if(p5.selectedItemPosition==2 && batting in 1..2)addSignal("P5",batting,"steady/slower innings → DEFEND")
            if(p5.selectedItemPosition>0 && batting==0)notes+="P5: batting-first team required"

            // P6: calculate expected odds for opening favourite, then compare against CURRENT price of that same team.
            var p6Expected:Double?=null; var p6Current:Double?=null
            if(of in 1..2 && oo!=null && oo>1 && diff!=null && ld!=null){
                val prob=max(0.01,min(0.99,1.0/oo + diff*ld*0.0065)); p6Expected=1.0/prob
                if(cf==of && co!=null && co>1){
                    p6Current=co; val gap=co-p6Expected
                    if(abs(gap)>0.10){val t=if(gap<0)of else other(of); addSignal("P6",t,String.format(Locale.US,"expected ${name(of)} %.2f vs current %.2f (gap %.2f) → support ${name(t)}",p6Expected,co,gap))} else notes+=String.format(Locale.US,"P6: expected %.2f vs current %.2f → no signal (threshold > 0.10)",p6Expected,co)
                } else if(cf in 1..2 && cf!=of) notes+="P6: current favourite differs from opening favourite; enter the current price for the opening favourite to compare P6"
                else notes+="P6: select the innings-break favourite as the opening favourite to compare its current price"
            } else notes+="P6: insufficient opening odds + Lambi inputs"

            // P3 override. P5 replaces P1 in the core layer. P2 is already conflict-resolved.
            val p3=signals.filter{it.pattern=="P3"}
            val p3Winner=if(p3.size==1)p3[0].team else 0
            val core=signals.filter{it.pattern=="P1" || it.pattern=="P2" || it.pattern=="P5"}
            val coreFinal=if(p3Winner!=0)p3Winner else run {
                val filtered=if(p5.selectedItemPosition>0)core.filter{it.pattern!="P1"} else core
                val av=filtered.count{it.team==1}; val bv=filtered.count{it.team==2}; if(av>bv)1 else if(bv>av)2 else 0
            }
            val market=signals.filter{it.pattern=="P4"||it.pattern=="P6"}
            val mvA=market.count{it.team==1}; val mvB=market.count{it.team==2}; val marketFinal=if(mvA>mvB)1 else if(mvB>mvA)2 else 0

            val finalTeam:Int; val status:String
            if(p3Winner!=0){finalTeam=p3Winner;status="P3 OVERRIDE"}
            else if(coreFinal!=0 && marketFinal!=0 && coreFinal!=marketFinal){finalTeam=coreFinal;status="CONFLICT — core vs market"}
            else {finalTeam=if(coreFinal!=0)coreFinal else marketFinal;status=if(coreFinal!=0 && marketFinal==coreFinal)"ALIGNED — core + market" else if(coreFinal!=0)"CORE SIGNAL" else if(marketFinal!=0)"MARKET SIGNAL" else "NO CLEAR SIGNAL"}

            val totalApplicable=signals.size; val agreeing=if(finalTeam==0)0 else signals.count{it.team==finalTeam}; val opposing=if(finalTeam==0)0 else signals.count{it.team!=finalTeam}
            val confidence=when{finalTeam==0->0;status=="P3 OVERRIDE"->85;status.startsWith("CONFLICT")->35;totalApplicable==0->0;else->min(90,50+abs(agreeing-opposing)*10)}
            val p6line=if(p6Expected!=null){String.format(Locale.US,"\nP6 expected odds: %.2f%s",p6Expected,if(p6Current!=null)String.format(Locale.US,"  •  current: %.2f",p6Current) else "")}else ""
            val finalText=if(finalTeam==0)"NO CLEAR SIGNAL" else name(finalTeam)
            val result=buildString{
                append("FINAL ANALYSIS\n\n"); append(finalText); append("\n"); append(status); append("\n\n")
                append("Confidence: "); append(if(confidence==0)"—" else "$confidence/100"); append("\n")
                append("Core: "); append(if(coreFinal==0)"No clear core signal" else name(coreFinal)); append("\n")
                append("Market: "); append(if(marketFinal==0)"No clear market signal" else name(marketFinal)); append("\n")
                if(status.startsWith("CONFLICT"))append("⚠ Core and market patterns disagree — treat as low-confidence conflict.\n")
                append("\nPATTERN DETAILS")
                val grouped=listOf("P3","P5","P1","P2","P4","P6")
                for(g in grouped){val ss=signals.filter{it.pattern==g}; if(ss.isNotEmpty())ss.forEach{append("\n• ${it.pattern} → ${name(it.team)}: ${it.text}")}}
                if(notes.isNotEmpty()){append("\n\nNOTES");notes.forEach{append("\n• $it")}}
                append("\n\nMATCH SNAPSHOT\nFirst innings: ${sc?:"—"}  •  ${if(length.selectedItemPosition==0)"20 overs" else "shortened"}")
                append("\nBatting first: ${if(batting==1)a else if(batting==2)b else "—"}")
                if(diff!=null && ld!=null)append(String.format(Locale.US,"\nLambi: %s %.1f runs",if(ld>0)"MORE" else "LESS",diff))
                append(p6line)
                append("\n\nExperimental strategy analysis — not a guaranteed probability or outcome.")
            }
            last=result; resultView.text=result
        }

        save.setOnClickListener{if(last.isBlank())Toast.makeText(this,"Analyse a match first",Toast.LENGTH_SHORT).show() else {historyView.text="✓ Last analysis saved in this session\n\n$last";Toast.makeText(this,"Analysis saved",Toast.LENGTH_SHORT).show()}}
        clear.setOnClickListener{teamA.text.clear();teamB.text.clear();score.text.clear();overs.text.clear();openOdds.text.clear();firstBallOdds.text.clear();currentOdds.text.clear();lambiDiff.text.clear();first.setSelection(0);length.setSelection(0);openFav.setSelection(0);currentFav.setSelection(0);lambiDir.setSelection(0);prevA.setSelection(0);prevB.setSelection(0);closeA.isChecked=false;closeB.isChecked=false;p5.setSelection(0);resultView.text="";historyView.text="";last=""}
        scroll.addView(root); setContentView(scroll)
    }
}
