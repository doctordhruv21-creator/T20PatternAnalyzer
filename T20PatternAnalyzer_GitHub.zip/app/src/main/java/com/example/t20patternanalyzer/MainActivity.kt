package com.example.t20patternanalyzer

import android.app.Activity
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class MainActivity : Activity() {
    // Palette: deliberately dark, high-contrast and sport-analytics oriented.
    private val bg = Color.rgb(8, 13, 22)
    private val panel = Color.rgb(15, 23, 36)
    private val panel2 = Color.rgb(20, 30, 46)
    private val fieldBg = Color.rgb(11, 18, 29)
    private val line = Color.rgb(43, 57, 76)
    private val white = Color.WHITE
    private val text = Color.rgb(235, 241, 248)
    private val muted = Color.rgb(145, 158, 176)
    private val cyan = Color.rgb(64, 190, 255)
    private val cyanSoft = Color.rgb(19, 52, 70)
    private val green = Color.rgb(54, 211, 132)
    private val greenSoft = Color.rgb(19, 59, 46)
    private val amber = Color.rgb(255, 177, 66)
    private val amberSoft = Color.rgb(64, 46, 22)
    private val red = Color.rgb(255, 93, 104)
    private val redSoft = Color.rgb(65, 28, 34)

    private lateinit var resultCard: LinearLayout
    private lateinit var historyView: TextView
    private lateinit var runButton: Button

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun solid(color: Int, radius: Int = 16) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat()
    }
    private fun outlined(fill: Int = fieldBg, stroke: Int = line, radius: Int = 12) = GradientDrawable().apply {
        setColor(fill); setStroke(dp(1), stroke); cornerRadius = dp(radius).toFloat()
    }
    private fun params(bottom: Int = 0, top: Int = 0) = LinearLayout.LayoutParams(-1, -2).apply {
        bottomMargin = dp(bottom); topMargin = dp(top)
    }
    private fun add(parent: LinearLayout, child: View, bottom: Int = 10) = parent.addView(child, params(bottom))

    private fun label(s: String) = TextView(this).apply {
        text = s.uppercase(Locale.US); textSize = 10.5f; typeface = Typeface.DEFAULT_BOLD
        setTextColor(muted); letterSpacing = .10f
    }
    private fun heading(s: String, size: Float = 18f) = TextView(this).apply {
        text = s; textSize = size; typeface = Typeface.DEFAULT_BOLD; setTextColor(this@MainActivity.text)
    }
    private fun body(s: String) = TextView(this).apply {
        text = s; textSize = 12f; setTextColor(muted); setLineSpacing(0f, 1.08f)
    }
    private fun field(hint: String, number: Boolean = false) = EditText(this).apply {
        this.hint = hint; setSingleLine(true); textSize = 14.5f; setTextColor(this@MainActivity.text)
        setHintTextColor(Color.rgb(92, 108, 128)); setPadding(dp(13), dp(9), dp(13), dp(9))
        minimumHeight = dp(48)
        inputType = if (number) InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL else InputType.TYPE_CLASS_TEXT
        background = outlined(); includeFontPadding = false
    }
    private fun spinner(options: Array<String>) = Spinner(this).apply {
        adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, options)
        background = outlined(); minimumHeight = dp(48)
    }
    private fun twoCol(a: View, b: View, gap: Int = 8) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        addView(a, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(gap / 2) })
        addView(b, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(gap / 2) })
    }
    private fun fieldBlock(parent: LinearLayout, name: String, view: View, bottom: Int = 9) {
        add(parent, label(name), 4); add(parent, view, bottom)
    }
    private fun card(title: String, kicker: String, description: String): LinearLayout {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(15), dp(15), dp(15), dp(15)); background = solid(panel, 18)
        }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val badge = TextView(this).apply {
            text = kicker; textSize = 10f; typeface = Typeface.DEFAULT_BOLD; setTextColor(cyan)
            gravity = Gravity.CENTER; background = solid(cyanSoft, 10); setPadding(dp(9), dp(6), dp(9), dp(6)); letterSpacing = .06f
        }
        top.addView(badge, LinearLayout.LayoutParams(dp(54), dp(32)))
        val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(11), 0, 0, 0) }
        titles.addView(heading(title, 17f), params(2)); titles.addView(body(description), params())
        top.addView(titles, LinearLayout.LayoutParams(0, -2, 1f)); c.addView(top, params(14))
        return c
    }
    private fun infoPill(title: String, value: String, color: Int = cyan, fill: Int = cyanSoft) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(11), dp(9), dp(11), dp(9)); background = solid(fill, 12)
        addView(TextView(this@MainActivity).apply { text = title.uppercase(Locale.US); textSize = 9f; typeface = Typeface.DEFAULT_BOLD; setTextColor(muted); letterSpacing = .07f }, params(3))
        addView(TextView(this@MainActivity).apply { text = value; textSize = 14f; typeface = Typeface.DEFAULT_BOLD; setTextColor(color) }, params())
    }

    private data class Signal(val pattern: String, val team: Int, val text: String)
    private data class P6Result(val expectedOdds: Double, val marketImpliedOdds: Double, val difference: Double, val signalTeam: Int?)

    /**
     * Finalized P6 engine.
     * Baseline is the pre-first-ball price, never the pre-match price.
     * 0.0065 probability/run is applied to the chasing team; LESS than benchmark helps chase,
     * MORE than benchmark hurts chase. Market alignment requires an absolute odds gap > 0.10.
     */
    private fun calculateP6(
        openingFavourite: Int,
        preFirstBallOdds: Double,
        battingFirst: Int,
        moreThanBenchmark: Boolean,
        runDifference: Double,
        currentFavourite: Int,
        currentOdds: Double
    ): P6Result {
        val chasingAdjustment = if (moreThanBenchmark) -runDifference * 0.0065 else runDifference * 0.0065
        val openingFavouriteAdjustment = if (openingFavourite != battingFirst) chasingAdjustment else -chasingAdjustment
        val baselineProbability = 1.0 / preFirstBallOdds
        val expectedProbability = max(0.01, min(0.99, baselineProbability + openingFavouriteAdjustment))
        val expectedOdds = 1.0 / expectedProbability
        val marketProbability = 1.0 / currentOdds
        val marketImpliedOdds = if (currentFavourite == openingFavourite) currentOdds else {
            val openingFavouriteProbability = 1.0 - marketProbability
            if (openingFavouriteProbability < 0.99) 1.0 / openingFavouriteProbability else 99.0
        }
        val difference = marketImpliedOdds - expectedOdds
        val signal = when {
            difference < -0.10 -> openingFavourite
            difference > 0.10 -> if (openingFavourite == 1) 2 else 1
            else -> null
        }
        return P6Result(expectedOdds, marketImpliedOdds, difference, signal)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg; window.navigationBarColor = bg

        val scroll = ScrollView(this).apply { setBackgroundColor(bg); clipToPadding = false }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(14), dp(14), dp(34))
        }

        // HERO
        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(18), dp(18), dp(18))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(13, 32, 52), Color.rgb(10, 18, 30))).apply { cornerRadius = dp(24).toFloat() }
        }
        val brand = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val logo = TextView(this).apply {
            text = "P6"; textSize = 17f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.rgb(7, 20, 30)); gravity = Gravity.CENTER
            background = solid(cyan, 12)
        }
        brand.addView(logo, LinearLayout.LayoutParams(dp(48), dp(48)))
        val bt = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
        bt.addView(TextView(this).apply { text = "T20 PATTERN ANALYZER"; textSize = 10f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.rgb(126, 196, 231)); letterSpacing = .16f }, params(3))
        bt.addView(TextView(this).apply { text = "Decision Console"; textSize = 22f; typeface = Typeface.DEFAULT_BOLD; setTextColor(white) }, params())
        brand.addView(bt, LinearLayout.LayoutParams(0, -2, 1f)); hero.addView(brand, params(12))
        hero.addView(TextView(this).apply {
            text = "P1–P6  •  pattern layer  +  market layer  •  built for fast match reads"
            textSize = 12f; setTextColor(Color.rgb(173, 193, 214))
        }, params(14))
        val status = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(11), dp(9), dp(11), dp(9)); background = solid(Color.rgb(17, 38, 57), 12) }
        status.addView(TextView(this).apply { text = "●"; textSize = 12f; setTextColor(green) }, LinearLayout.LayoutParams(dp(22), -2))
        status.addView(TextView(this).apply { text = "ANALYSIS ONLY  ·  NO BETS ARE PLACED"; textSize = 10.5f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.rgb(185, 205, 224)); letterSpacing = .06f }, LinearLayout.LayoutParams(0, -2, 1f))
        hero.addView(status, params())
        add(root, hero, 12)

        // MATCH SETUP
        val match = card("Match setup", "01", "Define the two teams and the innings state.")
        fieldBlock(match, "TEAMS", twoCol(field("Team A"), field("Team B")), 9)
        val first = spinner(arrayOf("Select batting-first team", "Team A", "Team B")); fieldBlock(match, "BATTING FIRST", first, 9)
        fieldBlock(match, "FIRST-INNINGS SCORE", field("e.g. 159", true), 9)
        val length = spinner(arrayOf("20 overs", "Shortened — under 20 overs")); fieldBlock(match, "INNINGS LENGTH", length, 9)
        val overs = field("e.g. 17.4", true); fieldBlock(match, "OVERS ACTUALLY PLAYED", overs, 0)
        add(root, match, 10)

        // MARKET
        val odds = card("Market board", "02", "Capture the prices exactly as they existed around the first ball and innings break.")
        val openFav = spinner(arrayOf("Select opening favourite", "Team A", "Team B")); fieldBlock(odds, "OPENING FAVOURITE", openFav, 9)
        val openOdds = field("e.g. 1.52", true); fieldBlock(odds, "PRE-FIRST-BALL ODDS", openOdds, 4)
        add(odds, TextView(this).apply {
            text = "P6 BASELINE  •  This is the only opening price used by P6. Pre-match odds are ignored."
            textSize = 10.5f; setTextColor(cyan); setPadding(dp(10), dp(8), dp(10), dp(8)); background = solid(cyanSoft, 10)
        }, 10)
        val firstBallOdds = field("e.g. 1.53", true); fieldBlock(odds, "FIRST-BALL ODDS  ·  P4", firstBallOdds, 9)
        val currentFav = spinner(arrayOf("Select innings-break favourite", "Team A", "Team B")); fieldBlock(odds, "INNINGS-BREAK FAVOURITE", currentFav, 9)
        val currentOdds = field("e.g. 1.42", true); fieldBlock(odds, "INNINGS-BREAK ODDS  ·  P6", currentOdds, 9)
        val lambiDir = spinner(arrayOf("Select score vs Lambi / benchmark", "MORE than Lambi", "LESS than Lambi")); fieldBlock(odds, "SCORE VS BENCHMARK", lambiDir, 9)
        val lambiDiff = field("absolute run difference, e.g. 4", true); fieldBlock(odds, "RUN DIFFERENCE", lambiDiff, 0)
        add(root, odds, 10)

        // CONTEXT
        val prev = card("Context signals", "03", "P2 and P3 read the immediately previous match. P5 is the manual innings-shape override.")
        val prevA = spinner(arrayOf("Unknown", "Won — chasing", "Won — defending", "Lost — chasing", "Lost — defending")); fieldBlock(prev, "TEAM A · PREVIOUS MATCH", prevA, 8)
        val prevB = spinner(arrayOf("Unknown", "Won — chasing", "Won — defending", "Lost — chasing", "Lost — defending")); fieldBlock(prev, "TEAM B · PREVIOUS MATCH", prevB, 8)
        val closeA = CheckBox(this).apply { text = "Team A  ·  close / volatile previous match"; textSize = 12.5f; setTextColor(this@MainActivity.text); buttonTintList = ColorStateList.valueOf(cyan) }
        val closeB = CheckBox(this).apply { text = "Team B  ·  close / volatile previous match"; textSize = 12.5f; setTextColor(this@MainActivity.text); buttonTintList = ColorStateList.valueOf(cyan) }
        add(prev, closeA, 1); add(prev, closeB, 8)
        val p5 = spinner(arrayOf("No P5 signal", "Collapse + recovery  →  CHASE", "Steady / slower innings  →  DEFEND")); fieldBlock(prev, "P5 · FIRST-INNINGS SHAPE", p5, 0)
        add(root, prev, 10)

        // RUN
        runButton = Button(this).apply {
            text = "RUN FINAL ANALYSIS   →"; textSize = 14.5f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.rgb(5, 17, 27))
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(cyan, Color.rgb(99, 220, 255))).apply { cornerRadius = dp(16).toFloat() }
            minimumHeight = dp(58); stateListAnimator = null
        }
        add(root, runButton, 10)

        resultCard = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(16)); background = solid(panel, 20); visibility = View.GONE }
        add(root, resultCard, 10)
        val save = Button(this).apply {
            text = "SAVE LAST ANALYSIS"; textSize = 12f; typeface = Typeface.DEFAULT_BOLD; setTextColor(this@MainActivity.text); background = outlined(panel2, line, 13); minimumHeight = dp(48); stateListAnimator = null
        }
        add(root, save, 7)
        historyView = TextView(this).apply { textSize = 11.5f; setTextColor(muted); setPadding(dp(3), dp(3), dp(3), dp(3)); setLineSpacing(0f, 1.08f) }
        add(root, historyView, 7)
        val clear = Button(this).apply {
            text = "RESET FORM"; textSize = 11.5f; typeface = Typeface.DEFAULT_BOLD; setTextColor(muted); background = solid(Color.rgb(18, 27, 40), 13); minimumHeight = dp(46); stateListAnimator = null
        }
        add(root, clear, 12)
        add(root, TextView(this).apply {
            text = "P6 threshold > 0.10  ·  adjustment 0.0065 probability/run  ·  confidence = signal alignment, not guaranteed probability."
            textSize = 10f; setTextColor(Color.rgb(91, 107, 126)); gravity = Gravity.CENTER; setLineSpacing(0f, 1.08f)
        }, 0)

        var last = ""
        runButton.setOnClickListener {
            runButton.text = "ANALYSING  ·  P1 → P6…"
            val a = root.findEditText(0, "Team A") ?: "Team A"
            val b = root.findEditText(1, "Team B") ?: "Team B"
            val scoreEdit = root.findEditTextByHint("e.g. 159")
            val oversEdit = root.findEditTextByHint("e.g. 17.4")
            val ooEdit = root.findEditTextByHint("e.g. 1.52")
            val fbEdit = root.findEditTextByHint("e.g. 1.53")
            val coEdit = root.findEditTextByHint("e.g. 1.42")
            val diffEdit = root.findEditTextByHint("absolute run difference, e.g. 4")
            val sc = scoreEdit?.toIntOrNull(); val oo = ooEdit?.toDoubleOrNull(); val fb = fbEdit?.toDoubleOrNull(); val co = coEdit?.toDoubleOrNull()
            val batting = first.selectedItemPosition; val of = openFav.selectedItemPosition; val cf = currentFav.selectedItemPosition
            val diff = diffEdit?.toDoubleOrNull()?.let { abs(it) }
            val moreThan = when (lambiDir.selectedItemPosition) { 1 -> true; 2 -> false; else -> null }
            val signals = mutableListOf<Signal>(); val notes = mutableListOf<String>()
            fun name(t: Int) = if (t == 1) a else b
            fun other(t: Int) = if (t == 1) 2 else 1
            fun addSignal(p: String, t: Int, s: String) { signals += Signal(p, t, s) }
            fun role(t: Int) = if (batting == 0) 0 else if (t == batting) 2 else 1

            // P1
            if (sc != null && length.selectedItemPosition == 0 && batting in 1..2) {
                val tendency = when (sc) {
                    in 141..149, in 160..169, in 180..189, in 190..200, in 210..225 -> 2
                    in 150..159, in 170..179, in 201..209 -> 1
                    else -> 0
                }
                if (tendency == 1) addSignal("P1", other(batting), "$sc → CHASE tendency")
                if (tendency == 2) addSignal("P1", batting, "$sc → DEFEND tendency")
                if (tendency == 0) notes += "P1: no signal (score outside 141–225)"
            } else notes += "P1: no signal (requires a completed 20-over innings)"

            // P2
            fun p2(position: Int, team: Int): Int? {
                val r = role(team); if (position !in 1..4 || r == 0) return null
                val won = position <= 2; val previousRole = if (position == 1 || position == 3) 1 else 2
                val support = if (won) r != previousRole else r == previousRole
                return if (support) team else other(team)
            }
            val p2a = p2(prevA.selectedItemPosition, 1); val p2b = p2(prevB.selectedItemPosition, 2)
            if (p2a != null && p2b != null && p2a != p2b) notes += "P2: opposite team signals → P2 ignored entirely" else {
                if (p2a != null) addSignal("P2", p2a, "${name(1)} previous ${if (prevA.selectedItemPosition <= 2) "WIN" else "LOSS"} / ${if (prevA.selectedItemPosition == 1 || prevA.selectedItemPosition == 3) "chasing" else "defending"} → support ${name(p2a)}")
                if (p2b != null) addSignal("P2", p2b, "${name(2)} previous ${if (prevB.selectedItemPosition <= 2) "WIN" else "LOSS"} / ${if (prevB.selectedItemPosition == 1 || prevB.selectedItemPosition == 3) "chasing" else "defending"} → support ${name(p2b)}")
            }

            // P3
            val p3a = closeA.isChecked && prevA.selectedItemPosition in 1..4; val p3b = closeB.isChecked && prevB.selectedItemPosition in 1..4
            if (p3a && p3b) notes += "P3: both teams qualify → P3 ignored entirely" else {
                if (p3a) addSignal("P3", 1, "close / volatile previous match → $a")
                if (p3b) addSignal("P3", 2, "close / volatile previous match → $b")
            }

            // P4
            if (of in 1..2 && oo != null && fb != null && oo > 1 && fb > 1) {
                val move = fb - oo
                if (abs(move) > 0.10) {
                    val t = if (move > 0) of else other(of)
                    addSignal("P4", t, String.format(Locale.US, "opening ${name(of)} %.2f → first-ball %.2f  ·  move %+.2f", oo, fb, move))
                } else notes += String.format(Locale.US, "P4: movement %.2f → no signal (threshold > 0.10)", abs(move))
            } else notes += "P4: insufficient opening / first-ball odds inputs"

            // P5
            if (p5.selectedItemPosition == 1 && batting in 1..2) addSignal("P5", other(batting), "collapse + recovery → CHASE")
            if (p5.selectedItemPosition == 2 && batting in 1..2) addSignal("P5", batting, "steady / slower innings → DEFEND")
            if (p5.selectedItemPosition > 0 && batting == 0) notes += "P5: batting-first team required"

            // P6
            var p6: P6Result? = null
            if (of in 1..2 && oo != null && oo > 1 && diff != null && moreThan != null && batting in 1..2 && cf in 1..2 && co != null && co > 1) {
                p6 = calculateP6(of, oo, batting, moreThan, diff, cf, co)
                val r = p6
                if (r.signalTeam != null) addSignal("P6", r.signalTeam, String.format(Locale.US, "expected %.2f  ·  market-implied %.2f  ·  gap %+.2f", r.expectedOdds, r.marketImpliedOdds, r.difference))
                else notes += String.format(Locale.US, "P6: expected %.2f vs market-implied %.2f → NO SIGNAL (gap %.2f; threshold > 0.10)", r.expectedOdds, r.marketImpliedOdds, r.difference)
            } else notes += "P6: requires opening favourite, pre-first-ball odds, batting-first team, innings-break favourite/odds and benchmark difference"

            val p3 = signals.filter { it.pattern == "P3" }; val p3Winner = if (p3.size == 1) p3[0].team else 0
            val core = signals.filter { it.pattern == "P1" || it.pattern == "P2" || it.pattern == "P5" }
            val coreFinal = if (p3Winner != 0) p3Winner else run {
                val filtered = if (p5.selectedItemPosition > 0) core.filter { it.pattern != "P1" } else core
                val av = filtered.count { it.team == 1 }; val bv = filtered.count { it.team == 2 }
                if (av > bv) 1 else if (bv > av) 2 else 0
            }
            val market = signals.filter { it.pattern == "P4" || it.pattern == "P6" }
            val mvA = market.count { it.team == 1 }; val mvB = market.count { it.team == 2 }
            val marketFinal = if (mvA > mvB) 1 else if (mvB > mvA) 2 else 0
            val finalTeam: Int; val statusText: String
            if (p3Winner != 0) { finalTeam = p3Winner; statusText = "P3 OVERRIDE" }
            else if (coreFinal != 0 && marketFinal != 0 && coreFinal != marketFinal) { finalTeam = coreFinal; statusText = "CONFLICT  ·  CORE vs MARKET" }
            else {
                finalTeam = if (coreFinal != 0) coreFinal else marketFinal
                statusText = when {
                    coreFinal != 0 && marketFinal == coreFinal -> "ALIGNED  ·  CORE + MARKET"
                    coreFinal != 0 -> "CORE SIGNAL"
                    marketFinal != 0 -> "MARKET SIGNAL"
                    else -> "NO CLEAR SIGNAL"
                }
            }
            val applicable = signals.size
            val agreeing = if (finalTeam == 0) 0 else signals.count { it.team == finalTeam }
            val opposing = if (finalTeam == 0) 0 else signals.count { it.team != finalTeam }
            val confidence = when {
                finalTeam == 0 -> 0
                statusText == "P3 OVERRIDE" -> 85
                statusText.startsWith("CONFLICT") -> 35
                applicable == 0 -> 0
                else -> min(90, 50 + abs(agreeing - opposing) * 10)
            }

            renderResult(a, b, finalTeam, statusText, confidence, coreFinal, marketFinal, signals, notes, sc, batting, cf, length.selectedItemPosition, p6)
            last = buildString {
                append("FINAL ANALYSIS\n\n"); append(if (finalTeam == 0) "NO CLEAR SIGNAL" else name(finalTeam)); append("\n$statusText\n\n")
                append("Confidence: ${if (confidence == 0) "—" else "$confidence/100"}\n")
                append("Core: ${if (coreFinal == 0) "No clear core signal" else name(coreFinal)}\n")
                append("Market: ${if (marketFinal == 0) "No clear market signal" else name(marketFinal)}\n\nPATTERN DETAILS")
                signals.forEach { append("\n• ${it.pattern} → ${name(it.team)}: ${it.text}") }
                if (notes.isNotEmpty()) { append("\n\nNOTES"); notes.forEach { append("\n• $it") } }
            }
            runButton.post { runButton.text = "RUN ANALYSIS AGAIN   →" }
        }

        save.setOnClickListener {
            if (last.isBlank()) Toast.makeText(this, "Run an analysis first", Toast.LENGTH_SHORT).show()
            else { historyView.text = "✓  LAST ANALYSIS SAVED IN THIS SESSION\n\n$last"; Toast.makeText(this, "Analysis saved", Toast.LENGTH_SHORT).show() }
        }
        clear.setOnClickListener {
            root.clearAllInputs(); resultCard.removeAllViews(); resultCard.visibility = View.GONE; historyView.text = ""; last = ""; runButton.text = "RUN FINAL ANALYSIS   →"
        }

        scroll.addView(root); setContentView(scroll)
    }

    private fun renderResult(
        a: String, b: String, finalTeam: Int, status: String, confidence: Int, coreFinal: Int, marketFinal: Int,
        signals: List<Signal>, notes: List<String>, score: Int?, batting: Int, currentFavourite: Int,
        inningsLength: Int, p6: P6Result?
    ) {
        fun team(t: Int) = if (t == 1) a else b
        resultCard.removeAllViews(); resultCard.visibility = View.VISIBLE
        val conflict = status.startsWith("CONFLICT"); val noSignal = finalTeam == 0
        val resultColor = when { noSignal -> muted; conflict -> amber; else -> green }
        val resultFill = when { noSignal -> Color.rgb(28, 35, 46); conflict -> amberSoft; else -> greenSoft }

        add(resultCard, TextView(this).apply { text = "FINAL READ"; textSize = 10f; typeface = Typeface.DEFAULT_BOLD; setTextColor(muted); letterSpacing = .14f }, 6)
        val hero = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(13), dp(13), dp(13), dp(13)); background = solid(resultFill, 16) }
        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        left.addView(TextView(this).apply { text = if (noSignal) "NO CLEAR SIGNAL" else team(finalTeam).uppercase(Locale.US); textSize = 23f; typeface = Typeface.DEFAULT_BOLD; setTextColor(resultColor) }, params(3))
        left.addView(TextView(this).apply { text = status; textSize = 11f; typeface = Typeface.DEFAULT_BOLD; setTextColor(resultColor); letterSpacing = .06f }, params())
        hero.addView(left, LinearLayout.LayoutParams(0, -2, 1f))
        hero.addView(TextView(this).apply { text = if (confidence == 0) "—" else "$confidence"; textSize = 25f; typeface = Typeface.DEFAULT_BOLD; setTextColor(this@MainActivity.text); gravity = Gravity.CENTER }, LinearLayout.LayoutParams(dp(58), dp(58)))
        hero.addView(TextView(this).apply { text = "CONF\n/100"; textSize = 8.5f; typeface = Typeface.DEFAULT_BOLD; setTextColor(muted); gravity = Gravity.CENTER }, LinearLayout.LayoutParams(dp(40), dp(58)))
        add(resultCard, hero, 10)

        val summary = twoCol(
            infoPill("Core", if (coreFinal == 0) "—" else team(coreFinal), if (coreFinal == 0) muted else cyan, if (coreFinal == 0) panel2 else cyanSoft),
            infoPill("Market", if (marketFinal == 0) "—" else team(marketFinal), if (marketFinal == 0) muted else green, if (marketFinal == 0) panel2 else greenSoft)
        )
        add(resultCard, summary, 10)
        if (conflict) add(resultCard, TextView(this).apply { text = "⚠  CORE + MARKET DISAGREE  ·  treat this read as low confidence"; textSize = 10.5f; typeface = Typeface.DEFAULT_BOLD; setTextColor(amber); setPadding(dp(10), dp(9), dp(10), dp(9)); background = solid(amberSoft, 10) }, 10)

        add(resultCard, heading("Pattern breakdown", 15f), 7)
        val order = listOf("P3", "P5", "P1", "P2", "P4", "P6")
        for (p in order) {
            signals.filter { it.pattern == p }.forEach { sig ->
                val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.TOP; setPadding(dp(9), dp(9), dp(9), dp(9)); background = solid(fieldBg, 11) }
                r.addView(TextView(this@MainActivity).apply { text = p; textSize = 9.5f; typeface = Typeface.DEFAULT_BOLD; setTextColor(cyan); gravity = Gravity.CENTER; background = solid(cyanSoft, 7); setPadding(dp(6), dp(5), dp(6), dp(5)) }, LinearLayout.LayoutParams(dp(34), dp(28)).apply { rightMargin = dp(8) })
                r.addView(TextView(this).apply { text = "${team(sig.team)}  ·  ${sig.text}"; textSize = 11.5f; setTextColor(this@MainActivity.text); setLineSpacing(0f, 1.08f) }, LinearLayout.LayoutParams(0, -2, 1f))
                add(resultCard, r, 5)
            }
        }
        if (p6 != null) {
            val gapColor = when { abs(p6.difference) <= 0.10 -> muted; p6.difference < 0 -> green; else -> amber }
            add(resultCard, TextView(this).apply {
                text = String.format(Locale.US, "P6  ·  EXPECTED %.2f   |   MARKET %.2f   |   GAP %+.2f", p6.expectedOdds, p6.marketImpliedOdds, p6.difference)
                textSize = 10.5f; typeface = Typeface.DEFAULT_BOLD; setTextColor(gapColor); setPadding(dp(10), dp(10), dp(10), dp(10)); background = solid(panel2, 10)
            }, 9)
        }
        if (notes.isNotEmpty()) {
            add(resultCard, heading("Notes", 15f), 5)
            notes.forEach { add(resultCard, TextView(this).apply { text = "• $it"; textSize = 10.8f; setTextColor(muted); setLineSpacing(0f, 1.08f) }, 3) }
        }
        add(resultCard, heading("Match snapshot", 15f), 5)
        add(resultCard, TextView(this).apply {
            text = "First innings  ${score ?: "—"}   ·   ${if (inningsLength == 0) "20 overs" else "shortened"}\nBatting first  ${if (batting in 1..2) team(batting) else "—"}\nBreak favourite  ${if (currentFavourite in 1..2) team(currentFavourite) else "—"}"
            textSize = 11f; setTextColor(muted); setLineSpacing(0f, 1.12f); setPadding(dp(2), 0, dp(2), 0)
        }, 7)
        add(resultCard, TextView(this).apply {
            text = "P6 logic: baseline = pre-first-ball odds · ±0.0065 probability/run on the chasing side · market gap must exceed 0.10"
            textSize = 9.5f; setTextColor(Color.rgb(92, 108, 128)); gravity = Gravity.CENTER; setLineSpacing(0f, 1.08f)
        }, 0)
        resultCard.post { resultCard.requestFocus(); resultCard.parent?.let { (it as? ScrollView)?.smoothScrollTo(0, resultCard.top) } }
    }

    // Small view-tree helpers keep the single-activity project dependency-free.
    private fun View.findEditTextByHint(hint: String): EditText? {
        if (this is EditText && this.hint?.toString() == hint) return this
        if (this is android.view.ViewGroup) {
            for (i in 0 until childCount) {
                val found = getChildAt(i).findEditTextByHint(hint)
                if (found != null) return found
            }
        }
        return null
    }
    private fun View.findEditText(index: Int, defaultHint: String): String? {
        val list = mutableListOf<EditText>()
        fun walk(v: View) {
            if (v is EditText) list += v
            if (v is android.view.ViewGroup) for (i in 0 until v.childCount) walk(v.getChildAt(i))
        }
        walk(this)
        return list.getOrNull(index)?.text?.toString()?.trim()?.ifBlank { defaultHint }
    }
    private fun View.clearAllInputs() {
        if (this is EditText) text.clear()
        if (this is Spinner) setSelection(0)
        if (this is CheckBox) isChecked = false
        if (this is android.view.ViewGroup) for (i in 0 until childCount) getChildAt(i).clearAllInputs()
    }
}
