# T20 Pattern Analyzer V4

V4 improves the manual test interface for the six experimental T20 signals.

Changes: favourite can be Team A or Team B for opening and innings-break odds; separate previous-match outcomes for both teams; separate close-match flags for both teams; batting-first selector; full/shortened innings selector; run difference from Team A perspective; refreshed card-based UI.

The app is analysis-only and does not place bets.
