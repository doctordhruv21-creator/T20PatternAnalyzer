package com.example.t20patternanalyzer

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class MainActivity : Activity() {

    private lateinit var resultView: TextView
    private lateinit var historyView: TextView

    private val navy = Color.rgb(16, 36, 61)
    private val blue = Color.rgb(30, 136, 229)
    private val green = Color.rgb(46, 125, 50)
    private val red = Color.rgb(198, 40, 40)
    private val textDark = Color.rgb(35, 43, 52)
    private val muted = Color.rgb(100, 110, 120)
    private val cardBg = Color.rgb(255, 255, 255)
    private val pageBg = Color.rgb(245, 247, 250)

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radius: Int = 18): GradientDrawable {
        return GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
        }
    }

    private fun card(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(16))
            background = rounded(cardBg)
        }
    }

    private fun add(parent: LinearLayout, child: View, bottom: Int = 10) {
        parent.addView(child, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(bottom) })
    }

    private fun sectionTitle(title: String, subtitle: String? = null): LinearLayout {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val t = TextView(this).apply {
            text = title
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(navy)
        }
        add(box, t, if (subtitle == null) 2 else 4)
        if (subtitle != null) {
            val s = TextView(this).apply {
                text = subtitle
                textSize = 12f
                setTextColor(muted)
            }
            add(box, s, 0)
        }
        return box
    }

    private fun label(text: String): TextView {
        return TextView(this).apply {
            this.text = text
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(muted)
        }
    }

    private fun textInput(hintText: String): EditText {
        return EditText(this).apply {
            hint = hintText
            setSingleLine(true)
            textSize = 16f
            setPadding(dp(12), dp(8), dp(12), dp(8))
            inputType = InputType.TYPE_CLASS_TEXT
            background = rounded(Color.rgb(247, 249, 252), 12)
        }
    }

    private fun numberInput(hintText: String, signed: Boolean = false): EditText {
        return EditText(this).apply {
            hint = hintText
            setSingleLine(true)
            textSize = 16f
            setPadding(dp(12), dp(8), dp(12), dp(8))
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL or
                    if (signed) InputType.TYPE_NUMBER_FLAG_SIGNED else 0
            background = rounded(Color.rgb(247, 249, 252), 12)
        }
    }

    private fun spinner(options: Array<String>): Spinner {
        return Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, options)
            background = rounded(Color.rgb(247, 249, 252), 12)
            minimumHeight = dp(48)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(pageBg)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(28))
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(22))
            background = rounded(navy, 22)
        }
        val title = TextView(this).apply {
            text = "T20 Pattern Analyzer"
            textSize = 27f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
        }
        add(header, title, 4)
        val sub = TextView(this).apply {
            text = "V4  •  Six-signal engine  •  Smarter inputs"
            textSize = 13f
            setTextColor(Color.rgb(205, 220, 235))
        }
        add(header, sub, 0)
        add(root, header, 12)

        val matchCard = card()
        add(matchCard, sectionTitle("🏏  Match setup", "Tell the analyzer who is batting first and how long the innings lasted"), 12)
        val teamA = textInput("Team A")
        val teamB = textInput("Team B")
        add(matchCard, label("Teams"), 5)
        add(matchCard, teamA, 7)
        add(matchCard, teamB, 10)

        add(matchCard, label("Who batted first?"), 5)
        val battingFirst = spinner(arrayOf("Select batting-first team", "Team A", "Team B"))
        add(matchCard, battingFirst, 10)

        add(matchCard, label("First-innings score"), 5)
        val firstInningsScore = numberInput("e.g. 147")
        add(matchCard, firstInningsScore, 10)

        add(matchCard, label("Innings length"), 5)
        val inningsLength = spinner(arrayOf("20 overs", "Shortened — under 20 overs"))
        add(matchCard, inningsLength, 7)
        val oversPlayed = numberInput("Overs actually played, e.g. 17.4")
        add(matchCard, oversPlayed, 10)

        val scoreHint = TextView(this).apply {
            text = "Run difference is entered below from Team A's perspective: + means A is ahead, − means B is ahead."
            textSize = 12f
            setTextColor(muted)
        }
        add(matchCard, scoreHint, 0)
        add(root, matchCard, 12)

        val oddsCard = card()
        add(oddsCard, sectionTitle("💹  Odds snapshot", "Choose whichever team is the favourite — A or B"), 12)
        add(oddsCard, label("Opening favourite"), 5)
        val openingFavourite = spinner(arrayOf("Select opening favourite", "Team A", "Team B"))
        add(oddsCard, openingFavourite, 8)
        val openingOdds = numberInput("Opening odds, e.g. 1.50")
        add(oddsCard, openingOdds, 12)

        add(oddsCard, label("Innings-break favourite"), 5)
        val currentFavourite = spinner(arrayOf("Select innings-break favourite", "Team A", "Team B"))
        add(oddsCard, currentFavourite, 8)
        val currentOdds = numberInput("Current odds, e.g. 1.80")
        add(oddsCard, currentOdds, 12)

        add(oddsCard, label("Score vs Lambi"), 5)
        val lambiDirection = spinner(arrayOf("Select: more or less than Lambi", "More than Lambi", "Less than Lambi"))
        add(oddsCard, lambiDirection, 8)
        val runDifference = numberInput("Difference from Lambi, e.g. 10")
        add(oddsCard, runDifference, 3)
        val lambiHint = TextView(this).apply {
            text = "Example: Lambi 150 → score 160 = 10 more; score 140 = 10 less. Enter only the absolute difference."
            textSize = 12f
            setTextColor(muted)
        }
        add(oddsCard, lambiHint, 0)
        add(root, oddsCard, 12)

        val previousCard = card()
        add(previousCard, sectionTitle("🔄  Previous match signals", "Enter the result separately for each team"), 12)
        add(previousCard, label("Team A — previous match"), 5)
        val previousA = spinner(arrayOf("Unknown", "Won — chasing", "Won — defending", "Lost — chasing", "Lost — defending"))
        add(previousCard, previousA, 10)
        add(previousCard, label("Team B — previous match"), 5)
        val previousB = spinner(arrayOf("Unknown", "Won — chasing", "Won — defending", "Lost — chasing", "Lost — defending"))
        add(previousCard, previousB, 10)

        val closeA = CheckBox(this).apply {
            text = "Team A's previous match was very close / favourite changed multiple times"
            textSize = 14f
            setTextColor(textDark)
        }
        val closeB = CheckBox(this).apply {
            text = "Team B's previous match was very close / favourite changed multiple times"
            textSize = 14f
            setTextColor(textDark)
        }
        add(previousCard, closeA, 4)
        add(previousCard, closeB, 0)
        add(root, previousCard, 12)

        val shapeCard = card()
        add(shapeCard, sectionTitle("📈  First-innings shape", "Use only what was visible before the chase"), 12)
        val collapseRecovery = CheckBox(this).apply {
            text = "Early collapse followed by recovery"
            textSize = 14f
            setTextColor(textDark)
        }
        val steadyInnings = CheckBox(this).apply {
            text = "Steady / slower scoring without repeated wicket clusters"
            textSize = 14f
            setTextColor(textDark)
        }
        add(shapeCard, collapseRecovery, 4)
        add(shapeCard, steadyInnings, 0)
        add(root, shapeCard, 12)

        val analyseButton = Button(this).apply {
            text = "ANALYSE MATCH  →"
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            background = rounded(blue, 16)
            minimumHeight = dp(54)
        }
        add(root, analyseButton, 12)

        resultView = TextView(this).apply {
            textSize = 15f
            setTextColor(textDark)
            setPadding(dp(18), dp(18), dp(18), dp(18))
            background = rounded(Color.WHITE, 18)
        }
        add(root, resultView, 12)

        val saveButton = Button(this).apply {
            text = "SAVE LAST PREDICTION"
            setTextColor(navy)
            background = rounded(Color.rgb(225, 232, 240), 14)
            minimumHeight = dp(50)
        }
        add(root, saveButton, 10)

        historyView = TextView(this).apply {
            textSize = 13f
            setTextColor(muted)
            setPadding(dp(18), dp(12), dp(18), dp(12))
        }
        add(root, historyView, 10)

        val clearButton = Button(this).apply {
            text = "CLEAR FORM"
            setTextColor(navy)
            background = rounded(Color.rgb(232, 235, 239), 14)
        }
        add(root, clearButton, 12)

        val note = TextView(this).apply {
            text = "⚠ Experimental signals only. The analyzer does not place bets. Confidence is a composite signal score, not a guaranteed probability."
            textSize = 12f
            setTextColor(muted)
            gravity = Gravity.CENTER
        }
        add(root, note, 0)

        var lastPrediction = ""

        analyseButton.setOnClickListener {
            val aName = teamA.text.toString().trim().ifBlank { "Team A" }
            val bName = teamB.text.toString().trim().ifBlank { "Team B" }
            val score = firstInningsScore.text.toString().toIntOrNull()
            val openOdds = openingOdds.text.toString().toDoubleOrNull()
            val curOdds = currentOdds.text.toString().toDoubleOrNull()
            val runDiffAbsolute = runDifference.text.toString().toDoubleOrNull()?.let { abs(it) }
            val lambiSign = when (lambiDirection.selectedItemPosition) {
                1 -> 1.0
                2 -> -1.0
                else -> null
            }
            val runDiff = if (runDiffAbsolute != null && lambiSign != null) runDiffAbsolute * lambiSign else null
            val firstTeam = battingFirst.selectedItemPosition

            val signals = mutableListOf<String>()
            var aVotes = 0
            var bVotes = 0
            var chaseVotes = 0
            var defendVotes = 0

            fun addVote(team: Int, reason: String) {
                signals += reason
                if (team == 1) aVotes++ else if (team == 2) bVotes++
            }

            // Pattern 1: first innings score bands.
            if (score != null) {
                val tendency = when (score) {
                    in 141..149, in 160..169, in 180..189, in 190..200, in 210..225 -> "DEFEND"
                    in 150..159, in 170..179, in 201..209 -> "CHASE"
                    else -> "NONE"
                }
                if (tendency == "DEFEND") {
                    defendVotes++
                    if (firstTeam == 1) aVotes++ else if (firstTeam == 2) bVotes++
                    signals += "P1 • $score → DEFEND tendency"
                } else if (tendency == "CHASE") {
                    chaseVotes++
                    if (firstTeam == 1) bVotes++ else if (firstTeam == 2) aVotes++
                    signals += "P1 • $score → CHASE tendency"
                } else {
                    signals += "P1 • $score → outside configured score bands"
                }
            }

            // Pattern 2: previous direction, evaluated for each team and current role.
            fun previousDirection(position: Int): String {
                return when (position) {
                    1 -> "CHASE"
                    2 -> "DEFEND"
                    3 -> "CHASE"
                    4 -> "DEFEND"
                    else -> "UNKNOWN"
                }
            }
            fun previousOutcome(position: Int): String {
                return when (position) {
                    1, 2 -> "WON"
                    3, 4 -> "LOST"
                    else -> "UNKNOWN"
                }
            }
            fun currentRole(team: Int): String {
                if (firstTeam == 0) return "UNKNOWN"
                return if (team == firstTeam) "DEFEND" else "CHASE"
            }
            fun applyP2(team: Int, position: Int, teamName: String) {
                val outcome = previousOutcome(position)
                val previousDir = previousDirection(position)
                val role = currentRole(team)
                if (outcome == "UNKNOWN" || role == "UNKNOWN") {
                    if (outcome != "UNKNOWN") signals += "P2 • $teamName previous result known ($outcome), but current chase/defend role is unknown"
                    return
                }
                val repeatDirection = previousDir == role
                val support = if (outcome == "WON") !repeatDirection else repeatDirection
                if (support) {
                    if (team == 1) aVotes++ else bVotes++
                    signals += "P2 • $teamName $outcome ${previousDir.lowercase()} previously → support $teamName (${role.lowercase()} now)"
                } else {
                    if (team == 1) bVotes++ else aVotes++
                    signals += "P2 • $teamName $outcome ${previousDir.lowercase()} previously → oppose $teamName (${role.lowercase()} now)"
                }
            }
            applyP2(1, previousA.selectedItemPosition, aName)
            applyP2(2, previousB.selectedItemPosition, bName)

            // Pattern 3: close/fluctuating previous match, separately for each team.
            if (closeA.isChecked) {
                val known = previousA.selectedItemPosition in 1..4
                if (known) {
                    aVotes++
                    signals += "P3 • $aName close/fluctuating previous match → continuation signal for $aName"
                } else signals += "P3 • $aName close match marked, previous winner unknown"
            }
            if (closeB.isChecked) {
                val known = previousB.selectedItemPosition in 1..4
                if (known) {
                    bVotes++
                    signals += "P3 • $bName close/fluctuating previous match → continuation signal for $bName"
                } else signals += "P3 • $bName close match marked, previous winner unknown"
            }

            // Pattern 4: favourite-specific odds movement.
            if (openOdds != null && curOdds != null && openOdds > 1.0 && curOdds > 1.0) {
                val favAtOpen = openingFavourite.selectedItemPosition
                val favNow = currentFavourite.selectedItemPosition
                if (favAtOpen in 1..2) {
                    val favName = if (favAtOpen == 1) aName else bName
                    val favTeam = favAtOpen
                    if (curOdds < openOdds) {
                        if (favTeam == 1) bVotes++ else aVotes++
                        signals += String.format(Locale.US, "P4 • $favName shortened %.2f → %.2f → oppose $favName", openOdds, curOdds)
                    } else if (curOdds > openOdds) {
                        if (favTeam == 1) aVotes++ else bVotes++
                        signals += String.format(Locale.US, "P4 • $favName drifted %.2f → %.2f → support $favName", openOdds, curOdds)
                    } else {
                        signals += String.format(Locale.US, "P4 • $favName odds unchanged at %.2f", openOdds)
                    }
                    if (favNow in 1..2 && favNow != favAtOpen) {
                        val nowName = if (favNow == 1) aName else bName
                        signals += "P4 note • favourite switched to $nowName at the innings break"
                    }
                } else {
                    signals += "P4 • select the opening favourite to evaluate odds movement"
                }
            }

            // Pattern 5: innings shape.
            if (collapseRecovery.isChecked) {
                chaseVotes++
                if (firstTeam == 1) bVotes++ else if (firstTeam == 2) aVotes++
                signals += "P5 • early collapse + recovery → CHASE tendency"
            }
            if (steadyInnings.isChecked) {
                defendVotes++
                if (firstTeam == 1) aVotes++ else if (firstTeam == 2) bVotes++
                signals += "P5 • steady/slower innings → DEFEND tendency"
            }

            // Pattern 6: opening favourite probability + run adjustment.
            var adjustedProbability: Double? = null
            val openingFav = openingFavourite.selectedItemPosition
            if (openOdds != null && openOdds > 1.0 && openingFav in 1..2 && runDiff != null) {
                // Lambi comparison is independent of which team is favourite:
                // more than Lambi = positive adjustment, less than Lambi = negative adjustment.
                val baseProbability = 1.0 / openOdds
                adjustedProbability = min(0.99, max(0.01, baseProbability + runDiff * 0.0065))
                val favName = if (openingFav == 1) aName else bName
                val expectedOdds = 1.0 / adjustedProbability
                val directionText = if (runDiff >= 0) "more than Lambi" else "less than Lambi"
                signals += String.format(Locale.US, "P6 • $favName base %.1f%% + %s by %.1f runs → %.1f%% (expected odds %.2f)", baseProbability * 100, directionText, abs(runDiff), adjustedProbability * 100, expectedOdds)
                if (adjustedProbability >= 0.5) {
                    if (openingFav == 1) aVotes++ else bVotes++
                } else {
                    if (openingFav == 1) bVotes++ else aVotes++
                }
            }

            val prediction = when {
                aVotes > bVotes -> aName
                bVotes > aVotes -> bName
                else -> "NO CLEAR SIGNAL"
            }
            val totalVotes = aVotes + bVotes
            val confidence = if (totalVotes == 0) 50.0 else min(90.0, 50.0 + (abs(aVotes - bVotes) * 8.0))

            val oversText = if (inningsLength.selectedItemPosition == 0) "20 overs" else "shortened${oversPlayed.text.toString().trim().let { if (it.isBlank()) "" else " • $it overs" }}"
            val result = buildString {
                append("FINAL SIGNAL\n")
                append(prediction)
                append("\n\n")
                append(String.format(Locale.US, "Signal strength: %.0f/100", confidence))
                append("\nVote count: $aName $aVotes  •  $bName $bVotes")
                append("\n\nSIGNALS")
                if (signals.isEmpty()) append("\n• Not enough inputs for the configured patterns")
                else signals.forEach { append("\n• $it") }
                append("\n\nMATCH SNAPSHOT")
                append("\nFirst innings: ${score ?: "—"}  •  $oversText")
                append("\nBatting first: ${if (firstTeam == 1) aName else if (firstTeam == 2) bName else "—"}")
                if (runDiff != null) {
                    append(String.format(Locale.US, "\nLambi comparison: %s %.1f runs", if (runDiff >= 0) "MORE" else "LESS", abs(runDiff)))
                }
                if (adjustedProbability != null) append(String.format(Locale.US, "\nP6 adjusted opening-favourite probability: %.1f%%", adjustedProbability * 100))
                append("\n\nExperimental signal score — not a guaranteed probability.")
            }
            lastPrediction = result
            resultView.text = result
            resultView.setTextColor(textDark)
        }

        saveButton.setOnClickListener {
            if (lastPrediction.isBlank()) {
                Toast.makeText(this, "Analyse a match first", Toast.LENGTH_SHORT).show()
            } else {
                historyView.text = "✓ Last prediction saved in this session\n\n$lastPrediction"
                Toast.makeText(this, "Prediction saved", Toast.LENGTH_SHORT).show()
            }
        }

        clearButton.setOnClickListener {
            teamA.text.clear()
            teamB.text.clear()
            firstInningsScore.text.clear()
            oversPlayed.text.clear()
            openingOdds.text.clear()
            currentOdds.text.clear()
            runDifference.text.clear()
            lambiDirection.setSelection(0)
            battingFirst.setSelection(0)
            inningsLength.setSelection(0)
            openingFavourite.setSelection(0)
            currentFavourite.setSelection(0)
            previousA.setSelection(0)
            previousB.setSelection(0)
            closeA.isChecked = false
            closeB.isChecked = false
            collapseRecovery.isChecked = false
            steadyInnings.isChecked = false
            resultView.text = ""
            historyView.text = ""
            lastPrediction = ""
        }

        scroll.addView(root)
        setContentView(scroll)
    }
}
