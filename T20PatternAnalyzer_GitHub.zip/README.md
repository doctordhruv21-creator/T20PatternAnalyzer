# T20 Pattern Analyzer V5

V5 implements the finalized P1–P6 strategy framework discussed for the T20 Pattern Analyzer.

## Finalized engine
- P1: full 20-over first-innings score bands; shortened innings produce no P1 signal.
- P2: immediately preceding match result + chase/defend mapping, evaluated separately for both teams; opposite P2 signals are ignored.
- P3: manually marked close/fluctuating previous match; one qualifying team overrides all other patterns; both qualifying teams cause P3 to be ignored.
- P4: opening favourite vs first-ball odds; only movement strictly greater than 0.10 is considered.
- P5: manual, mutually exclusive innings-shape choice; P5 overrides P1.
- P6: Lambi adjustment using 0.0065 probability per run, expected odds calculation, then market comparison; only odds differences strictly greater than 0.10 are considered.

## Conflict handling
- P3 override is highest priority.
- Otherwise P5 replaces P1 in the core layer.
- P1/P2/P5 form the core signal.
- P4/P6 form the market signal.
- If core and market agree, the app reports alignment.
- If core and market disagree, the app reports **CONFLICT — core vs market** and low confidence instead of forcing a silent choice.
- If only one layer has a signal, that layer is reported.

The app is analysis-only and does not place bets. Confidence is a signal-quality indicator, not a guaranteed probability.
