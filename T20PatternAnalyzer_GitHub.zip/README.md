# T20 Pattern Analyzer — V5.4

Analysis-only Android app for the user's T20 pattern strategy. It does not place bets.

## Patterns
- **P1:** First innings score bands; only a completed 20-over innings qualifies.
- **P2:** Immediately previous match direction, evaluated separately for each team. Opposite P2 signals are ignored.
- **P3:** Manual close/fluctuating previous-match signal. If both teams qualify, P3 is ignored. A single P3 signal overrides other patterns.
- **P4:** Opening favourite vs first-ball odds. Movement strictly greater than 0.10 supports the appropriate side.
- **P5:** Manual first-innings shape: collapse + recovery = CHASE; steady/slower = DEFEND. P5 replaces P1 when selected.
- **P6:** Finalized innings-break market-alignment calculation.

## P6 calculation — finalized
1. **Baseline odds are the odds entered immediately before the first ball. Pre-match odds are not used.**
2. Baseline probability = `1 / pre-first-ball odds`.
3. Run adjustment = `0.0065 probability per run`.
4. The adjustment applies to the **chasing team**: LESS than the Lambi/benchmark increases the chasing team's probability; MORE decreases it.
5. Convert the adjusted probability of the opening favourite back to expected odds.
6. Compare expected odds with the current innings-break market odds for that same team. If the favourite switched, derive the opening favourite's market-implied odds from the current favourite's probability.
7. If current odds are **more than 0.10 lower** than expected odds → support the opening favourite.
8. If current odds are **more than 0.10 higher** than expected odds → support the other team.
9. If the absolute difference is **≤ 0.10**, P6 gives **NO SIGNAL**.

### Validation example
If GC bats first, the opening/pre-first-ball ECR odds are **1.52**, GC scores **4 LESS** than expected, and the innings-break ECR odds are **1.42**:
- Baseline ECR probability = `1 / 1.52` = 0.6579
- Chasing-team adjustment = `4 × 0.0065` = +0.026
- Expected ECR probability ≈ 0.6839
- Expected ECR odds ≈ **1.46**
- Market odds = **1.42**
- Difference = **−0.04**
- **P6 = NO SIGNAL** because the difference does not exceed 0.10.

## UI
V5.4 refreshes the interface with a darker premium header, clearer input sections, compact field styling, a visual final-analysis card, signal badges, confidence display, and a cleaner market/P6 explanation.

## Signal layers
P3 overrides. Otherwise P1/P2/P5 form the core layer and P4/P6 form the market layer. Agreement is reported; disagreement is shown as a low-confidence conflict.
