# T20 Pattern Analyzer — Upgraded V3

This version is based on the original T20 Pattern Analyzer project.

## Preserved prediction engine
- P1, P2, P3, P4, P5 and finalized P6
- P2 opposite-signal ignore rule
- P3 mutual qualification ignore rule
- P3 override
- P5 suppressing P1 in the core decision
- Core vs Market separation
- Core/Market conflict handling
- Final confidence logic
- P6 uses pre-first-ball odds as the baseline
- P6 automatically calculates actual innings score minus the selected Lambi / 20-over runline
- P6 applies the 0.0065/run convention with correct LESS/MORE direction
- P6 strict >0.10 market-difference threshold

## Upgraded shell
- Jetpack Compose + Material 3
- Dark Stadium theme
- Live T20 match screen using Retrofit/Gson and CricAPI-compatible currentMatches structure
- Live match → real P1–P6 prediction form
- Animated What-If scenario gauge
- Room offline prediction snapshots

## Important
The What-If simulator is intentionally separate from the original P1–P6 engine. It does not change the established prediction formulas.
