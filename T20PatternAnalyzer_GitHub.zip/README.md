# T20 Pattern Analyzer — Live Match + Prediction

This version adds a Live Match Center to the existing P1–P6 prediction engine.

## What changed
- Live Matches tab using Cricket Data / CricAPI Current Matches API.
- Current match list with team scores, wickets and overs where supplied by the API.
- One-tap **OPEN PREDICTION** button on every live match.
- Prediction tab opens the existing P1–P6 pattern-analysis form unchanged.
- API key is entered inside the app and stored locally on the device; it is NOT committed to GitHub.
- Added Android INTERNET permission.
- Existing finalized P6 rules are preserved.

## API
The live-score integration uses:
`https://api.cricapi.com/v1/currentMatches?apikey=YOUR_API_KEY&offset=0`

Cricket Data currently documents the Current Matches endpoint and provides a lifetime-free tier with 100 API hits/day. Registered API-key requests can provide near-live data; exact freshness and limits depend on the provider plan.

## Setup
1. Create a Cricket Data account and obtain your API key.
2. Build/install this APK.
3. Open **LIVE MATCHES**.
4. Paste the API key and tap **SAVE API KEY & REFRESH**.
5. Tap **OPEN PREDICTION** on a match to launch the existing pattern form.

## Important production note
For a public app, do not permanently embed a shared API key in the APK. A small backend/proxy should keep the provider key server-side and rate-limit requests. The current implementation is suitable for a personal/internal build because the key is supplied by the user at runtime.

## Prediction engine
The existing P1–P6 engine remains the source of the prediction result. P6 continues to use the pre-first-ball odds baseline and the finalized 0.0065/run adjustment convention.
