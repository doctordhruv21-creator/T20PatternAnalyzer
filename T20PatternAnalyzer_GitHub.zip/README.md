# T20 Pattern Analyzer — V5.3

Analysis-only Android app for the user's T20 pattern strategy. It does not place bets.

## Patterns
- **P1:** First innings score bands; only a completed 20-over innings qualifies. 141–225 bands as finalized by the strategy.
- **P2:** Immediately previous match direction, evaluated separately for each team. Opposite P2 signals are ignored; matching signals confirm.
- **P3:** Manual close/fluctuating previous-match signal. If both teams qualify, P3 is ignored. A single P3 signal overrides all other patterns.
- **P4:** Opening favourite vs first-ball odds. Movement strictly greater than 0.10 supports the appropriate side.
- **P5:** Manual first-innings shape: collapse + recovery = CHASE; steady/slower = DEFEND. P5 replaces P1 when selected.
- **P6:** Lambi-adjusted probability calculated at the innings break.

## P6 calculation
1. Opening probability = `1 / opening odds`.
2. Lambi adjustment = `run difference × 0.0065`.
3. MORE adds the adjustment; LESS subtracts it.
4. Expected odds = `1 / expected probability` for the **opening favourite**.
5. At the innings break, select the **current favourite** and enter its current odds.
6. If the current favourite is still the opening favourite, those odds are used directly.
7. If the favourite has switched, derive the market-implied odds of the opening favourite from the current favourite:
   - `opening-favourite market probability = 1 - (1 / current-favourite odds)`
   - `opening-favourite market odds = 1 / opening-favourite market probability`
8. **1.98 is the crossover point where both teams are treated as favourite.** The favourite-change understanding is used only for this innings-break P6 calculation; the app does not continuously track a live movement path.
9. If market-implied odds are more than 0.10 above expected odds, P6 supports the other team. If more than 0.10 below expected odds, P6 supports the opening favourite. Absolute difference ≤ 0.10 = no P6 signal.

### Example
Opening favourite A = 1.70; Lambi = 150; score = 120 (30 LESS); current favourite B = 1.40.
- Opening probability = 58.82%
- Lambi adjustment = 19.50 percentage points
- Expected A probability = 39.32%
- Expected A odds = 2.54
- B market probability = 71.43%
- A market-implied probability = 28.57%
- A market-implied odds = 3.50
- Difference = 0.96 → **P6 supports Team B**.

## Signal layers
P3 overrides. Otherwise P1/P2/P5 form the core layer and P4/P6 form the market layer. Agreement is reported; disagreement is shown as a low-confidence conflict rather than silently overriding one layer.
