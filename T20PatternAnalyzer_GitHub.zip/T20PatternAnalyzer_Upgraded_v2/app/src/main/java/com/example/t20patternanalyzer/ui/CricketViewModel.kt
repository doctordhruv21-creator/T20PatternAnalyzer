package com.example.t20patternanalyzer.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.t20patternanalyzer.data.api.CricketApiService
import com.example.t20patternanalyzer.data.api.CricketMatchDto
import com.example.t20patternanalyzer.data.db.AppDatabase
import com.example.t20patternanalyzer.data.db.MatchPrediction
import com.example.t20patternanalyzer.engine.AnalysisResult
import com.example.t20patternanalyzer.engine.PatternInput
import com.example.t20patternanalyzer.engine.PatternEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class CricketViewModel(app:Application):AndroidViewModel(app){
 private val dao=AppDatabase.getInstance(app).predictionDao()
 private val api=Retrofit.Builder().baseUrl(CricketApiService.BASE_URL).client(OkHttpClient.Builder().addInterceptor(HttpLoggingInterceptor().apply{level=HttpLoggingInterceptor.Level.BASIC}).build()).addConverterFactory(GsonConverterFactory.create()).build().create(CricketApiService::class.java)
 private val _matches=MutableStateFlow<List<CricketMatchDto>>(emptyList()); val matches:StateFlow<List<CricketMatchDto>>=_matches.asStateFlow()
 private val _loading=MutableStateFlow(false); val loading:StateFlow<Boolean>=_loading.asStateFlow()
 private val _error=MutableStateFlow<String?>(null); val error:StateFlow<String?>=_error.asStateFlow()
 private val _apiKey=MutableStateFlow(""); val apiKey:StateFlow<String>=_apiKey.asStateFlow()
 val savedPredictions=dao.observeAll().flowOn(Dispatchers.IO)
 fun setApiKey(v:String){_apiKey.value=v}
 fun loadMatches(){val key=_apiKey.value.trim();if(key.isBlank()){_error.value="Enter your CricAPI key first.";return};viewModelScope.launch(Dispatchers.IO){_loading.value=true;_error.value=null;try{val r=api.getCurrentMatches(key);if(r.status.equals("success",true))_matches.value=r.data.filter{it.matchType.equals("t20",true)||it.name.orEmpty().contains("T20",true)}else _error.value=r.message?:"Cricket API returned an error."}catch(e:Exception){_error.value=e.message?:"Unable to load live matches."}finally{_loading.value=false}}}
 fun analyze(input:PatternInput):AnalysisResult=PatternEngine.analyze(input)
 fun save(match:CricketMatchDto?,input:PatternInput,result:AnalysisResult){viewModelScope.launch(Dispatchers.IO){val a=input.teamA.ifBlank{"Team A"};val b=input.teamB.ifBlank{"Team B"};fun s(p:String)=result.signals.filter{it.pattern==p}.joinToString(" | "){"${if(it.team==1)a else b}: ${it.text}"};dao.insert(MatchPrediction(match?.id.orEmpty(),match?.name?:("$a vs $b"),a,b,result.finalTeam,result.status,result.confidence,result.coreTeam,result.marketTeam,s("P1"),s("P2"),s("P3"),s("P4"),s("P5"),s("P6")))}}
 fun delete(id:Long){viewModelScope.launch(Dispatchers.IO){dao.deleteById(id)}}
}
