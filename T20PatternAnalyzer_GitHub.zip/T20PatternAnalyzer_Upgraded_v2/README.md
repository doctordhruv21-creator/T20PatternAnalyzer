# T20 Pattern Analyzer — v6 Upgraded

This version is an upgrade of the original T20 Pattern Analyzer, not a replacement of its prediction engine.

## Preserved original decision engine

- P1 score-band logic
- P2 previous-match logic and opposite-signal ignore rule
- P3 close/volatile-match logic and mutual qualification ignore rule
- P4 opening → first-ball movement with strict `> 0.10` threshold
- P5 manual first-innings-shape signal and P5 → P1 interaction
- P3 override
- Core vs Market separation
- Core/Market conflict handling
- Original confidence calculation
- Finalized P6:
  - pre-first-ball/opening odds are the baseline
  - `0.0065` run adjustment convention
  - LESS than expected/Lambi increases chasing-side probability
  - MORE decreases chasing-side probability
  - strict `> 0.10` odds-difference threshold
  - market-implied odds when the innings-break favourite switches

The original engine now lives in `engine/PatternEngine.kt` so the UI can evolve without changing the decision rules.

## New layer

- Jetpack Compose + Material 3
- Dark Stadium theme
- Live T20 match feed through Retrofit + Gson
- Match selection → P1–P6 form
- What-If simulator with animated scenario probability gauge
- Phase-ready analysis presentation
- Room offline prediction snapshots
- Saved decision vault

The What-If simulator is deliberately separate from P1–P6. It does not alter the original prediction formulas.

## Build

Use JDK 17 and Android Gradle Plugin 8.7.3. The included GitHub workflow uses Gradle 8.9 and can build the project from the repository root or from an uploaded `T20PatternAnalyzer*.zip`.

Enter your CricAPI key inside the app. It is not hard-coded into the source.
