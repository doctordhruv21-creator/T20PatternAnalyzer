package com.example.t20patternanalyzer

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Cached
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SportsCricket
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.t20patternanalyzer.data.api.CricketMatchDto
import com.example.t20patternanalyzer.data.db.MatchPrediction
import com.example.t20patternanalyzer.ui.CricketViewModel
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

private val DeepSlateNavy = Color(0xFF0F172A)
private val Slate = Color(0xFF1E293B)
private val PitchGreen = Color(0xFF10B981)
private val ElectricCyan = Color(0xFF38BDF8)
private val MutedText = Color(0xFF94A3B8)
private val Danger = Color(0xFFF87171)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            T20Theme {
                T20App()
            }
        }
    }
}

@Composable
private fun T20Theme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = androidx.compose.material3.darkColorScheme(
            primary = PitchGreen,
            secondary = ElectricCyan,
            background = DeepSlateNavy,
            surface = Slate,
            onBackground = Color.White,
            onSurface = Color.White
        ),
        content = content
    )
}

private enum class Screen {
    LIVE, PREDICT, SAVED
}

@Composable
private fun T20App(viewModel: CricketViewModel = viewModel()) {
    var screen by remember { mutableStateOf(Screen.LIVE) }
    var selectedMatch by remember { mutableStateOf<CricketMatchDto?>(null) }

    Scaffold(
        containerColor = DeepSlateNavy,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("T20 PATTERN ANALYZER", fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                        Text(
                            if (screen == Screen.LIVE) "LIVE MATCH CENTER" else if (screen == Screen.PREDICT) "PATTERN PREDICTION" else "SAVED SNAPSHOTS",
                            fontSize = 11.sp,
                            color = ElectricCyan,
                            fontWeight = FontWeight.Bold
                        )
                    }
                },
                navigationIcon = {
                    if (screen != Screen.LIVE) {
                        IconButton(onClick = { screen = Screen.LIVE; selectedMatch = null }) {
                            Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                        }
                    } else {
                        Icon(Icons.Default.SportsCricket, contentDescription = null, tint = PitchGreen)
                    }
                },
                actions = {
                    IconButton(onClick = { viewModel.loadMatches() }) {
                        Icon(Icons.Default.Refresh, contentDescription = "Refresh")
                    }
                    IconButton(onClick = { screen = Screen.SAVED }) {
                        Icon(Icons.Default.Cached, contentDescription = "Saved predictions")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DeepSlateNavy)
            )
        },
        bottomBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Slate)
                    .padding(8.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                NavItem("LIVE", Icons.Default.SportsCricket, screen == Screen.LIVE) {
                    screen = Screen.LIVE
                }
                NavItem("PREDICT", Icons.Default.Analytics, screen == Screen.PREDICT) {
                    screen = Screen.PREDICT
                }
                NavItem("SAVED", Icons.Default.Cached, screen == Screen.SAVED) {
                    screen = Screen.SAVED
                }
            }
        }
    ) { padding ->
        when (screen) {
            Screen.LIVE -> LiveScreen(
                modifier = Modifier.padding(padding),
                viewModel = viewModel,
                onPredict = {
                    selectedMatch = it
                    screen = Screen.PREDICT
                }
            )
            Screen.PREDICT -> PredictionScreen(
                modifier = Modifier.padding(padding),
                viewModel = viewModel,
                match = selectedMatch
            )
            Screen.SAVED -> SavedScreen(
                modifier = Modifier.padding(padding),
                viewModel = viewModel
            )
        }
    }
}

@Composable
private fun NavItem(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    selected: Boolean,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 22.dp, vertical = 7.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, contentDescription = label, tint = if (selected) PitchGreen else MutedText)
        Text(label, fontSize = 10.sp, color = if (selected) PitchGreen else MutedText, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun LiveScreen(
    modifier: Modifier,
    viewModel: CricketViewModel,
    onPredict: (CricketMatchDto) -> Unit
) {
    val matches by viewModel.matches.collectAsState()
    val loading by viewModel.loading.collectAsState()
    val error by viewModel.error.collectAsState()
    val apiKey by viewModel.apiKey.collectAsState()
    var showSettings by remember { mutableStateOf(apiKey.isBlank()) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(vertical = 16.dp)
    ) {
        item {
            HeroCard(
                title = "READ THE GAME",
                subtitle = "Live scores + pattern-based prediction in one dashboard."
            )
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Slate),
                shape = RoundedCornerShape(18.dp)
            ) {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Settings, contentDescription = null, tint = ElectricCyan)
                        Spacer(Modifier.width(10.dp))
                        Text("CRICKET API", fontWeight = FontWeight.Bold)
                        Spacer(Modifier.weight(1f))
                        FilterChip(
                            selected = apiKey.isNotBlank(),
                            onClick = { showSettings = !showSettings },
                            label = { Text(if (apiKey.isBlank()) "KEY REQUIRED" else "KEY SAVED") }
                        )
                    }

                    if (showSettings) {
                        Spacer(Modifier.height(10.dp))
                        OutlinedTextField(
                            value = apiKey,
                            onValueChange = viewModel::setApiKey,
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text("CricAPI API key") },
                            singleLine = true
                        )
                        Spacer(Modifier.height(8.dp))
                        Button(
                            onClick = {
                                showSettings = false
                                viewModel.loadMatches()
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = PitchGreen)
                        ) {
                            Text("CONNECT & LOAD LIVE MATCHES", color = DeepSlateNavy, fontWeight = FontWeight.ExtraBold)
                        }
                    }
                }
            }
        }

        if (loading) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(20.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    CircularProgressIndicator(color = PitchGreen)
                    Spacer(Modifier.width(12.dp))
                    Text("Fetching live T20 matches...", color = MutedText)
                }
            }
        }

        error?.let { message ->
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF3B1F2B))) {
                    Text(message, color = Danger, modifier = Modifier.padding(14.dp))
                }
            }
        }

        if (!loading && matches.isEmpty()) {
            item {
                EmptyState()
            }
        }

        items(matches, key = { it.id.orEmpty() }) { match ->
            LiveMatchCard(match = match, onPredict = { onPredict(match) })
        }
    }
}

@Composable
private fun HeroCard(title: String, subtitle: String) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Slate),
        shape = RoundedCornerShape(24.dp)
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .background(
                    androidx.compose.ui.graphics.Brush.horizontalGradient(
                        listOf(Slate, Color(0xFF132B36))
                    )
                )
                .padding(20.dp)
        ) {
            Text(title, color = PitchGreen, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.height(6.dp))
            Text(subtitle, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 30.sp)
            Spacer(Modifier.height(8.dp))
            Text("Pattern engine • What-if simulator • Offline snapshots", color = MutedText, fontSize = 12.sp)
        }
    }
}

@Composable
private fun LiveMatchCard(match: CricketMatchDto, onPredict: () -> Unit) {
    val teamA = match.teams.getOrElse(0) { "Team A" }
    val teamB = match.teams.getOrElse(1) { "Team B" }
    val latest = match.score.lastOrNull()
    val scoreText = if (latest != null) {
        "${latest.r ?: 0}/${latest.w ?: 0}  •  ${(latest.o ?: 0.0)} ov"
    } else {
        "Score unavailable"
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = Slate),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(9.dp).clip(CircleShape).background(PitchGreen)
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    match.status ?: "LIVE",
                    color = PitchGreen,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp
                )
                Spacer(Modifier.weight(1f))
                Text(match.matchType?.uppercase() ?: "T20", color = MutedText, fontSize = 11.sp)
            }

            Spacer(Modifier.height(14.dp))
            Text(match.name ?: "$teamA vs $teamB", fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))

            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(teamA, fontWeight = FontWeight.SemiBold)
                    Text(teamB, color = MutedText)
                }
                Text(scoreText, color = ElectricCyan, fontWeight = FontWeight.ExtraBold)
            }

            Spacer(Modifier.height(12.dp))
            if (!match.venue.isNullOrBlank()) {
                Text(match.venue, color = MutedText, fontSize = 11.sp)
                Spacer(Modifier.height(10.dp))
            }

            Button(
                onClick = onPredict,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = PitchGreen)
            ) {
                Icon(Icons.Default.Analytics, contentDescription = null, tint = DeepSlateNavy)
                Spacer(Modifier.width(8.dp))
                Text("OPEN PATTERN PREDICTION", color = DeepSlateNavy, fontWeight = FontWeight.ExtraBold)
            }
        }
    }
}

@Composable
private fun EmptyState() {
    Card(
        colors = CardDefaults.cardColors(containerColor = Slate),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(
            Modifier.fillMaxWidth().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(Icons.Default.SportsCricket, contentDescription = null, tint = ElectricCyan, modifier = Modifier.size(42.dp))
            Spacer(Modifier.height(10.dp))
            Text("No T20 matches loaded", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text("Connect a CricAPI key and refresh to fetch the current match list.", color = MutedText, fontSize = 12.sp)
        }
    }
}

@Composable
private fun PredictionScreen(
    modifier: Modifier,
    viewModel: CricketViewModel,
    match: CricketMatchDto?
) {
    var target by remember(match?.id) { mutableIntStateOf(match?.score?.lastOrNull()?.r ?: 160) }
    var oversLeft by remember(match?.id) { mutableFloatStateOf(10f) }
    var wicketsLost by remember(match?.id) { mutableIntStateOf(match?.score?.lastOrNull()?.w ?: 3) }
    var weighting by remember(match?.id) { mutableFloatStateOf(0.65f) }

    val probability = calculateProbability(target, oversLeft, wicketsLost, weighting)
    val animatedProbability by animateFloatAsState(
        targetValue = probability,
        animationSpec = tween(650),
        label = "winProbability"
    )

    val powerplayRisk = riskForPhase(oversLeft, 6f, wicketsLost)
    val middleRisk = riskForPhase(oversLeft, 10f, wicketsLost)
    val deathRisk = riskForPhase(oversLeft, 4f, wicketsLost)

    LazyColumn(
        modifier = modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(vertical = 16.dp)
    ) {
        item {
            HeroCard(
                title = "PATTERN LAB",
                subtitle = match?.name ?: "Manual match prediction"
            )
        }

        item {
            ProbabilityCard(animatedProbability)
        }

        item {
            SimulatorCard(
                target = target,
                onTargetChange = { target = it },
                oversLeft = oversLeft,
                onOversChange = { oversLeft = it },
                wicketsLost = wicketsLost,
                onWicketsChange = { wicketsLost = it },
                weighting = weighting,
                onWeightingChange = { weighting = it }
            )
        }

        item {
            RiskCard(powerplayRisk, middleRisk, deathRisk)
        }

        item {
            Button(
                onClick = {
                    viewModel.savePrediction(
                        match = match ?: CricketMatchDto(teams = listOf("Manual Team A", "Manual Team B")),
                        probability = probability,
                        targetScore = target,
                        oversLeft = oversLeft,
                        wicketsLost = wicketsLost,
                        userWeighting = weighting,
                        powerplayRisk = powerplayRisk,
                        middleRisk = middleRisk,
                        deathRisk = deathRisk
                    )
                },
                modifier = Modifier.fillMaxWidth().height(54.dp),
                colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan)
            ) {
                Icon(Icons.Default.Save, contentDescription = null, tint = DeepSlateNavy)
                Spacer(Modifier.width(8.dp))
                Text("SAVE SNAPSHOT OFFLINE", color = DeepSlateNavy, fontWeight = FontWeight.ExtraBold)
            }
        }
    }
}

private fun calculateProbability(
    target: Int,
    oversLeft: Float,
    wicketsLost: Int,
    weighting: Float
): Float {
    val targetPressure = ((target - 130f) / 90f).coerceIn(-1f, 1f)
    val timeFactor = (oversLeft / 20f).coerceIn(0f, 1f)
    val wicketPressure = (wicketsLost / 10f).coerceIn(0f, 1f)
    val raw = 0.50f - targetPressure * 0.18f + timeFactor * 0.18f - wicketPressure * 0.24f
    return (raw * weighting + 0.50f * (1f - weighting)).coerceIn(0.02f, 0.98f)
}

private fun riskForPhase(oversLeft: Float, phaseOvers: Float, wicketsLost: Int): Float {
    val phaseExposure = (phaseOvers - oversLeft.coerceAtMost(phaseOvers)).coerceIn(0f, phaseOvers) / phaseOvers
    return (0.25f + phaseExposure * 0.55f + wicketsLost * 0.025f).coerceIn(0f, 1f)
}

@Composable
private fun ProbabilityCard(probability: Float) {
    val pct = probability * 100f
    Card(colors = CardDefaults.cardColors(containerColor = Slate), shape = RoundedCornerShape(22.dp)) {
        Column(Modifier.fillMaxWidth().padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("LIVE WIN PROBABILITY", color = MutedText, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.weight(1f))
                Text("${pct.roundToInt()}%", color = PitchGreen, fontSize = 28.sp, fontWeight = FontWeight.Black)
            }
            Spacer(Modifier.height(14.dp))
            LinearProgressIndicator(
                progress = { probability },
                modifier = Modifier.fillMaxWidth().height(12.dp).clip(RoundedCornerShape(20.dp)),
                color = PitchGreen,
                trackColor = DeepSlateNavy
            )
            Spacer(Modifier.height(10.dp))
            Text(
                when {
                    pct >= 65 -> "MODEL LEAN: STRONG"
                    pct >= 52 -> "MODEL LEAN: POSITIVE"
                    pct <= 35 -> "MODEL LEAN: AGAINST"
                    else -> "MODEL LEAN: NEUTRAL"
                },
                color = ElectricCyan,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp
            )
        }
    }
}

@Composable
private fun SimulatorCard(
    target: Int,
    onTargetChange: (Int) -> Unit,
    oversLeft: Float,
    onOversChange: (Float) -> Unit,
    wicketsLost: Int,
    onWicketsChange: (Int) -> Unit,
    weighting: Float,
    onWeightingChange: (Float) -> Unit
) {
    Card(colors = CardDefaults.cardColors(containerColor = Slate), shape = RoundedCornerShape(22.dp)) {
        Column(Modifier.padding(18.dp)) {
            Text("WHAT-IF MATCH SIMULATOR", fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
            Text("Move the inputs and watch the model respond.", color = MutedText, fontSize = 11.sp)
            Spacer(Modifier.height(14.dp))

            SliderRow("TARGET SCORE", "$target", target.toFloat(), 80f..240f) {
                onTargetChange(it.roundToInt())
            }
            SliderRow("OVERS LEFT", String.format("%.1f", oversLeft), oversLeft, 0f..20f, onOversChange)
            SliderRow("WICKETS LOST", "$wicketsLost", wicketsLost.toFloat(), 0f..10f) {
                onWicketsChange(it.roundToInt())
            }
            SliderRow("USER WEIGHTING", "${(weighting * 100).roundToInt()}%", weighting, 0f..1f, onWeightingChange)
        }
    }
}

@Composable
private fun SliderRow(
    label: String,
    valueText: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onChange: (Float) -> Unit
) {
    Column {
        Row {
            Text(label, color = MutedText, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            Text(valueText, color = ElectricCyan, fontWeight = FontWeight.ExtraBold)
        }
        Slider(
            value = value,
            onValueChange = onChange,
            valueRange = range,
            colors = androidx.compose.material3.SliderDefaults.colors(
                thumbColor = PitchGreen,
                activeTrackColor = PitchGreen,
                inactiveTrackColor = DeepSlateNavy
            )
        )
    }
}

@Composable
private fun RiskCard(powerplay: Float, middle: Float, death: Float) {
    Card(colors = CardDefaults.cardColors(containerColor = Slate), shape = RoundedCornerShape(22.dp)) {
        Column(Modifier.padding(18.dp)) {
            Text("PHASE RISK BREAKDOWN", fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
            Spacer(Modifier.height(14.dp))
            RiskRow("POWERPLAY", powerplay)
            RiskRow("MIDDLE OVERS", middle)
            RiskRow("DEATH OVERS", death)
        }
    }
}

@Composable
private fun RiskRow(label: String, value: Float) {
    Column(Modifier.padding(bottom = 12.dp)) {
        Row {
            Text(label, color = MutedText, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            Text("${(value * 100).roundToInt()}%", color = ElectricCyan, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(5.dp))
        LinearProgressIndicator(
            progress = { value },
            modifier = Modifier.fillMaxWidth().height(7.dp).clip(RoundedCornerShape(20.dp)),
            color = if (value > 0.65f) Danger else PitchGreen,
            trackColor = DeepSlateNavy
        )
    }
}

@Composable
private fun SavedScreen(
    modifier: Modifier,
    viewModel: CricketViewModel
) {
    val predictions by viewModel.savedPredictions.collectAsState(initial = emptyList())

    LazyColumn(
        modifier = modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(vertical = 16.dp)
    ) {
        item {
            HeroCard(
                title = "OFFLINE VAULT",
                subtitle = "Your prediction snapshots stay available without the network."
            )
        }

        if (predictions.isEmpty()) {
            item { EmptySavedState() }
        }

        items(predictions, key = { it.id }) { prediction ->
            SavedPredictionCard(prediction, onDelete = { viewModel.deletePrediction(prediction.id) })
        }
    }
}

@Composable
private fun EmptySavedState() {
    Card(colors = CardDefaults.cardColors(containerColor = Slate), shape = RoundedCornerShape(18.dp)) {
        Text(
            "No snapshots yet. Open a match, tune the simulator, and save your first pattern prediction.",
            color = MutedText,
            modifier = Modifier.padding(18.dp)
        )
    }
}

@Composable
private fun SavedPredictionCard(prediction: MatchPrediction, onDelete: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Slate), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(16.dp)) {
            Text(prediction.matchName, fontWeight = FontWeight.Bold)
            Text("${prediction.teamA} vs ${prediction.teamB}", color = MutedText, fontSize = 12.sp)
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Win probability", color = MutedText)
                Text("${(prediction.predictedWinProbability * 100).roundToInt()}%", color = PitchGreen, fontWeight = FontWeight.ExtraBold)
            }
            Text(
                "Target ${prediction.targetScore} • ${prediction.oversLeft} ov left • ${prediction.wicketsLost} wickets lost",
                color = ElectricCyan,
                fontSize = 11.sp
            )
            Spacer(Modifier.height(8.dp))
            Button(
                onClick = onDelete,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3B1F2B))
            ) {
                Text("DELETE SNAPSHOT", color = Danger, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}
