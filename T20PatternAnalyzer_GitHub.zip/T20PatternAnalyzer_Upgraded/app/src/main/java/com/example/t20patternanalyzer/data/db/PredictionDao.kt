package com.example.t20patternanalyzer.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface PredictionDao {
    @Insert
    suspend fun insert(prediction: MatchPrediction): Long

    @Query("SELECT * FROM match_predictions ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<MatchPrediction>>

    @Query("DELETE FROM match_predictions WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM match_predictions")
    suspend fun deleteAll()
}
