package com.example.t20patternanalyzer.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "match_predictions")
data class MatchPrediction(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val matchId: String,
    val matchName: String,
    val teamA: String,
    val teamB: String,
    val predictedWinProbability: Float,
    val targetScore: Int,
    val oversLeft: Float,
    val wicketsLost: Int,
    val userWeighting: Float,
    val powerplayRisk: Float,
    val middleRisk: Float,
    val deathRisk: Float,
    val createdAt: Long = System.currentTimeMillis()
)
