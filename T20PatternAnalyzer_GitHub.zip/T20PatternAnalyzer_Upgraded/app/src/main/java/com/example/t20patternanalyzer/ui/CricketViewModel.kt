package com.example.t20patternanalyzer.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.t20patternanalyzer.data.api.CricketApiResponse
import com.example.t20patternanalyzer.data.api.CricketApiService
import com.example.t20patternanalyzer.data.api.CricketMatchDto
import com.example.t20patternanalyzer.data.db.AppDatabase
import com.example.t20patternanalyzer.data.db.MatchPrediction
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import okhttp3.logging.HttpLoggingInterceptor
import okhttp3.OkHttpClient

class CricketViewModel(application: Application) : AndroidViewModel(application) {

    private val dao = AppDatabase.getInstance(application).predictionDao()

    private val api: CricketApiService by lazy {
        val logging = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BASIC
        }
        val client = OkHttpClient.Builder()
            .addInterceptor(logging)
            .build()

        Retrofit.Builder()
            .baseUrl(CricketApiService.BASE_URL)
            .client(client)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(CricketApiService::class.java)
    }

    private val _matches = MutableStateFlow<List<CricketMatchDto>>(emptyList())
    val matches: StateFlow<List<CricketMatchDto>> = _matches.asStateFlow()

    private val _loading = MutableStateFlow(false)
    val loading: StateFlow<Boolean> = _loading.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    private val _savedPredictions = dao.observeAll()
    val savedPredictions = _savedPredictions

    private val _apiKey = MutableStateFlow("")
    val apiKey: StateFlow<String> = _apiKey.asStateFlow()

    fun setApiKey(value: String) {
        _apiKey.value = value
    }

    fun loadMatches() {
        val key = _apiKey.value.trim()
        if (key.isBlank()) {
            _error.value = "Enter your CricAPI key first."
            return
        }

        viewModelScope.launch(Dispatchers.IO) {
            _loading.value = true
            _error.value = null
            try {
                val response: CricketApiResponse = api.getCurrentMatches(key)
                if (response.status.equals("success", ignoreCase = true)) {
                    _matches.value = response.data.filter {
                        it.matchType.equals("t20", ignoreCase = true) ||
                            it.name.orEmpty().contains("T20", ignoreCase = true)
                    }
                } else {
                    _error.value = response.message ?: "The cricket API returned an error."
                }
            } catch (e: Exception) {
                _error.value = e.message ?: "Unable to load live matches."
            } finally {
                _loading.value = false
            }
        }
    }

    fun savePrediction(
        match: CricketMatchDto,
        probability: Float,
        targetScore: Int,
        oversLeft: Float,
        wicketsLost: Int,
        userWeighting: Float,
        powerplayRisk: Float,
        middleRisk: Float,
        deathRisk: Float
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            val teams = match.teams + listOf("Team A", "Team B")
            dao.insert(
                MatchPrediction(
                    matchId = match.id.orEmpty(),
                    matchName = match.name ?: "T20 Match",
                    teamA = teams.getOrElse(0) { "Team A" },
                    teamB = teams.getOrElse(1) { "Team B" },
                    predictedWinProbability = probability,
                    targetScore = targetScore,
                    oversLeft = oversLeft,
                    wicketsLost = wicketsLost,
                    userWeighting = userWeighting,
                    powerplayRisk = powerplayRisk,
                    middleRisk = middleRisk,
                    deathRisk = deathRisk
                )
            )
        }
    }

    fun deletePrediction(id: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            dao.deleteById(id)
        }
    }
}
