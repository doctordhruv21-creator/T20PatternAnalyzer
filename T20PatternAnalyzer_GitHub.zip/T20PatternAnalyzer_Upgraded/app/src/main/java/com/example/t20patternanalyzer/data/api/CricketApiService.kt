package com.example.t20patternanalyzer.data.api

import retrofit2.http.GET
import retrofit2.http.Query

data class CricketApiResponse(
    val status: String? = null,
    val message: String? = null,
    val data: List<CricketMatchDto> = emptyList()
)

data class CricketMatchDto(
    val id: String? = null,
    val name: String? = null,
    val matchType: String? = null,
    val status: String? = null,
    val venue: String? = null,
    val date: String? = null,
    val dateTimeGMT: String? = null,
    val teams: List<String> = emptyList(),
    val teamInfo: List<TeamInfoDto> = emptyList(),
    val score: List<ScoreDto> = emptyList(),
    val tossWinner: String? = null,
    val tossChoice: String? = null
)

data class TeamInfoDto(
    val name: String? = null,
    val shortname: String? = null,
    val img: String? = null
)

data class ScoreDto(
    val r: Int? = null,
    val w: Int? = null,
    val o: Double? = null,
    val inning: String? = null
)

interface CricketApiService {
    @GET("v1/currentMatches")
    suspend fun getCurrentMatches(
        @Query("apikey") apiKey: String,
        @Query("offset") offset: Int = 0
    ): CricketApiResponse

    companion object {
        const val BASE_URL = "https://api.cricapi.com/"
    }
}
