# T20 Pattern Analyzer keeps release minification disabled by default.
