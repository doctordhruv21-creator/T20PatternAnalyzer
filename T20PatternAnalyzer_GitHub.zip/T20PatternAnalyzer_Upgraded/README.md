# T20 Pattern Analyzer — Upgraded

A modern Kotlin + Jetpack Compose Material 3 T20 cricket analysis application.

## Included

- Dark Stadium UI using Deep Slate Navy, Slate, Pitch Green and Electric Cyan.
- Live T20 match feed through Retrofit + Gson using the CricAPI `currentMatches` endpoint structure.
- Live win-probability gauge with `animateFloatAsState`.
- Interactive What-If simulator:
  - Target Score
  - Overs Left
  - Wickets Lost
  - User Weighting
- Phase Risk Breakdown for Powerplay, Middle Overs and Death Overs.
- Room offline storage for prediction snapshots.
- Bottom navigation for Live, Predict and Saved.
- API key entry is kept out of source code.

## Build

Open the project in Android Studio with JDK 17. The source has been corrected for the Retrofit/OkHttp logging package and Material 3 experimental API opt-in.

Run:

`./gradlew :app:assembleDebug`

The project uses Android Gradle Plugin 8.7.3, Kotlin 2.0.21 and Jetpack Compose Material 3.

## CricAPI

Enter a valid CricAPI key in the Live Match Center. The service expects the documented `/v1/currentMatches` response shape, including a top-level `status` and `data` array.

The API key is entered at runtime and is not hard-coded into this project.
