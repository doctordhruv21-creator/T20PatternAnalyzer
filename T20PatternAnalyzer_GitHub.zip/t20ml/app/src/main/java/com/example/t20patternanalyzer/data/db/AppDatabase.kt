package com.example.t20patternanalyzer.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(entities = [MatchPrediction::class], version = 2, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun predictionDao(): PredictionDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE match_predictions ADD COLUMN battingFirst INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE match_predictions ADD COLUMN firstInningsScore INTEGER")
                db.execSQL("ALTER TABLE match_predictions ADD COLUMN isTwentyOvers INTEGER NOT NULL DEFAULT 1")
                db.execSQL("ALTER TABLE match_predictions ADD COLUMN openingFavourite INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE match_predictions ADD COLUMN preFirstBallOdds REAL")
                db.execSQL("ALTER TABLE match_predictions ADD COLUMN firstBallOdds REAL")
                db.execSQL("ALTER TABLE match_predictions ADD COLUMN inningsBreakFavourite INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE match_predictions ADD COLUMN inningsBreakOdds REAL")
                db.execSQL("ALTER TABLE match_predictions ADD COLUMN lambiType TEXT NOT NULL DEFAULT 'LAMBI'")
                db.execSQL("ALTER TABLE match_predictions ADD COLUMN lambi REAL")
                db.execSQL("ALTER TABLE match_predictions ADD COLUMN teamAPreviousMatch INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE match_predictions ADD COLUMN teamBPreviousMatch INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE match_predictions ADD COLUMN teamAClose INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE match_predictions ADD COLUMN teamBClose INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE match_predictions ADD COLUMN p5Input INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE match_predictions ADD COLUMN outcome TEXT NOT NULL DEFAULT 'PENDING'")
                db.execSQL("ALTER TABLE match_predictions ADD COLUMN actualWinner INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE match_predictions ADD COLUMN resolvedAt INTEGER")
            }
        }

        fun getInstance(context: Context): AppDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(
                context.applicationContext,
                AppDatabase::class.java,
                "t20_pattern_analyzer.db"
            ).addMigrations(MIGRATION_1_2).build().also { INSTANCE = it }
        }
    }
}
