package com.example.t20patternanalyzer

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SportsCricket
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.t20patternanalyzer.data.api.CricketMatchDto
import com.example.t20patternanalyzer.engine.AnalysisResult
import com.example.t20patternanalyzer.engine.PatternInput
import com.example.t20patternanalyzer.ui.CricketViewModel
import kotlin.math.roundToInt

private val Navy = Color(0xFF0F172A)
private val Slate = Color(0xFF1E293B)
private val Green = Color(0xFF10B981)
private val Cyan = Color(0xFF38BDF8)
private val Muted = Color(0xFF94A3B8)
private val Red = Color(0xFFF87171)
private val Amber = Color(0xFFF59E0B)

private enum class Tab { LIVE, PREDICT, SAVED }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Navy.toArgb()
        window.navigationBarColor = Navy.toArgb()
        setContent {
            T20Theme {
                T20App()
            }
        }
    }
}

@Composable
private fun T20Theme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = androidx.compose.material3.darkColorScheme(
            primary = Green,
            secondary = Cyan,
            background = Navy,
            surface = Slate,
            onBackground = Color.White,
            onSurface = Color.White
        ),
        content = content
    )
}

@Composable
private fun T20App(vm: CricketViewModel = viewModel()) {
    var tab by rememberSaveable { mutableStateOf(Tab.LIVE) }
    var selectedMatch by remember { mutableStateOf<CricketMatchDto?>(null) }

    Scaffold(
        containerColor = Navy,
        bottomBar = {
            NavigationBar(containerColor = Slate) {
                NavigationBarItem(
                    selected = tab == Tab.LIVE,
                    onClick = { tab = Tab.LIVE },
                    icon = { Icon(Icons.Default.SportsCricket, contentDescription = "Live") },
                    label = { Text("LIVE") }
                )
                NavigationBarItem(
                    selected = tab == Tab.PREDICT,
                    onClick = { tab = Tab.PREDICT },
                    icon = { Icon(Icons.Default.Analytics, contentDescription = "Predict") },
                    label = { Text("PREDICT") }
                )
                NavigationBarItem(
                    selected = tab == Tab.SAVED,
                    onClick = { tab = Tab.SAVED },
                    icon = { Icon(Icons.Default.Save, contentDescription = "Saved") },
                    label = { Text("SAVED") }
                )
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            Header(
                tab = tab,
                onRefresh = {
                    if (tab == Tab.LIVE) {
                        vm.loadMatches()
                    }
                }
            )

            when (tab) {
                Tab.LIVE -> LiveScreen(vm) {
                    selectedMatch = it
                    tab = Tab.PREDICT
                }
                Tab.PREDICT -> PredictionScreen(vm, selectedMatch)
                Tab.SAVED -> SavedScreen(vm)
            }
        }
    }
}

@Composable
private fun Header(tab: Tab, onRefresh: () -> Unit) {
    Surface(color = Navy) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    "T20 PATTERN ANALYZER",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Black
                )
                Text(
                    when (tab) {
                        Tab.LIVE -> "LIVE MATCH CENTER"
                        Tab.PREDICT -> "P1–P6 DECISION ENGINE"
                        Tab.SAVED -> "OFFLINE SNAPSHOTS"
                    },
                    color = Cyan,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            IconButton(onClick = onRefresh) {
                Icon(Icons.Default.Refresh, contentDescription = "Refresh", tint = Cyan)
            }
        }
    }
}

@Composable
private fun Hero(title: String, subtitle: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Slate),
        shape = RoundedCornerShape(24.dp)
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Text(title, color = Green, fontSize = 11.sp, fontWeight = FontWeight.Black)
            Spacer(Modifier.height(5.dp))
            Text(subtitle, fontSize = 23.sp, lineHeight = 28.sp, fontWeight = FontWeight.Black)
            Spacer(Modifier.height(7.dp))
            Text(
                "Original P1–P6 engine • market-aware • conflict-aware",
                color = Muted,
                fontSize = 11.sp
            )
        }
    }
}

@Composable
private fun LiveScreen(vm: CricketViewModel, onPredict: (CricketMatchDto) -> Unit) {
    val matches by vm.matches.collectAsState()
    val loading by vm.loading.collectAsState()
    val error by vm.error.collectAsState()
    val apiKey by vm.apiKey.collectAsState()
    var keyInput by rememberSaveable { mutableStateOf("") }
    var showSettings by rememberSaveable { mutableStateOf(true) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(vertical = 14.dp)
    ) {
        item {
            Hero(
                "LIVE MATCH CENTER",
                "Connect your cricket API, choose a live T20, and open the real P1–P6 form."
            )
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Slate),
                shape = RoundedCornerShape(18.dp)
            ) {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Settings, contentDescription = null, tint = Cyan)
                        Spacer(Modifier.width(8.dp))
                        Text("CRICKET API", fontWeight = FontWeight.Bold)
                        Spacer(Modifier.weight(1f))
                        Text(
                            if (apiKey.isBlank()) "NOT CONNECTED" else "CONNECTED",
                            color = if (apiKey.isBlank()) Amber else Green,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    if (showSettings) {
                        Spacer(Modifier.height(10.dp))
                        OutlinedTextField(
                            value = keyInput,
                            onValueChange = { keyInput = it },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text("CricAPI API key") },
                            singleLine = true
                        )
                        Spacer(Modifier.height(8.dp))
                        Button(
                            onClick = {
                                vm.setApiKey(keyInput)
                                showSettings = false
                                vm.loadMatches()
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = Green)
                        ) {
                            Text("CONNECT & LOAD T20", color = Navy, fontWeight = FontWeight.Black)
                        }
                    } else {
                        Spacer(Modifier.height(8.dp))
                        OutlinedButton(
                            onClick = { showSettings = true },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("CHANGE API KEY")
                        }
                    }
                }
            }
        }

        if (loading) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                    horizontalArrangement = Arrangement.Center
                ) {
                    Text("Loading live matches…", color = Cyan, fontWeight = FontWeight.Bold)
                }
            }
        }

        error?.let { message ->
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF3B2430)),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Text(
                        message,
                        modifier = Modifier.padding(14.dp),
                        color = Red,
                        fontSize = 12.sp
                    )
                }
            }
        }

        if (matches.isEmpty() && !loading) {
            item {
                Text(
                    "No T20 matches loaded yet. Enter a valid API key and tap Connect.",
                    color = Muted,
                    modifier = Modifier.padding(8.dp)
                )
            }
        }

        items(matches, key = { it.id.orEmpty() }) { match ->
            LiveMatchCard(match, onPredict)
        }
    }
}

@Composable
private fun LiveMatchCard(match: CricketMatchDto, onPredict: (CricketMatchDto) -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Slate),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(
                match.name ?: "T20 Match",
                fontSize = 17.sp,
                fontWeight = FontWeight.Black
            )
            Spacer(Modifier.height(4.dp))
            Text(
                match.status ?: "Status unavailable",
                color = Cyan,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(12.dp))

            match.score.takeLast(2).forEach { score ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(score.inning ?: "Innings", color = Muted, fontSize = 11.sp)
                    Text(
                        "${score.r ?: 0}/${score.w ?: 0}  (${score.o ?: 0.0})",
                        fontWeight = FontWeight.Black
                    )
                }
                Spacer(Modifier.height(4.dp))
            }

            Spacer(Modifier.height(10.dp))
            Button(
                onClick = { onPredict(match) },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Green)
            ) {
                Text("OPEN P1–P6 PREDICTION", color = Navy, fontWeight = FontWeight.Black)
            }
        }
    }
}

@Composable
private fun PredictionScreen(vm: CricketViewModel, match: CricketMatchDto?) {
    val teams = match?.teams.orEmpty()
    var teamA by rememberSaveable(match?.id) { mutableStateOf(teams.getOrNull(0).orEmpty()) }
    var teamB by rememberSaveable(match?.id) { mutableStateOf(teams.getOrNull(1).orEmpty()) }
    var battingFirst by rememberSaveable(match?.id) { mutableIntStateOf(0) }
    var firstScore by rememberSaveable(match?.id) {
        mutableStateOf(match?.score?.firstOrNull()?.r?.toString().orEmpty())
    }
    var isTwentyOvers by rememberSaveable(match?.id) { mutableStateOf(true) }

    var openingFavourite by rememberSaveable { mutableIntStateOf(0) }
    var preFirstBallOdds by rememberSaveable { mutableStateOf("") }
    var firstBallOdds by rememberSaveable { mutableStateOf("") }

    var lambiType by rememberSaveable { mutableIntStateOf(0) }
    var lambi by rememberSaveable { mutableStateOf("") }
    var inningsBreakFavourite by rememberSaveable { mutableIntStateOf(0) }
    var inningsBreakOdds by rememberSaveable { mutableStateOf("") }

    var teamAPreviousMatch by rememberSaveable { mutableIntStateOf(0) }
    var teamBPreviousMatch by rememberSaveable { mutableIntStateOf(0) }
    var teamAClose by rememberSaveable { mutableStateOf(false) }
    var teamBClose by rememberSaveable { mutableStateOf(false) }
    var p5 by rememberSaveable { mutableIntStateOf(0) }

    var result by remember { mutableStateOf<AnalysisResult?>(null) }

    val team1 = teamA.ifBlank { "Team 1" }
    val team2 = teamB.ifBlank { "Team 2" }
    val teamOptions = listOf("Select team", team1, team2)
    val actualScore = firstScore.toDoubleOrNull()
    val lambiValue = lambi.toDoubleOrNull()
    val lambiDifference = if (actualScore != null && lambiValue != null) actualScore - lambiValue else null

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(bottom = 20.dp)
    ) {
        item {
            Hero(
                "PATTERN LAB",
                match?.name ?: "Manual match analysis"
            )
        }

        item {
            Section("1  •  MATCH") {
                TextFieldLine("TEAM 1 NAME", teamA) { teamA = it }
                TextFieldLine("TEAM 2 NAME", teamB) { teamB = it }
                Choice("BATTING FIRST", battingFirst, teamOptions) { battingFirst = it }
                NumberField("INNINGS BREAK SCORE", firstScore) { firstScore = it }
                Choice(
                    "INNINGS FORMAT",
                    if (isTwentyOvers) 0 else 1,
                    listOf("20 overs", "Shortened innings")
                ) { isTwentyOvers = it == 0 }
                Text(
                    "Enter the score once — P1 and P6 will use it automatically.",
                    color = Muted,
                    fontSize = 11.sp
                )
            }
        }

        item {
            Section("2  •  OPENING MARKET") {
                Choice("OPENING FAVOURITE", openingFavourite, teamOptions) {
                    openingFavourite = it
                }
                NumberField("ODDS BEFORE FIRST BALL", preFirstBallOdds) {
                    preFirstBallOdds = it
                }
                NumberField("ODDS AFTER FIRST BALL", firstBallOdds) {
                    firstBallOdds = it
                }
                Text(
                    "P4 automatically measures the opening → first-ball movement. Signal only when movement is > 0.10.",
                    color = Muted,
                    fontSize = 11.sp
                )
            }
        }

        item {
            Section("3  •  P6  •  LAMBI + INNINGS BREAK") {
                Choice(
                    "LAMBI TYPE",
                    lambiType,
                    listOf("Select type", "OPEN LAMBI", "20 OVER RUNLINE")
                ) { lambiType = it }
                NumberField("LAMBI / RUNLINE", lambi) { lambi = it }

                if (lambiDifference != null) {
                    val direction = when {
                        lambiDifference < 0 -> "LESS THAN LAMBI"
                        lambiDifference > 0 -> "MORE THAN LAMBI"
                        else -> "EQUAL TO LAMBI"
                    }
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Navy),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Column(Modifier.padding(12.dp)) {
                            Text("AUTO-CALCULATED", color = Cyan, fontSize = 10.sp, fontWeight = FontWeight.Black)
                            Spacer(Modifier.height(3.dp))
                            Text(
                                "${actualScore!!.roundToInt()} − ${lambiValue!!.formatOneDecimal()} = ${if (lambiDifference >= 0) "+" else ""}${lambiDifference.formatOneDecimal()} runs",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Black
                            )
                            Text(
                                direction,
                                color = if (lambiDifference < 0) Green else if (lambiDifference > 0) Amber else Muted,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                }

                Choice("INNINGS-BREAK FAVOURITE", inningsBreakFavourite, teamOptions) {
                    inningsBreakFavourite = it
                }
                NumberField("INNINGS-BREAK ODDS", inningsBreakOdds) {
                    inningsBreakOdds = it
                }
                Text(
                    "P6 uses the pre-first-ball odds as its baseline, applies 0.0065 per run, and checks the market difference against the strict >0.10 threshold.",
                    color = Cyan,
                    fontSize = 11.sp
                )
            }
        }

        item {
            Section("4  •  PREVIOUS MATCH  •  P2 / P3") {
                Choice(
                    "$team1 PREVIOUS MATCH",
                    teamAPreviousMatch,
                    listOf(
                        "Unknown",
                        "Won — chasing",
                        "Won — defending",
                        "Lost — chasing",
                        "Lost — defending"
                    )
                ) { teamAPreviousMatch = it }
                Choice(
                    "$team2 PREVIOUS MATCH",
                    teamBPreviousMatch,
                    listOf(
                        "Unknown",
                        "Won — chasing",
                        "Won — defending",
                        "Lost — chasing",
                        "Lost — defending"
                    )
                ) { teamBPreviousMatch = it }
                CheckLine("$team1 close / volatile previous match", teamAClose) {
                    teamAClose = it
                }
                CheckLine("$team2 close / volatile previous match", teamBClose) {
                    teamBClose = it
                }
            }
        }

        item {
            Section("5  •  P5  •  FIRST-INNINGS SHAPE") {
                Choice(
                    "P5 SIGNAL",
                    p5,
                    listOf(
                        "No P5 signal",
                        "Collapse + recovery → CHASE",
                        "Steady / slower innings → DEFEND"
                    )
                ) { p5 = it }
            }
        }

        item {
            Button(
                onClick = {
                    result = vm.analyze(
                        PatternInput(
                            teamA = teamA,
                            teamB = teamB,
                            battingFirst = battingFirst,
                            firstInningsScore = firstScore.toIntOrNull(),
                            isTwentyOvers = isTwentyOvers,
                            openingFavourite = openingFavourite,
                            preFirstBallOdds = preFirstBallOdds.toDoubleOrNull(),
                            firstBallOdds = firstBallOdds.toDoubleOrNull(),
                            inningsBreakFavourite = inningsBreakFavourite,
                            inningsBreakOdds = inningsBreakOdds.toDoubleOrNull(),
                            lambiType = when (lambiType) {
                                1 -> "OPEN"
                                2 -> "20 OVER RUNLINE"
                                else -> "LAMBI"
                            },
                            lambi = lambiValue,
                            teamAPreviousMatch = teamAPreviousMatch,
                            teamBPreviousMatch = teamBPreviousMatch,
                            teamAClose = teamAClose,
                            teamBClose = teamBClose,
                            p5 = p5
                        )
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(58.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Green)
            ) {
                Text("ANALYSE P1–P6  →", color = Navy, fontWeight = FontWeight.Black)
            }
        }

        result?.let { analysis ->
            item { ResultCard(teamA, teamB, analysis) }
            item {
                Button(
                    onClick = {
                        vm.save(
                            match,
                            PatternInput(
                                teamA = teamA,
                                teamB = teamB,
                                battingFirst = battingFirst,
                                firstInningsScore = firstScore.toIntOrNull(),
                                isTwentyOvers = isTwentyOvers,
                                openingFavourite = openingFavourite,
                                preFirstBallOdds = preFirstBallOdds.toDoubleOrNull(),
                                firstBallOdds = firstBallOdds.toDoubleOrNull(),
                                inningsBreakFavourite = inningsBreakFavourite,
                                inningsBreakOdds = inningsBreakOdds.toDoubleOrNull(),
                                lambiType = when (lambiType) {
                                    1 -> "OPEN"
                                    2 -> "20 OVER RUNLINE"
                                    else -> "LAMBI"
                                },
                                lambi = lambiValue,
                                teamAPreviousMatch = teamAPreviousMatch,
                                teamBPreviousMatch = teamBPreviousMatch,
                                teamAClose = teamAClose,
                                teamBClose = teamBClose,
                                p5 = p5
                            ),
                            analysis
                        )
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Cyan)
                ) {
                    Icon(Icons.Default.Save, contentDescription = null, tint = Navy)
                    Spacer(Modifier.width(7.dp))
                    Text("SAVE TO ML DATASET", color = Navy, fontWeight = FontWeight.Black)
                }
            }
        }
    }
}

private fun Double.formatOneDecimal(): String = String.format(java.util.Locale.US, "%.1f", this)

@Composable
private fun Section(
    title: String,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Slate),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(title, color = Cyan, fontWeight = FontWeight.Black, fontSize = 11.sp)
            Spacer(Modifier.height(10.dp))
            content()
        }
    }
}

@Composable
private fun TextFieldLine(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 8.dp),
        label = { Text(label) },
        singleLine = true
    )
}

@Composable
private fun NumberField(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 8.dp),
        label = { Text(label) },
        singleLine = true
    )
}

@Composable
private fun Choice(
    label: String,
    value: Int,
    options: List<String>,
    onChange: (Int) -> Unit
) {
    var expanded by remember(label, value) { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 8.dp)
    ) {
        OutlinedButton(
            onClick = { expanded = true },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp)
        ) {
            Text(
                "$label  •  ${options.getOrElse(value) { options.first() }}",
                modifier = Modifier.fillMaxWidth()
            )
        }

        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
        ) {
            options.forEachIndexed { index, option ->
                DropdownMenuItem(
                    text = { Text(option) },
                    onClick = {
                        onChange(index)
                        expanded = false
                    }
                )
            }
        }
    }
}

@Composable
private fun CheckLine(
    text: String,
    checked: Boolean,
    onChange: (Boolean) -> Unit
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Checkbox(checked = checked, onCheckedChange = onChange)
        Text(text, color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun ResultCard(a: String, b: String, result: AnalysisResult) {
    fun teamName(team: Int): String = when (team) {
        1 -> a.ifBlank { "Team A" }
        2 -> b.ifBlank { "Team B" }
        else -> "—"
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = Slate),
        shape = RoundedCornerShape(22.dp)
    ) {
        Column(Modifier.padding(18.dp)) {
            Text("FINAL DECISION", color = Cyan, fontSize = 11.sp, fontWeight = FontWeight.Black)
            Spacer(Modifier.height(5.dp))
            Text(
                if (result.finalTeam == 0) "NO CLEAR SIGNAL" else teamName(result.finalTeam),
                fontSize = 29.sp,
                fontWeight = FontWeight.Black,
                color = if (result.status.startsWith("CONFLICT")) Amber else Green
            )
            Text(
                result.status,
                color = if (result.status.startsWith("CONFLICT")) Amber else Muted,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Metric("CONFIDENCE", "${result.confidence}/100")
                Metric("CORE", if (result.coreTeam == 0) "—" else teamName(result.coreTeam))
                Metric("MARKET", if (result.marketTeam == 0) "—" else teamName(result.marketTeam))
            }

            Spacer(Modifier.height(14.dp))
            Text("PATTERN DETAILS", fontWeight = FontWeight.Black)

            listOf("P3", "P5", "P1", "P2", "P4", "P6").forEach { pattern ->
                result.signals
                    .filter { it.pattern == pattern }
                    .forEach { signal ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 3.dp),
                            colors = CardDefaults.cardColors(containerColor = Navy),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Column(Modifier.padding(10.dp)) {
                                Text(
                                    "${signal.pattern}  •  ${teamName(signal.team)}",
                                    color = Cyan,
                                    fontWeight = FontWeight.Black,
                                    fontSize = 11.sp
                                )
                                Text(signal.text, fontSize = 11.sp, color = Color.White)
                            }
                        }
                    }
            }

            if (result.notes.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                Text("NOTES", fontWeight = FontWeight.Black)
                result.notes.forEach { note ->
                    Text(
                        "• $note",
                        color = Muted,
                        fontSize = 11.sp,
                        modifier = Modifier.padding(top = 3.dp)
                    )
                }
            }

            result.p6Expected?.let { expected ->
                Spacer(Modifier.height(8.dp))
                Text(
                    "P6  • expected %.2f  • market-implied %.2f  • difference %.2f"
                        .format(
                            expected,
                            result.p6Current ?: 0.0,
                            result.p6Difference ?: 0.0
                        ),
                    color = Cyan,
                    fontSize = 11.sp
                )
            }
        }
    }
}

@Composable
private fun Metric(key: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(key, color = Muted, fontSize = 9.sp)
        Text(value, color = Color.White, fontWeight = FontWeight.Black, fontSize = 13.sp)
    }
}

@Composable
private fun SavedScreen(vm: CricketViewModel) {
    val saved by vm.savedPredictions.collectAsState(initial = emptyList())
    val resolved = saved.filter { it.outcome == "WIN" || it.outcome == "LOSS" }
    val wins = resolved.count { it.outcome == "WIN" }
    val losses = resolved.count { it.outcome == "LOSS" }
    val accuracy = if (resolved.isEmpty()) 0 else (wins * 100.0 / resolved.size).roundToInt()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(vertical = 14.dp)
    ) {
        item {
            Hero(
                "ML DATA VAULT",
                "Every saved decision keeps its decision-time features so we can train and validate P7 later."
            )
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Slate),
                shape = RoundedCornerShape(18.dp)
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text("DATASET HEALTH", color = Cyan, fontSize = 11.sp, fontWeight = FontWeight.Black)
                    Spacer(Modifier.height(10.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Metric("SAVED", saved.size.toString())
                        Metric("PENDING", saved.count { it.outcome == "PENDING" }.toString())
                        Metric("RESOLVED", resolved.size.toString())
                        Metric("ACCURACY", if (resolved.isEmpty()) "—" else "$accuracy%")
                    }
                    Spacer(Modifier.height(10.dp))
                    Text(
                        if (resolved.isEmpty())
                            "Resolve completed predictions after the match. The app will then know whether the engine call was correct."
                        else
                            "WIN $wins  •  LOSS $losses  •  This accuracy is your recorded P1–P6 decision accuracy, not an ML score yet.",
                        color = Muted,
                        fontSize = 11.sp
                    )
                }
            }
        }

        if (saved.isEmpty()) {
            item {
                Text(
                    "No dataset records yet. Analyse a match and tap SAVE TO ML DATASET.",
                    color = Muted,
                    modifier = Modifier.padding(16.dp)
                )
            }
        }

        items(saved, key = { it.id }) { prediction ->
            Card(
                colors = CardDefaults.cardColors(containerColor = Slate),
                shape = RoundedCornerShape(18.dp)
            ) {
                Column(Modifier.padding(15.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(prediction.matchName, fontWeight = FontWeight.Black)
                            Text(
                                "${prediction.teamA} vs ${prediction.teamB}",
                                color = Muted,
                                fontSize = 11.sp
                            )
                        }
                        Text(
                            prediction.outcome,
                            color = when (prediction.outcome) {
                                "WIN" -> Green
                                "LOSS" -> Red
                                else -> Amber
                            },
                            fontWeight = FontWeight.Black,
                            fontSize = 11.sp
                        )
                    }

                    Spacer(Modifier.height(8.dp))
                    Text(
                        when (prediction.finalTeam) {
                            1 -> "PREDICTED  •  ${prediction.teamA}"
                            2 -> "PREDICTED  •  ${prediction.teamB}"
                            else -> "PREDICTED  •  NO CLEAR SIGNAL"
                        },
                        color = Green,
                        fontSize = 19.sp,
                        fontWeight = FontWeight.Black
                    )
                    Text(
                        "${prediction.status}  •  confidence ${prediction.confidence}/100",
                        color = Cyan,
                        fontSize = 11.sp
                    )

                    Spacer(Modifier.height(8.dp))
                    Text(
                        "FEATURES  •  score ${prediction.firstInningsScore ?: "—"}  •  pre-ball ${prediction.preFirstBallOdds?.formatOneDecimal() ?: "—"}  •  break ${prediction.inningsBreakOdds?.formatOneDecimal() ?: "—"}  •  Lambi ${prediction.lambi?.formatOneDecimal() ?: "—"}",
                        color = Muted,
                        fontSize = 10.sp
                    )

                    if (prediction.finalTeam in 1..2) {
                        Spacer(Modifier.height(8.dp))
                        Text("AFTER MATCH  •  who actually won?", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedButton(
                                onClick = { vm.updateOutcome(prediction.id, 1) },
                                modifier = Modifier.weight(1f)
                            ) { Text(prediction.teamA, fontSize = 10.sp) }
                            OutlinedButton(
                                onClick = { vm.updateOutcome(prediction.id, 2) },
                                modifier = Modifier.weight(1f)
                            ) { Text(prediction.teamB, fontSize = 10.sp) }
                        }
                        if (prediction.outcome != "PENDING") {
                            OutlinedButton(
                                onClick = { vm.resetOutcome(prediction.id) },
                                modifier = Modifier.fillMaxWidth()
                            ) { Text("RESET RESULT", fontSize = 10.sp) }
                        }
                    }

                    Spacer(Modifier.height(4.dp))
                    OutlinedButton(
                        onClick = { vm.delete(prediction.id) },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Red)
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = null, tint = Red)
                        Spacer(Modifier.width(5.dp))
                        Text("DELETE", color = Red, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun mutableFloatStateStatefulCompat(initial: Float): androidx.compose.runtime.MutableFloatState {
    return androidx.compose.runtime.mutableFloatStateOf(initial)
}
