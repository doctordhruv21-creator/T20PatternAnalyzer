package com.example.t20patternanalyzer.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.t20patternanalyzer.data.api.CricketApiService
import com.example.t20patternanalyzer.data.api.CricketMatchDto
import com.example.t20patternanalyzer.data.db.AppDatabase
import com.example.t20patternanalyzer.data.db.MatchPrediction
import com.example.t20patternanalyzer.engine.AnalysisResult
import com.example.t20patternanalyzer.engine.PatternEngine
import com.example.t20patternanalyzer.engine.PatternInput
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class CricketViewModel(application: Application) : AndroidViewModel(application) {

    private val dao = AppDatabase.getInstance(application).predictionDao()

    private val api: CricketApiService = Retrofit.Builder()
        .baseUrl(CricketApiService.BASE_URL)
        .client(
            OkHttpClient.Builder()
                .addInterceptor(
                    HttpLoggingInterceptor().apply {
                        level = HttpLoggingInterceptor.Level.BASIC
                    }
                )
                .build()
        )
        .addConverterFactory(GsonConverterFactory.create())
        .build()
        .create(CricketApiService::class.java)

    private val _matches = MutableStateFlow<List<CricketMatchDto>>(emptyList())
    val matches: StateFlow<List<CricketMatchDto>> = _matches.asStateFlow()

    private val _loading = MutableStateFlow(false)
    val loading: StateFlow<Boolean> = _loading.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    private val _apiKey = MutableStateFlow("")
    val apiKey: StateFlow<String> = _apiKey.asStateFlow()

    val savedPredictions = dao.observeAll().flowOn(Dispatchers.IO)

    fun setApiKey(value: String) {
        _apiKey.value = value.trim()
    }

    fun loadMatches() {
        val key = _apiKey.value.trim()
        if (key.isBlank()) {
            _error.value = "Enter your CricAPI key first."
            return
        }

        viewModelScope.launch(Dispatchers.IO) {
            _loading.value = true
            _error.value = null

            try {
                val response = api.getCurrentMatches(key)
                if (response.status.equals("success", ignoreCase = true)) {
                    _matches.value = response.data.filter { match ->
                        match.matchType.equals("t20", ignoreCase = true) ||
                            match.name.orEmpty().contains("T20", ignoreCase = true)
                    }
                } else {
                    _error.value = response.message ?: "Cricket API returned an error."
                }
            } catch (exception: Exception) {
                _error.value = exception.message ?: "Unable to load live matches."
            } finally {
                _loading.value = false
            }
        }
    }

    fun analyze(input: PatternInput): AnalysisResult {
        return PatternEngine.analyze(input)
    }

    fun save(
        match: CricketMatchDto?,
        input: PatternInput,
        result: AnalysisResult
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            val teamA = input.teamA.ifBlank { "Team A" }
            val teamB = input.teamB.ifBlank { "Team B" }

            fun patternText(pattern: String): String {
                return result.signals
                    .filter { it.pattern == pattern }
                    .joinToString(" | ") {
                        "${if (it.team == 1) teamA else teamB}: ${it.text}"
                    }
            }

            dao.insert(
                MatchPrediction(
                    matchId = match?.id.orEmpty(),
                    matchName = match?.name ?: "$teamA vs $teamB",
                    teamA = teamA,
                    teamB = teamB,
                    finalTeam = result.finalTeam,
                    status = result.status,
                    confidence = result.confidence,
                    coreTeam = result.coreTeam,
                    marketTeam = result.marketTeam,
                    p1 = patternText("P1"),
                    p2 = patternText("P2"),
                    p3 = patternText("P3"),
                    p4 = patternText("P4"),
                    p5 = patternText("P5"),
                    p6 = patternText("P6"),
                    battingFirst = input.battingFirst,
                    firstInningsScore = input.firstInningsScore,
                    isTwentyOvers = input.isTwentyOvers,
                    openingFavourite = input.openingFavourite,
                    preFirstBallOdds = input.preFirstBallOdds,
                    firstBallOdds = input.firstBallOdds,
                    inningsBreakFavourite = input.inningsBreakFavourite,
                    inningsBreakOdds = input.inningsBreakOdds,
                    lambiType = input.lambiType,
                    lambi = input.lambi,
                    teamAPreviousMatch = input.teamAPreviousMatch,
                    teamBPreviousMatch = input.teamBPreviousMatch,
                    teamAClose = input.teamAClose,
                    teamBClose = input.teamBClose,
                    p5Input = input.p5,
                    outcome = "PENDING",
                    actualWinner = 0,
                    resolvedAt = null
                )
            )
        }
    }

    fun updateOutcome(id: Long, actualWinner: Int) {
        if (actualWinner !in 1..2) return
        viewModelScope.launch(Dispatchers.IO) {
            dao.updateOutcome(id, actualWinner, System.currentTimeMillis())
        }
    }

    fun resetOutcome(id: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            dao.resetOutcome(id)
        }
    }

    fun delete(id: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            dao.deleteById(id)
        }
    }
}
