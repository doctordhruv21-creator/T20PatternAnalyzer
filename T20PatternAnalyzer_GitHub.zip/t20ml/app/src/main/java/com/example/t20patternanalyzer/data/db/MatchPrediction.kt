package com.example.t20patternanalyzer.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "match_predictions")
data class MatchPrediction(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val matchId: String,
    val matchName: String,
    val teamA: String,
    val teamB: String,
    val finalTeam: Int,
    val status: String,
    val confidence: Int,
    val coreTeam: Int,
    val marketTeam: Int,
    val p1: String,
    val p2: String,
    val p3: String,
    val p4: String,
    val p5: String,
    val p6: String,
    val createdAt: Long = System.currentTimeMillis(),

    // ML-ready feature snapshot: these are the values that were available at decision time.
    val battingFirst: Int = 0,
    val firstInningsScore: Int? = null,
    val isTwentyOvers: Boolean = true,
    val openingFavourite: Int = 0,
    val preFirstBallOdds: Double? = null,
    val firstBallOdds: Double? = null,
    val inningsBreakFavourite: Int = 0,
    val inningsBreakOdds: Double? = null,
    val lambiType: String = "LAMBI",
    val lambi: Double? = null,
    val teamAPreviousMatch: Int = 0,
    val teamBPreviousMatch: Int = 0,
    val teamAClose: Boolean = false,
    val teamBClose: Boolean = false,
    val p5Input: Int = 0,
    val outcome: String = "PENDING",
    val actualWinner: Int = 0,
    val resolvedAt: Long? = null
)
