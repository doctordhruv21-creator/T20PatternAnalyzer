package com.example.t20patternanalyzer.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface PredictionDao {
    @Insert
    suspend fun insert(value: MatchPrediction): Long

    @Query("SELECT * FROM match_predictions ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<MatchPrediction>>

    @Query("UPDATE match_predictions SET outcome = CASE WHEN finalTeam = :actualWinner THEN 'WIN' ELSE 'LOSS' END, actualWinner=:actualWinner, resolvedAt=:resolvedAt WHERE id=:id AND finalTeam IN (1,2)")
    suspend fun updateOutcome(id: Long, actualWinner: Int, resolvedAt: Long)

    @Query("UPDATE match_predictions SET outcome='PENDING', actualWinner=0, resolvedAt=NULL WHERE id=:id")
    suspend fun resetOutcome(id: Long)

    @Query("DELETE FROM match_predictions WHERE id=:id")
    suspend fun deleteById(id: Long)
}
