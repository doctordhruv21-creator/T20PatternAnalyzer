# T20 Pattern Analyzer v7.0 — ML Data Foundation

This version keeps the existing P1–P6 decision engine intact and adds the foundation for a future P7 machine-learning layer.

## What's new
- ML-ready prediction history in Room.
- Every saved prediction stores the decision-time P1–P6 inputs/features, not only the final text.
- Prediction records start as `PENDING`.
- After a match finishes, mark the actual winner directly from the Saved / ML Data Vault screen.
- Automatic WIN/LOSS classification against the saved prediction.
- Dataset health panel: saved, pending, resolved and recorded accuracy.
- Room 1 → 2 migration preserves existing saved snapshots.
- Version bumped to 7.0.

## Important ML design rule
The stored feature snapshot represents information available at the time of the prediction. Do not train on information that became available after the prediction point; this prevents data leakage.

## P1–P6
The original P1–P6 engine is preserved. P6 continues to use the pre-first-ball odds baseline, the 0.0065 run adjustment convention, automatic actual-score vs Lambi difference, and the strict >0.10 market-difference threshold.

## Next phase
Once enough resolved records exist, export/prepare the dataset and train a first tabular model. ML should initially be treated as P7 / a second opinion and should not silently replace P1–P6.
