package com.example.t20patternanalyzer

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.ViewGroup
import android.widget.*
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

data class Prediction(val team:String, val score:Int, val reasons:List<String>, val probability:Double?)

class MainActivity: Activity() {
    private lateinit var result: TextView
    private lateinit var history: TextView
    private fun ed(h:String)=EditText(this).apply{hint=h; setSingleLine(true)}
    private fun add(box:LinearLayout,v:android.view.View){box.addView(v,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=10})}

    override fun onCreate(b:Bundle?){
        super.onCreate(b)
        val s=ScrollView(this); val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(28,24,28,30)}
        add(box,TextView(this).apply{text="T20 Pattern Analyzer  V2";textSize=26f;setTextColor(Color.rgb(20,55,90))})
        add(box,TextView(this).apply{text="Experimental pattern engine • Backtest-ready";textSize=14f})
        val a=ed("Team A"), c=ed("Team B"), score=ed("1st innings score"), open=ed("Opening odds — Team A"), cur=ed("Current odds — Team A"), diff=ed("Run difference — A perspective")
        listOf(a,c,score,open,cur,diff).forEach{add(box,it)}
        val prev=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,arrayOf(
            "Previous result unknown","A won chasing","A won defending","B won chasing","B won defending"))}; add(box,prev)
        val close=CheckBox(this).apply{text="Previous match was very close / favourite changed multiple times"}; add(box,close)
        val collapse=CheckBox(this).apply{text="Early collapse followed by recovery"}; add(box,collapse)
        val steady=CheckBox(this).apply{text="Steady/slower innings without repeated wicket clusters"}; add(box,steady)
        val analyse=Button(this).apply{text="ANALYSE"}; add(box,analyse)
        result=TextView(this).apply{textSize=17f}; add(box,result)
        val save=Button(this).apply{text="SAVE PREDICTION"}; add(box,save)
        history=TextView(this).apply{textSize=14f}; add(box,history)
        val clear=Button(this).apply{text="CLEAR FORM"}; add(box,clear)

        var last:Prediction?=null
        analyse.setOnClickListener{
            val A=a.text.toString().ifBlank{"Team A"}; val B=c.text.toString().ifBlank{"Team B"}
            val sc=score.text.toString().toIntOrNull(); val oo=open.text.toString().toDoubleOrNull(); val co=cur.text.toString().toDoubleOrNull(); val rd=diff.text.toString().toDoubleOrNull()
            val r=mutableListOf<String>(); var av=0; var bv=0
            if(sc!=null) when(sc){
                in 141..149,in 160..169,in 180..189,in 190..200,in 210..225->{r+="P1: $sc → DEFEND tendency"; if(prev.selectedItemPosition==2||prev.selectedItemPosition==4){}}
                in 150..159,in 170..179,in 201..209->{r+="P1: $sc → CHASE tendency"}
                else->r+="P1: score outside configured bands"
            }
            when(prev.selectedItemPosition){
                1->{r+="P2: A won chasing previously → oppose A if A chases"; av-=1;bv+=1}
                2->{r+="P2: A won defending previously → support A if A defends";av+=1}
                3->{r+="P2: B won chasing previously → oppose B if B chases";bv-=1;av+=1}
                4->{r+="P2: B won defending previously → support B if B defends";bv+=1}
            }
            if(close.isChecked){r+="P3: close/fluctuating previous match → previous winner continuation signal"; if(prev.selectedItemPosition==1||prev.selectedItemPosition==2)av++ else if(prev.selectedItemPosition>=3)bv++}
            if(collapse.isChecked){r+="P5: collapse + recovery → CHASE tendency";bv++}
            if(steady.isChecked){r+="P5: steady/slower innings → DEFEND tendency";av++}
            if(oo!=null&&co!=null&&oo>1&&co>1){
                if(co<oo){r+="P4: A shortened ${"%.2f".format(oo)} → ${"%.2f".format(co)} → oppose A";bv++}
                else if(co>oo){r+="P4: A drifted ${"%.2f".format(oo)} → ${"%.2f".format(co)} → oppose B";av++}
                else r+="P4: no odds movement"
            }
            var p:Double?=if(oo!=null&&oo>1)1/oo else null
            if(p!=null&&rd!=null){p=min(.99,max(.01,p+rd*.0065));r+="P6: run model → A ${"%.1f".format(Locale.US,p*100)}%"}
            val pred=when{av>bv->A;bv>av->B;else->"NO CLEAR SIGNAL"}
            val conf=if(av+bv==0)50.0 else min(90.0,50.0+10.0*kotlin.math.abs(av-bv))
            r+="";r+="Composite signal: $pred";r+="Experimental confidence: ${"%.0f".format(conf)}/100"
            r+="";r+="Important: confidence is a signal score, not a guarantee or proven probability."
            last=Prediction(pred, r.size,r,p); result.text=r.joinToString("\n• ","• ")
        }
        save.setOnClickListener{last?.let{history.text="Last saved prediction: ${it.team}\n${history.text}"}?:Toast.makeText(this,"Analyse first",Toast.LENGTH_SHORT).show()}
        clear.setOnClickListener{listOf(a,c,score,open,cur,diff).forEach{it.text.clear()};result.text=""}
        s.addView(box);setContentView(s)
    }
}
