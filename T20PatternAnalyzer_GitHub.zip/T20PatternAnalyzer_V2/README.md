# T20 Pattern Analyzer V2
This is a prototype Android Studio project. It implements the six experimental T20 signals supplied by the user and a basic composite score.

V2 improvements:
- Cleaner single-screen UI
- Signal-by-signal reasoning
- Composite signal score
- Run-probability calculation
- Save-last-prediction placeholder for the next database milestone
- Architecture remains ready for live score/odds adapters

No betting or wager placement is implemented.
